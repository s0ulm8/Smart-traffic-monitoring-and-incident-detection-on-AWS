"""
Train a number-plate DETECTOR (finds the plate in a vehicle image; it does not read the text).

Run it in Google Colab (free GPU) or any machine with a GPU:
    pip install ultralytics
    python train_plate_model.py --data /path/to/dataset/data.yaml --epochs 50

The dataset must be in YOLOv8 format with exactly ONE class (the plate). Datasets whose classes are
characters (0-9, A-Z) are for text reading, not plate finding, and are rejected here.
Output: models/plate.pt  (use it with  python main.py --plate-model models/plate.pt ...)
"""

import argparse
import os
import shutil
import sys

import yaml


def check_dataset(data_yaml):
    with open(data_yaml) as f:
        cfg = yaml.safe_load(f)
    nc = int(cfg.get("nc", len(cfg.get("names", []))))
    if nc != 1:
        sys.exit(f"ERROR: this dataset has {nc} classes {cfg.get('names')}. A plate detector needs exactly 1 "
                 f"class (the plate). A dataset of characters cannot be used here.")
    base = cfg.get("path") or os.path.dirname(os.path.abspath(data_yaml))
    if not os.path.isabs(base):
        base = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(data_yaml)), base))
    for key in ("train", "val"):
        path = cfg.get(key)
        if not path:
            sys.exit(f"ERROR: data.yaml has no '{key}' entry.")
        full = path if os.path.isabs(path) else os.path.normpath(os.path.join(base, path))
        if os.path.isdir(full):
            n = len([x for x in os.listdir(full) if x.lower().endswith((".jpg", ".jpeg", ".png"))])
            print(f"{key}: {n} images ({full})")
            if key == "train" and n < 300:
                print(f"WARNING: only {n} training images - the model will be weak. Aim for 1000+.")
        else:
            print(f"NOTE: could not find {key} folder {full} (Ultralytics will resolve it itself).")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="path to the dataset's data.yaml (YOLOv8 format)")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--base", default="yolov8n.pt", help="starting weights")
    ap.add_argument("--out", default=os.path.join("models", "plate.pt"))
    args = ap.parse_args()

    check_dataset(args.data)
    from ultralytics import YOLO

    model = YOLO(args.base)
    model.train(data=args.data, epochs=args.epochs, imgsz=args.imgsz, batch=args.batch, project="runs_plate", name="train")
    best = os.path.join(str(model.trainer.save_dir), "weights", "best.pt")
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    shutil.copy(best, args.out)
    metrics = YOLO(args.out).val(data=args.data)
    print(f"\nSaved {args.out}.  mAP50 = {metrics.box.map50:.3f}  (above ~0.8 is good; below 0.5 needs more data)")


if __name__ == "__main__":
    main()
