# Smart Traffic Monitoring & Incident Detection - cloud edition

Your v4 pipeline (YOLO + ByteTrack + counting + speed + plates), unchanged, wrapped in a cloud application:
**video in -> vehicles counted and classified -> congestion / stopped-vehicle / overspeed / wrong-direction incidents ->
statistics in a database -> web dashboard.**

```
 Browser ──> ALB (load balancer) ──> EC2 instances in an Auto Scaling group (Docker: FastAPI + YOLO/OpenCV)
                                         │            │             │
                                         ▼            ▼             ▼
                                        RDS         S3        CloudWatch (logs, metrics, alarms)
                                  (PostgreSQL:   (videos,
                                   stats,        snapshots)       IAM roles · Secrets Manager · Security groups
                                   incidents)
```

| Your brief | What implements it |
|---|---|
| EC2 -> application / AI processing | EC2 launch template + Docker image (`Dockerfile`) |
| S3 -> video / image storage | Private bucket: original video, annotated video, incident snapshots |
| RDS -> traffic records | PostgreSQL: `jobs`, `traffic_stats` (every 5 s), `incidents` |
| CloudWatch -> monitoring | Container logs, custom metrics, dashboard, 5 alarms |
| IAM -> security | Instance role (no keys on servers), least-privilege policy, Secrets Manager, SG chain, IMDSv2 |
| ALB -> load balancing | Application Load Balancer, health check on `/health` |
| Auto Scaling -> scalability | ASG 1-3 instances, target-tracking on CPU 60 %, scale-in protection while a job runs |

---------------------------------------------------------------------------------------------------

## 0. What you need (30 min, mostly waiting)

- **AWS account** with a card (phone verification). Region used below: `ap-south-1` (Mumbai).
- **Docker Desktop**, **AWS CLI v2**, **Python 3.11+**, **Git Bash or WSL** on Windows (the deploy scripts are bash).
- A **test video**: 1-2 min of fixed-camera road traffic (MP4). Short is better for the first run.
- Budget: roughly **US$0.25 per hour (about US$6 per day)** while the stack runs: c5.xlarge + load balancer + RDS
  + public IPs. This is an *estimate*: check the AWS Pricing Calculator. **Tear down when finished** (section 7).

## 1. Run it on your laptop first (about 1 hour)

```bash
# A) unit + API tests (no models or AWS needed)
python -m venv venv && source venv/bin/activate        # Windows PowerShell: venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
pytest                                                  # expect 115 passed

# B) the real thing, in Docker, with PostgreSQL (same engine as RDS)
APP_API_KEY=choose-a-key docker compose up --build      # first build: 10-20 min (PyTorch, OCR model)
```
Open http://localhost:8000, enter your key (top right), upload your video, watch the job run.
Check: annotated video plays, chart fills, incidents appear with snapshots.

**Tune now, not in the cloud.** Cloud iterations cost 20 minutes each.
- Congestion / stopped thresholds: `IncidentConfig` in `cloud/incidents.py` (`stopped_seconds`, `moderate_vehicles`, ...).
  They are heuristics, **untuned for your camera**.
- Lanes + speed calibration: a scene JSON (see README.md "Calibrating speed"); upload it with the video.
  Without it the whole frame is one road area and speed alerts stay off (uncalibrated), exactly as in v4.

Do not continue until the local run works end-to-end.

## 2. Prepare AWS (about 30 min, once)

1. **Root user:** sign in, enable **MFA** (account menu > Security credentials).
2. **Budget alert:** Billing > Budgets > Create budget > *Monthly cost budget* > **$20** > email alert at 80 %.
3. **Admin IAM user** (do not work as root): IAM > Users > Create user > attach `AdministratorAccess` > enable MFA >
   Security credentials > *Create access key* (use case: CLI).
   (A tightly scoped policy is better for production; admin is acceptable for a short-lived learning project.)
4. **CLI:** `aws configure` (key, secret, region `ap-south-1`, output `json`), then `aws sts get-caller-identity`.
5. **Quota check:** Service Quotas > EC2 > *Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances*.
   Each `c5.xlarge` = 4 vCPU; MaxSize 3 needs 12. If your limit is lower, deploy with `MAX_SIZE=1` (or 2),
   or request an increase (can take hours, so do this first).

## 3. Build and push the image (about 20-30 min)

```bash
./deploy/01-push-image.sh
```
Creates the ECR repository (private, scan-on-push, keeps last 5 images), builds for `linux/amd64`, pushes, and remembers the tag.
Console check: ECR > Repositories > traffic-monitor.

## 4. Deploy the stack (about 15-20 min, mostly RDS)

```bash
./deploy/02-deploy-stack.sh                 # optional: ALERT_EMAIL=you@example.com  INSTANCE_TYPE=c5.2xlarge  MAX_SIZE=2
```
Access is restricted to **your current public IP** by default. If your IP changes (mobile hotspot, new network) you get a
timeout: re-run the script, or `ALLOWED_CIDR=0.0.0.0/0` for a short demo.

The script prints the **App URL** and the **API key**. While you wait, watch it in the console:
CloudFormation > your stack > *Events*; then EC2 > Instances, EC2 > Target groups (state turns *healthy*).

**The stack waits for the app to be healthy** (`cfn-signal`): if the image cannot be pulled or the app crashes, creation fails
and rolls back instead of leaving a broken stack. The script prints the first failure reason.

## 5. Verify - and collect evidence for your report

Open the App URL, paste the API key, upload your video. Then confirm each service really is used:

| Check | Where | Expect |
|---|---|---|
| Job completes, video plays | Dashboard | status *completed*, congestion chart, incident list |
| **S3** | S3 > your bucket > `jobs/<id>/` | `input.mp4`, `annotated.mp4`, `incidents/*.jpg`. Bucket is **not public**; the dashboard uses 1-hour presigned URLs |
| **RDS** | Private, reachable only from the app servers. Use SSM Session Manager (EC2 > instance > Connect > Session Manager), then the one-liner below | counts per table |
| **CloudWatch logs** | CloudWatch > Log groups > `/traffic-monitor/app` | application log lines |
| **CloudWatch dashboard** | URL printed by the script | CPU, healthy hosts, requests, jobs, incidents |
| **Secrets Manager** | Secrets Manager > two secrets | API key, DB credentials (never in env vars / user-data) |
| **IAM** | IAM > Roles > `traffic-monitor-InstanceRole-*` | S3 only on this bucket, read only these two secrets |

Read the database from the instance (Session Manager shell):
```bash
sudo docker exec traffic python -c "from cloud.settings import Settings;from cloud.db import Database;from sqlalchemy import text;s=Settings.from_env();d=Database(s.database_url,s.db_ssl)
with d.session() as x: print(x.execute(text('select type,count(*) from incidents group by type')).all())"
```

### Demonstrations worth screenshots (about 1 hour)
1. **Self-healing:** EC2 > terminate the instance. Within ~10 min the Auto Scaling group launches a replacement and the target
   returns to *healthy* (ASG > Activity tab). Running jobs on the killed instance are marked failed ("worker lost" after ~3 min).
2. **Scale-out:** upload a 2-3 min video. YOLO on CPU pins the CPU, so after ~3-5 min average CPU > 60 % and a 2nd instance
   launches (ASG > Activity; CloudWatch dashboard CPU). New uploads can then land on it. A job never moves between servers:
   extra instances add *concurrency*, not speed for one video. While a job runs its instance is protected from scale-in.
3. **Security:** call the API without a key (`curl <url>/api/jobs` -> 401); submit stream URL `http://169.254.169.254/`
   (rejected); try opening an S3 object URL directly (AccessDenied); show the security-group chain ALB -> app -> database.
4. **Alarm:** with `ALERT_EMAIL` set (confirm the subscription email), stop the app container
   (`sudo docker stop traffic` via Session Manager) and wait for the *NoHealthyHosts* alarm email.

## 6. Day plan (one long day)
| Time | Do |
|---|---|
| 0:00-1:00 | Section 0 and 2 (account, MFA, budget, CLI, quota). Start the Docker build (section 1B) while doing this |
| 1:00-2:30 | Local test with your video; tune thresholds; run `pytest` |
| 2:30-3:30 | Section 3 (push image) |
| 3:30-4:30 | Section 4 (deploy). Read the template while RDS creates, so you can explain every resource |
| 4:30-6:30 | Section 5 (verify, demos, screenshots) |
| 6:30-7:30 | Report: diagram, cost, security, scaling, limitations. **Then section 7** |

## 7. Tear down (do not skip)
```bash
./deploy/03-teardown.sh --delete-ecr
```
Empties the bucket, deletes the stack (VPC, ALB, EC2, RDS, secrets, logs) and the ECR repo. Next day: Billing > Cost Explorer;
confirm ~$0. (Load balancer, RDS and public IPv4 addresses are the usual surprises.)

---------------------------------------------------------------------------------------------------

## Troubleshooting
| Symptom | Likely cause / fix |
|---|---|
| Stack rolled back at `AutoScalingGroup` | App never became healthy. Read `/var/log/traffic-userdata.log` and CloudWatch log group `/traffic-monitor/app`. Usual causes: wrong `ImageTag`, image built for ARM (use the script), quota limit |
| `docker pull` access denied | The image is not in ECR in this region/account, or tag mismatch |
| Browser times out | `AllowedCidr` is not your current IP |
| Dashboard says invalid key | `aws secretsmanager get-secret-value ...` command from the script output |
| Job `failed: could not open the video source` | Stream URL not reachable/blocked; private addresses are intentionally refused |
| Annotated video won't play | `ffmpeg` missing (it is in the Docker image; locally install ffmpeg) |
| Slow processing | CPU only. Bigger instance (`INSTANCE_TYPE=c5.2xlarge`), turn off plate OCR in the form, lower resolution |
| Uploads rejected 429 | 5 jobs already queued on that server (`MAX_PENDING_JOBS`) |

## Security notes
- Servers have **no SSH port**; use SSM Session Manager. Security groups: ALB (your IP) -> app :8000 -> database :5432.
- Database in private subnets with no internet route, encrypted at rest, TLS to the app. Secrets in Secrets Manager.
- S3: block-public-access, encrypted, TLS-only, auto-expiry (30 days). IMDSv2 required.
- Stream URLs: only rtsp/rtmp/http(s) to **public** addresses (SSRF guard). Uploads: type, size and "is it a video" checks.
- **Default deployment is HTTP**, so the API key travels unencrypted. Fine for a demo from your own IP; for anything else supply
  `CERT_ARN` (an ACM certificate for your domain) and the template enables HTTPS and redirects HTTP.

## Honest limitations
- **Not tested on real traffic footage / real YOLO inside Docker / a real AWS deployment** by the author (the build environment had no
  Docker, no AWS account and no PyTorch). Tested: 115 automated tests (your 79 + 36 new: API, database, S3/Secrets/ASG/CloudWatch via
  moto, incident logic, SSRF guard, template lint), the real HTTP server and the dashboard in a real browser with a scripted detector.
  Expect the first deploy to need a small fix; section Troubleshooting says where to look.
- Congestion and stopped-vehicle thresholds are untuned defaults. Speed needs calibration (as in v4). Plate reading is weak without a
  dedicated plate model (as in v4).
- A job runs on the instance that received it. Next step for true scale-out: an SQS queue so any server takes any job.
- EC2 sits in public subnets (SG-locked) to avoid NAT-gateway cost; production would use private subnets + NAT/VPC endpoints.
- No user accounts: one shared API key.

## Files
`cloud/` server code · `deploy/template.yaml` CloudFormation · `deploy/*.sh` push/deploy/teardown · `Dockerfile`, `docker-compose.yml`
· `tests/test_cloud_*.py`, `tests/test_incidents.py`, `tests/test_deploy_files.py` · your v4 files are unmodified.
