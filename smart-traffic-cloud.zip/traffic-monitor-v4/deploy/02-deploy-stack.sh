#!/usr/bin/env bash
# Create or update the whole AWS stack (VPC, ALB, Auto Scaling, EC2, RDS, S3, IAM, CloudWatch).
#   ./deploy/02-deploy-stack.sh
# Optional environment variables:
#   STACK_NAME (traffic-monitor)  AWS_REGION (ap-south-1)  IMAGE_TAG (from the last push)  ECR_REPO
#   ALLOWED_CIDR (default: YOUR public IP /32)  INSTANCE_TYPE  MAX_SIZE  ALERT_EMAIL  CERT_ARN
set -euo pipefail
cd "$(dirname "$0")/.."

STACK="${STACK_NAME:-traffic-monitor}"
REGION="${AWS_REGION:-ap-south-1}"
REPO="${ECR_REPO:-traffic-monitor}"
TAG="${IMAGE_TAG:-$(cat deploy/.last-image-tag 2>/dev/null || true)}"
[ -n "$TAG" ] || { echo "No image tag: run ./deploy/01-push-image.sh first (or set IMAGE_TAG)"; exit 1; }

if [ -z "${ALLOWED_CIDR:-}" ]; then
  MYIP="$(curl -fsS https://checkip.amazonaws.com | tr -d '[:space:]')"
  ALLOWED_CIDR="$MYIP/32"
  echo "Restricting access to your current IP: $ALLOWED_CIDR  (set ALLOWED_CIDR=0.0.0.0/0 to open it to everyone)"
fi

aws ecr describe-images --repository-name "$REPO" --image-ids imageTag="$TAG" --region "$REGION" >/dev/null \
  || { echo "Image $REPO:$TAG not found in ECR ($REGION)"; exit 1; }

STATUS="$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query 'Stacks[0].StackStatus' --output text 2>/dev/null || echo NONE)"
if [ "$STATUS" = "ROLLBACK_COMPLETE" ]; then
  echo "A previous attempt failed and rolled back. Deleting it first ..."
  aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
  aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
fi

OVERRIDES=(EcrRepositoryName="$REPO" ImageTag="$TAG" AllowedCidr="$ALLOWED_CIDR")
[ -n "${INSTANCE_TYPE:-}" ] && OVERRIDES+=(InstanceType="$INSTANCE_TYPE")
[ -n "${MAX_SIZE:-}" ]      && OVERRIDES+=(MaxSize="$MAX_SIZE")
[ -n "${ALERT_EMAIL:-}" ]   && OVERRIDES+=(AlertEmail="$ALERT_EMAIL")
[ -n "${CERT_ARN:-}" ]      && OVERRIDES+=(CertificateArn="$CERT_ARN")

aws cloudformation validate-template --template-body file://deploy/template.yaml --region "$REGION" >/dev/null
echo "Deploying stack '$STACK' (first run takes about 15-20 minutes; RDS is the slow part) ..."
aws cloudformation deploy --template-file deploy/template.yaml --stack-name "$STACK" --region "$REGION" \
  --capabilities CAPABILITY_IAM --no-fail-on-empty-changeset --parameter-overrides "${OVERRIDES[@]}" || {
  echo; echo "Deployment FAILED. The first failure reason:"
  aws cloudformation describe-stack-events --stack-name "$STACK" --region "$REGION" \
    --query "reverse(StackEvents)[?contains(ResourceStatus,'FAILED')].[LogicalResourceId,ResourceStatusReason]|[0]" --output text
  echo "See README-CLOUD.md > Troubleshooting. For app problems check the log group /$STACK/app in CloudWatch."
  exit 1
}

out() { aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" \
          --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
echo
echo "================ DONE ================"
echo "App URL      : $(out AppUrl)"
echo "Dashboard    : $(out CloudWatchDashboardUrl)"
echo "S3 bucket    : $(out BucketName)"
echo "API key      : $(eval "$(out GetApiKeyCommand)")"
echo "(The API key is stored in Secrets Manager; treat it like a password.)"
