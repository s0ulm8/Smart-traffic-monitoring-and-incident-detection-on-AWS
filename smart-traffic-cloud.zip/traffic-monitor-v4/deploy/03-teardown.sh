#!/usr/bin/env bash
# Delete EVERYTHING this project created, so nothing keeps billing.
#   ./deploy/03-teardown.sh            (add --delete-ecr to also delete the image repository)
set -euo pipefail
STACK="${STACK_NAME:-traffic-monitor}"
REGION="${AWS_REGION:-ap-south-1}"
REPO="${ECR_REPO:-traffic-monitor}"

read -r -p "Delete stack '$STACK' in $REGION, including the database and all stored videos? (type yes) " ans
[ "$ans" = "yes" ] || { echo "Aborted."; exit 1; }

BUCKET="$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='BucketName'].OutputValue" --output text 2>/dev/null || true)"
if [ -n "$BUCKET" ] && [ "$BUCKET" != "None" ]; then
  echo "Emptying bucket $BUCKET (CloudFormation cannot delete a non-empty bucket) ..."
  aws s3 rm "s3://$BUCKET" --recursive --region "$REGION" >/dev/null
fi
echo "Deleting stack (about 10 minutes) ..."
aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
echo "Stack deleted."

if [ "${1:-}" = "--delete-ecr" ]; then
  aws ecr delete-repository --repository-name "$REPO" --region "$REGION" --force >/dev/null && echo "ECR repository deleted."
else
  echo "ECR repository '$REPO' kept (small storage cost). Delete it with: $0 --delete-ecr"
fi
echo "Tomorrow: check Billing > Cost Explorer to confirm nothing is still charging."
