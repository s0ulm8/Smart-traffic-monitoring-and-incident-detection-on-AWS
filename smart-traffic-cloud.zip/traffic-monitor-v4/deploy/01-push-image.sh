#!/usr/bin/env bash
# Build the Docker image for EC2 (x86_64) and push it to your private ECR repository.
#   ./deploy/01-push-image.sh            (optional: AWS_REGION=ap-south-1 ECR_REPO=traffic-monitor IMAGE_TAG=v1)
set -euo pipefail
cd "$(dirname "$0")/.."

REGION="${AWS_REGION:-ap-south-1}"
REPO="${ECR_REPO:-traffic-monitor}"
TAG="${IMAGE_TAG:-$(date +%Y%m%d-%H%M%S)}"

command -v docker >/dev/null || { echo "Docker is not installed / not on PATH"; exit 1; }
docker info >/dev/null 2>&1 || { echo "Docker is installed but not running - start Docker Desktop"; exit 1; }
ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
REGISTRY="$ACCOUNT.dkr.ecr.$REGION.amazonaws.com"
echo "Account $ACCOUNT, region $REGION, image $REPO:$TAG"

if ! aws ecr describe-repositories --repository-names "$REPO" --region "$REGION" >/dev/null 2>&1; then
  echo "Creating ECR repository $REPO ..."
  aws ecr create-repository --repository-name "$REPO" --region "$REGION" \
    --image-scanning-configuration scanOnPush=true --encryption-configuration encryptionType=AES256 >/dev/null
fi
# keep only the 5 newest images (old ones cost storage money)
aws ecr put-lifecycle-policy --repository-name "$REPO" --region "$REGION" --lifecycle-policy-text '{
  "rules":[{"rulePriority":1,"description":"keep last 5","selection":{"tagStatus":"any","countType":"imageCountMoreThan","countNumber":5},"action":{"type":"expire"}}]}' >/dev/null

aws ecr get-login-password --region "$REGION" | docker login --username AWS --password-stdin "$REGISTRY"
# --platform: EC2 here is x86_64. Without it, a build on an Apple-Silicon laptop would not run on EC2.
docker build --platform linux/amd64 -t "$REPO:$TAG" .
docker tag "$REPO:$TAG" "$REGISTRY/$REPO:$TAG"
docker push "$REGISTRY/$REPO:$TAG"

echo "$TAG" > deploy/.last-image-tag
echo
echo "Pushed $REGISTRY/$REPO:$TAG"
echo "Next:  ./deploy/02-deploy-stack.sh"
