"""Compare a run's summary.json with counts you made by hand.

    python evaluate.py out/summary.json --truth truth.json
truth.json example: {"total": 6, "Car": 6, "Motorcycle": 0, "Bus": 0, "Truck": 0, "overspeeding": 3}
Only keys present in truth.json are checked. Exit code 1 if any count is off.
"""
import argparse
import json
import sys


def compare(stats, truth):
    rows = []
    for key, want in truth.items():
        got = stats["total"] if key == "total" else stats["overspeeding"] if key == "overspeeding" \
            else stats["by_class"].get(key, 0)
        rows.append((key, want, got, got - want))
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("summary")
    ap.add_argument("--truth", required=True)
    a = ap.parse_args()
    stats = json.load(open(a.summary))["stats"]
    rows = compare(stats, json.load(open(a.truth)))
    print(f"{'item':<14}{'manual':>7}{'system':>8}{'error':>7}")
    for k, w, g, e in rows:
        print(f"{k:<14}{w:>7}{g:>8}{e:>+7}")
    sys.exit(1 if any(e for *_, e in rows) else 0)
