"""Vehicle detection + multi-object tracking (YOLO + ByteTrack)."""

from ultralytics import YOLO

import config


def resolve_device():
    """config.USE_GPU now really controls YOLO (it only affected OCR before)."""
    if config.USE_GPU:
        try:
            import torch

            if torch.cuda.is_available():
                return 0
            print("[detector] USE_GPU=True but CUDA is not available - using CPU.")
        except Exception as exc:  # torch missing / broken
            print(f"[detector] could not check CUDA ({exc}) - using CPU.")
    return "cpu"


class VehicleDetectorTracker:
    def __init__(self, model_path=None, conf=None):
        self.model = YOLO(model_path or config.MODEL_PATH)
        self.conf = config.CONF_THRESHOLD if conf is None else conf
        self.vehicle_classes = config.VEHICLE_CLASSES
        self.device = resolve_device()

    def track(self, frame):
        """Returns [{id, box:(x1,y1,x2,y2), cls_id, cls_name, conf}, ...]."""
        results = self.model.track(
            frame,
            persist=True,
            conf=self.conf,
            classes=list(self.vehicle_classes.keys()),
            tracker="bytetrack.yaml",
            device=self.device,
            imgsz=config.YOLO_IMGSZ,
            verbose=False,
        )

        detections = []
        if not results:
            return detections
        boxes = results[0].boxes
        if boxes is None or boxes.id is None:
            return detections

        xyxy = boxes.xyxy.cpu().numpy()
        ids = boxes.id.cpu().numpy().astype(int)
        clss = boxes.cls.cpu().numpy().astype(int)
        confs = boxes.conf.cpu().numpy()

        for box, tid, cls_id, conf in zip(xyxy, ids, clss, confs):
            x1, y1, x2, y2 = box.astype(int)
            height = y2 - y1
            if height < config.MIN_VEHICLE_BOX_HEIGHT_PX or (x2 - x1) * height < config.MIN_VEHICLE_BOX_AREA_PX:
                continue                     # too small to be a usable vehicle detection
            detections.append(
                {
                    "id": int(tid),
                    "box": (int(x1), int(y1), int(x2), int(y2)),
                    "cls_id": int(cls_id),
                    "cls_name": self.vehicle_classes.get(int(cls_id), "Vehicle"),
                    "conf": float(conf),
                }
            )
        return detections
