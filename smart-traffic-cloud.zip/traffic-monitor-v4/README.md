# Traffic Monitor v4

Same objective as before: YOLO detection (car/motorcycle/bus/truck) -> ByteTrack -> plate OCR -> line counting
-> speed -> overspeed alerts -> end-of-video statistics -> Streamlit dashboard. v4 only fixes defects.

## Run
    pip install -r requirements.txt          # opencv-python must be 4.x (Haar plate fallback needs it)
    python main.py --source video.mp4 --scene scenes/highway_example.json --out-dir out
    python main.py --source video.mp4 --speed-limit 50 --distance <MEASURED metres between the two lines>
    streamlit run dashboard.py
    pytest                                   # 75 tests
    python evaluate.py out/summary.json --truth truth.json   # compare against your hand count

## What changed from v3
- Counting: per-ROI lines with hysteresis, wrong-direction flagging, ROI/direction validation.
- Tracking: edge-exit guard, size-ratio gate, soft class bonus, same-frame collision split, bounded memory,
  min box size + MIN_CONFIRM_FRAMES (fixes the "#8 Car" over-count from tiny false detections).
- Speed: upward traffic handled; overspeed needs 6 consecutive fresh readings (false alerts 0% vs 36% in
  simulated +/-2px noise); plausibility cap; calibration validation; "SPEED UNCALIBRATED" banner.
- Plates: plate search only when the vehicle is wide enough, hard caps, character-level voting,
  multi-fragment joining, overspeed events get their plate filled in when OCR resolves later.
- Haar fallback: vendored XML in assets/, loud warning if no localiser is available (was silently disabled on OpenCV 5).
- Ops: GPU device passed to YOLO, live-stream timestamps, H.264 output, scene JSON files, config resolved at construction.

## Calibrating speed (required for real numbers)
Use 4+ road points forming a known rectangle (`calibration_src_points` px, `calibration_dst_points` metres)
in the scene JSON, or measure the distance between the two lines. The default 15 m is a placeholder.

## Measured results (real runs)
- highway.mp4 (812 frames): 28 vehicles (25 car, 2 truck, 1 bus), 5 overspeed flagged. Speeds UNCALIBRATED.
- plates.mp4 (746 frames): 6 cars, 4 overspeed flagged. I passed `--distance 12` as an illustrative value,
  NOT a measurement, so those speeds are illustrative only.

## Known limitations
- Plates: English-only OCR, so Chinese province characters are dropped (A8254S plate -> partial read);
  one car (#1) was read wrongly ("5482545") in the sample. Single-line plates only. A dedicated plate model
  (`--plate-model`) is strongly recommended over the Haar fallback. Far-away vehicles (highway clip) have no readable plates.
- A different same-looking, same-sized car appearing where another vanished mid-scene can be merged.
- Counts validated by hand on plates.mp4 only: 6 moving cars (2 parked cars correctly not counted); system = 6 (validation/). One 30 s clip, not a statistical proof; highway.mp4 is NOT hand-counted.
- Dashboard loads without errors under Streamlit AppTest; a full upload-and-run session was not exercised.
- Not yet done: trajectory drawing, richer reports.
- A 91 km/h reading on plates.mp4 car #8 survived a jump-rejection fix, so it is not a tracking glitch; with a guessed 12 m distance it is unverifiable.

## Why some vehicles show a speed and others don't (two-line mode)
A speed appears only after a vehicle crosses BOTH speed lines. Far-away cars are detected only low in the frame,
so with lines at 55%/80% only 17 of 28 counted highway vehicles got a speed; with 62%/88% 27 of 28 did.
Place the lines (scene keys `speed_line_a_ratio` / `speed_line_b_ratio`) where vehicles are already detected,
and set `line_distance_m` to the REAL measured distance between THOSE two lines. With the placeholder 15 m
the speeds (and overspeed alerts) are meaningless: on the highway clip nearly every vehicle was flagged.

## Training a better plate model (`train_plate_model.py`)
The plate model from the small GitHub repo was trained on very little data. To train your own:
1. Get a YOLOv8-format dataset with ONE class (the plate) and 1000+ images (e.g. from Roboflow Universe:
   Fork Dataset -> Download -> YOLOv8). Character datasets (0-9, A-Z) will NOT work and are rejected.
2. In Google Colab (free GPU runtime): `pip install ultralytics`, upload the dataset and this script, then
   `python train_plate_model.py --data dataset/data.yaml --epochs 50`
3. Download `models/plate.pt` and use it: `python main.py --source video.mp4 --plate-model models/plate.pt`
The script prints mAP50 at the end (above ~0.8 is good). Tested here only on a 4-image toy set (1 epoch) to
confirm the training/saving steps run; real accuracy depends on your dataset.
