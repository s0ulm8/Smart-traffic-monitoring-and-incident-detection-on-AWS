"""
Number-plate localisation + OCR.

  * detect_plate(): dedicated plate model if config.PLATE_MODEL_PATH is set,
    otherwise a (weak) OpenCV Haar-cascade fallback.
  * read_plate(): upscales + contrast-enhances the crop, then joins ALL
    confident text fragments on the plate's line left-to-right (EasyOCR often
    splits a plate in two), validates the result against PLATE_REGEX and a
    minimum confidence.
  * combine_plate_reads(): character-by-character confidence-weighted vote
    across several reads, so A82545 + A8254S + A8254S -> A8254S instead of
    splitting the votes between two near-identical strings.

Single-line plates only (two-line plates are not handled).
"""

import os
import re
from collections import defaultdict

import cv2

import config


def combine_plate_reads(reads):
    """reads: list of (text, confidence). Returns the consensus plate or None."""
    if not reads:
        return None
    by_len = defaultdict(list)
    for text, conf in reads:
        by_len[len(text)].append((text, conf))
    length = max(by_len, key=lambda n: sum(c for _, c in by_len[n]))   # most-supported length
    group = by_len[length]
    out = []
    for i in range(length):
        scores = defaultdict(float)
        for text, conf in group:
            scores[text[i]] += conf
        out.append(max(scores.items(), key=lambda kv: kv[1])[0])
    return "".join(out)


def _clean(text):
    return re.sub(r"[^A-Za-z0-9]", "", text).upper()


def _extent(bbox):
    xs = [p[0] for p in bbox]
    ys = [p[1] for p in bbox]
    return min(xs), max(xs), min(ys), max(ys)


class PlateRecognizer:
    def __init__(self, plate_model_path=None, use_easyocr=True):
        plate_model_path = config.PLATE_MODEL_PATH if plate_model_path is None else plate_model_path
        self.plate_model = None
        self.cascade = None
        self.ocr_error = None
        self.localiser_error = None

        if plate_model_path and os.path.exists(plate_model_path):
            from ultralytics import YOLO

            self.plate_model = YOLO(plate_model_path)
        else:
            if plate_model_path:
                print(f"[plates] PLATE_MODEL_PATH '{plate_model_path}' not found - using the weak Haar fallback.")
            self.cascade = self._load_cascade()
            if self.cascade is None:
                self.localiser_error = ("no plate localiser available: need OpenCV 4.x (cv2.CascadeClassifier) "
                                        "or a PLATE_MODEL_PATH")
                print(f"[plates] WARNING: {self.localiser_error}. Plates will NOT be found.")

        self.reader = None
        if use_easyocr:
            try:
                import easyocr

                self.reader = easyocr.Reader(["en"], gpu=config.USE_GPU)
            except Exception as exc:
                # Previously swallowed silently, leaving plates blank with no clue why.
                self.ocr_error = str(exc)
                print(f"[plates] WARNING: EasyOCR could not be loaded ({exc}). "
                      f"Plate reading is DISABLED for this run.")

        self._plate_regex = re.compile(config.PLATE_REGEX)

    @staticmethod
    def _load_cascade():
        """Vendored XML first (works on any OpenCV 4.x wheel), then cv2.data."""
        if not hasattr(cv2, "CascadeClassifier"):
            return None
        here = os.path.dirname(os.path.abspath(__file__))
        candidates = [os.path.join(here, "assets", "haarcascade_russian_plate_number.xml")]
        if hasattr(cv2, "data"):
            candidates.append(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")
        for path in candidates:
            if os.path.exists(path):
                c = cv2.CascadeClassifier(path)
                if not c.empty():
                    return c
        return None

    # ------------------------------------------------------------------
    def detect_plate(self, vehicle_crop):
        """Returns (plate_crop, box) or (None, None)."""
        if vehicle_crop is None or vehicle_crop.size == 0:
            return None, None

        if self.plate_model is not None:
            results = self.plate_model.predict(vehicle_crop, conf=config.PLATE_CONF_THRESHOLD, verbose=False)
            if results and len(results[0].boxes) > 0:
                boxes = results[0].boxes
                best = int(boxes.conf.argmax())            # most confident, not just the first
                x1, y1, x2, y2 = boxes.xyxy[best].cpu().numpy().astype(int)
                crop = vehicle_crop[y1:y2, x1:x2]
                return (crop, (int(x1), int(y1), int(x2), int(y2))) if crop.size else (None, None)
            return None, None

        if self.cascade is None:
            return None, None
        gray = cv2.cvtColor(vehicle_crop, cv2.COLOR_BGR2GRAY)
        plates = self.cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(40, 15))
        if len(plates) == 0:
            return None, None
        plates = [p for p in plates if config.PLATE_MIN_ASPECT <= p[2] / max(p[3], 1) <= config.PLATE_MAX_ASPECT]
        if not plates:
            return None, None                # grille/headlight false hits are not plate-shaped
        x, y, w, h = max(plates, key=lambda p: p[2] * p[3])
        crop = vehicle_crop[y:y + h, x:x + w]
        return (crop, (int(x), int(y), int(x + w), int(y + h))) if crop.size else (None, None)

    @staticmethod
    def _preprocess(plate_crop):
        h, w = plate_crop.shape[:2]
        scale = max(1, int(200 / max(h, 1)))
        if scale > 1:
            plate_crop = cv2.resize(plate_crop, (w * scale, h * scale), interpolation=cv2.INTER_CUBIC)
        gray = cv2.cvtColor(plate_crop, cv2.COLOR_BGR2GRAY)
        return cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)

    def read_plate(self, plate_crop):
        """Returns (text, confidence) or (None, 0.0)."""
        if plate_crop is None or plate_crop.size == 0 or self.reader is None:
            return None, 0.0

        results = self.reader.readtext(self._preprocess(plate_crop))
        frags = []
        for bbox, text, conf in results:
            cleaned = _clean(text)
            if cleaned and conf >= config.PLATE_MIN_FRAGMENT_CONFIDENCE:
                frags.append((bbox, cleaned, float(conf)))
        if not frags:
            return None, 0.0

        # Anchor on the most confident fragment, then add every other
        # fragment sitting on the same text line, ordered left to right.
        anchor = max(frags, key=lambda f: f[2])
        _, _, ay0, ay1 = _extent(anchor[0])
        mid, band = (ay0 + ay1) / 2, max(ay1 - ay0, 1)
        line = [f for f in frags if abs((_extent(f[0])[2] + _extent(f[0])[3]) / 2 - mid) <= 0.75 * band]
        line.sort(key=lambda f: _extent(f[0])[0])

        text = "".join(f[1] for f in line)
        conf = sum(len(f[1]) * f[2] for f in line) / sum(len(f[1]) for f in line)   # length-weighted

        if conf < config.PLATE_MIN_OCR_CONFIDENCE or not self._plate_regex.match(text):
            return None, 0.0
        return text, conf
