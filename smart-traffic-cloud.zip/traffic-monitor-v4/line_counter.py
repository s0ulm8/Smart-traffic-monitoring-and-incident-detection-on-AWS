"""
ROI-aware, direction-aware vehicle counting.

A vehicle is counted once, when its ground point moves from clearly one side
of its ROI's counting line to clearly the other side. "Clearly" means more
than COUNT_LINE_HYSTERESIS_PX away from the line, so:
  * a stopped/slow vehicle whose box jitters across the line is NOT counted
  * a slow crawler is still counted (it eventually leaves the dead zone)
  * crossing direction comes from which side it came from and went to
    (a real displacement, not a single noisy frame-to-frame difference)

Vehicles crossing against an ROI's expected direction are flagged as
wrong-direction rather than silently counted as normal traffic.
"""

from collections import defaultdict

import config


class RoiLineCounter:
    def __init__(self, hysteresis_px=None):
        self.hysteresis_px = config.COUNT_LINE_HYSTERESIS_PX if hysteresis_px is None else hysteresis_px
        self.last_side = {}                  # canonical_id -> {roi_name: -1 | +1}
        self.counted_ids = set()
        self.counts_by_roi_direction = defaultdict(int)   # (roi_name, direction) -> n
        self.wrong_direction_ids = set()

    def update(self, tid, roi, y):
        """Call once per frame per visible vehicle with its ground-point y.
        Returns None, or {"roi", "direction", "wrong_direction"} on the frame
        a new count is registered."""
        if roi is None or tid in self.counted_ids:
            return None

        line = roi.count_line_y
        if y < line - self.hysteresis_px:
            side = -1
        elif y > line + self.hysteresis_px:
            side = 1
        else:
            return None                      # dead zone: keep the previous side

        sides = self.last_side.setdefault(tid, {})
        prev = sides.get(roi.name)           # sides are tracked per ROI/line
        sides[roi.name] = side
        if prev is None or prev == side:
            return None

        direction = "down" if side > prev else "up"
        self.counted_ids.add(tid)
        self.counts_by_roi_direction[(roi.name, direction)] += 1
        wrong = roi.direction not in ("both", direction)
        if wrong:
            self.wrong_direction_ids.add(tid)
        return {"roi": roi.name, "direction": direction, "wrong_direction": wrong}

    def forget(self, tid):
        self.last_side.pop(tid, None)
        self.counted_ids.discard(tid)        # bounded memory; tid is long gone
