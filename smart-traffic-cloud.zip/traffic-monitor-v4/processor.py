"""
TrafficMonitor v4: detection+tracking -> stable IDs -> ROI/direction-aware
counting -> speed -> persistent overspeed alerts -> plate OCR with voting.

Design notes
  * All geometry uses the box's bottom-centre (the road-contact point).
  * Aggregate stats are running counters, so per-vehicle detail can be purged
    for memory without changing totals.
  * Overspeed alerts need several consecutive FRESH readings above the limit;
    events keep the track ID and their plate is updated if OCR resolves later.
  * Plate searching is gated on vehicle size and spread over the vehicle's
    whole visible lifetime, so it is not exhausted while the vehicle is far.
  * Defaults are resolved from `config` at construction time (not import time),
    and the detector / plate recognizer can be injected (used by the tests).
"""

import csv
import json
import os
import time
from collections import Counter, defaultdict

import cv2

import config
import utils
from class_voter import ClassVoter
from line_counter import RoiLineCounter
from plate_recognition import PlateRecognizer, combine_plate_reads
from roi import RoadROIManager
from speed_estimator import HomographySpeedEstimator, SimpleLineSpeedEstimator
from track_merger import TrackMerger

_UNSET = object()


def _pick(value, default):
    return default if value is _UNSET else value


def is_live_source(source):
    """Camera index or network stream: timestamps must come from the wall clock."""
    if isinstance(source, int):
        return True
    return str(source).lower().startswith(("rtsp://", "rtmp://", "http://", "https://", "udp://"))


class TrafficMonitor:
    def __init__(
        self,
        speed_limit_kmh=_UNSET,
        real_distance_m=_UNSET,
        model_path=_UNSET,
        plate_model_path=_UNSET,
        conf=_UNSET,
        enable_ocr=True,
        calibration_src_points=_UNSET,
        calibration_dst_points=_UNSET,
        road_rois=_UNSET,
        speed_line_a_ratio=_UNSET,
        speed_line_b_ratio=_UNSET,
        distance_is_measured=False,
        detector=None,
        plate_recognizer=None,
    ):
        self.speed_limit = _pick(speed_limit_kmh, config.SPEED_LIMIT_KMH)
        self.real_distance_m = _pick(real_distance_m, config.SPEED_CALIB_DISTANCE_M)
        self.calibration_src_points = _pick(calibration_src_points, config.CALIBRATION_SRC_POINTS)
        self.calibration_dst_points = _pick(calibration_dst_points, config.CALIBRATION_DST_POINTS)
        self.road_rois_config = _pick(road_rois, config.ROAD_ROIS)
        self.speed_line_a_ratio = _pick(speed_line_a_ratio, config.SPEED_LINE_A_RATIO)
        self.speed_line_b_ratio = _pick(speed_line_b_ratio, config.SPEED_LINE_B_RATIO)
        self.distance_is_measured = distance_is_measured

        if detector is None:
            from detector_tracker import VehicleDetectorTracker   # heavy import only when needed

            detector = VehicleDetectorTracker(_pick(model_path, config.MODEL_PATH), _pick(conf, config.CONF_THRESHOLD))
        self.detector = detector
        self.plate_recognizer = plate_recognizer or PlateRecognizer(
            _pick(plate_model_path, config.PLATE_MODEL_PATH), use_easyocr=enable_ocr
        )
        self.track_merger = TrackMerger()
        self.class_voter = ClassVoter()
        self.counter = RoiLineCounter()

        self.roi_manager = None
        self.speed_estimator = None
        self.using_homography_speed = False
        self.speed_calibrated = False

        self.plate_reads = defaultdict(list)             # tid -> [(text, conf)]
        self.plate_ocr_calls = defaultdict(int)
        self.plate_searches = defaultdict(int)
        self.plate_last_attempt_frame = {}

        self.vehicle_records = {}
        self.last_seen_frame = {}
        self.hit_count = {}                              # total sightings (not necessarily consecutive)
        self.events = []

        self.agg_total = 0
        self.agg_by_class = Counter()
        self.agg_overspeeding = 0
        self.agg_wrong_direction = 0
        self.agg_by_roi_direction = Counter()

        self.frame_idx = 0

    # ------------------------------------------------------------------
    def _init_geometry(self, w, h):
        self.roi_manager = RoadROIManager(w, h, self.road_rois_config)
        if not self.roi_manager.is_configured():
            print("[TrafficMonitor] No ROAD_ROIS configured - using one whole-frame ROI "
                  "(counts are NOT lane-separated).")

        if self.calibration_src_points and self.calibration_dst_points:
            self.speed_estimator = HomographySpeedEstimator(self.calibration_src_points, self.calibration_dst_points)
            self.using_homography_speed = True
            self.speed_calibrated = True
        else:
            self.speed_estimator = SimpleLineSpeedEstimator(
                int(h * self.speed_line_a_ratio), int(h * self.speed_line_b_ratio), self.real_distance_m
            )
            self.using_homography_speed = False
            self.speed_calibrated = bool(self.distance_is_measured)
            if not self.speed_calibrated:
                print("[TrafficMonitor] WARNING: speed is UNCALIBRATED (no calibration points and the line "
                      f"distance {self.real_distance_m} m is an unverified default). Speeds are indicative only.")

    # ------------------------------------------------------------------
    def _link_plate_to_events(self, tid, plate):
        for e in self.events:
            if e["track_id"] == tid:
                e["plate"] = plate

    def _update_plate(self, tid, rec, frame, box):
        x1, y1, x2, y2 = box
        if (
            self.plate_recognizer.reader is None
            or (x2 - x1) < config.PLATE_MIN_VEHICLE_WIDTH_PX
            or self.plate_ocr_calls[tid] >= config.MAX_OCR_ATTEMPTS_PER_VEHICLE
            or self.plate_searches[tid] >= config.MAX_PLATE_SEARCHES_PER_VEHICLE
            or len(self.plate_reads[tid]) >= config.PLATE_MIN_ACCEPTED_READS
        ):
            return
        last = self.plate_last_attempt_frame.get(tid, -config.OCR_ATTEMPT_INTERVAL_FRAMES)
        if self.frame_idx - last < config.OCR_ATTEMPT_INTERVAL_FRAMES:
            return
        self.plate_last_attempt_frame[tid] = self.frame_idx
        self.plate_searches[tid] += 1

        plate_crop, _ = self.plate_recognizer.detect_plate(frame[max(y1, 0):y2, max(x1, 0):x2])
        if plate_crop is None:
            return                       # nothing found: costs a search, not the OCR budget
        self.plate_ocr_calls[tid] += 1
        text, conf = self.plate_recognizer.read_plate(plate_crop)
        if not text:
            return
        self.plate_reads[tid].append((text, conf))
        best = combine_plate_reads(self.plate_reads[tid])
        if best != rec["plate"]:
            rec["plate"] = best
            self._link_plate_to_events(tid, best)     # fix earlier "UNKNOWN" events

    def _update_speed(self, tid, rec, gx, gy, timestamp):
        reading = self.speed_estimator.update(tid, gx, gy, timestamp)
        if reading is None:
            return
        rec["speed"] = reading.speed_kmh
        if not self.speed_calibrated and not config.ALERT_WHEN_UNCALIBRATED:
            return                           # show the indicative speed, but raise no alert
        if reading.decision_kmh > self.speed_limit + config.OVERSPEED_TOLERANCE_KMH:
            rec["over_streak"] += 1
        else:
            rec["over_streak"] = 0
        if rec["over_streak"] >= self.speed_estimator.confirm and not rec["overspeed"]:
            rec["overspeed"] = True
            self.agg_overspeeding += 1
            self.events.append({
                "frame": self.frame_idx,
                "track_id": tid,
                "class": rec["class"],
                "plate": rec["plate"] or "UNKNOWN",
                "speed_kmh": rec["speed"],
                "limit_kmh": self.speed_limit,
                "speed_calibrated": self.speed_calibrated,
            })

    # ------------------------------------------------------------------
    def process_frame(self, frame, timestamp=None):
        h, w = frame.shape[:2]
        if self.roi_manager is None:
            self._init_geometry(w, h)
        if timestamp is None:
            timestamp = time.time()

        detections = self.track_merger.update(frame, self.detector.track(frame), self.frame_idx)

        for det in detections:
            tid = det["canonical_id"]
            x1, y1, x2, y2 = det["box"]
            gx, gy = (x1 + x2) // 2, y2                  # bottom-centre ground point
            self.last_seen_frame[tid] = self.frame_idx

            self.hit_count[tid] = self.hit_count.get(tid, 0) + 1
            if self.hit_count[tid] < config.MIN_CONFIRM_FRAMES:
                continue                                  # unconfirmed: probably noise

            stable_class = self.class_voter.update(tid, det["cls_name"])
            rec = self.vehicle_records.get(tid)
            if rec is None:
                rec = {"class": stable_class, "plate": None, "speed": None, "overspeed": False,
                       "counted": False, "wrong_direction": False, "over_streak": 0}
                self.vehicle_records[tid] = rec
            rec["class"] = stable_class

            roi = self.roi_manager.assign((gx, gy))
            result = self.counter.update(tid, roi, gy)
            if result is not None:
                rec["counted"] = True
                self.agg_total += 1
                self.agg_by_class[stable_class] += 1
                self.agg_by_roi_direction[(result["roi"], result["direction"])] += 1
                if result["wrong_direction"]:
                    rec["wrong_direction"] = True
                    self.agg_wrong_direction += 1

            self._update_speed(tid, rec, gx, gy, timestamp)
            self._update_plate(tid, rec, frame, det["box"])

            utils.draw_box(frame, det["box"], rec["class"], tid, rec["plate"], rec["speed"],
                           rec["overspeed"], rec["wrong_direction"])

        utils.draw_rois(frame, self.roi_manager)
        if self.using_homography_speed:
            utils.draw_calibration_quad(frame, self.calibration_src_points)
        else:
            utils.draw_speed_lines(frame, self.speed_estimator.line_a_y, self.speed_estimator.line_b_y)
        stats = self.get_stats()
        utils.draw_hud(frame, stats)

        self._purge_stale_records()
        self.frame_idx += 1
        return frame, stats

    # ------------------------------------------------------------------
    def _purge_stale_records(self):
        stale = [t for t, last in self.last_seen_frame.items() if self.frame_idx - last > config.RECORD_EXPIRY_FRAMES]
        for tid in stale:
            for d in (self.vehicle_records, self.last_seen_frame, self.hit_count, self.plate_reads,
                      self.plate_ocr_calls, self.plate_searches, self.plate_last_attempt_frame):
                d.pop(tid, None)
            self.speed_estimator.forget(tid)
            self.counter.forget(tid)
            self.class_voter.forget(tid)

    # ------------------------------------------------------------------
    def get_stats(self):
        return {
            "total": self.agg_total,
            "by_class": dict(self.agg_by_class),
            "overspeeding": self.agg_overspeeding,
            "wrong_direction": self.agg_wrong_direction,
            # "roi|direction" string keys: tuple keys are not JSON-serialisable
            "by_roi_direction": {f"{r}|{d}": c for (r, d), c in self.agg_by_roi_direction.items()},
            "speed_calibrated": self.speed_calibrated,
        }

    def get_plate_table(self):
        return [
            {
                "track_id": tid,
                "class": r["class"],
                "plate": r["plate"] or "-",
                "speed_kmh": r["speed"] if r["speed"] is not None else "-",
                "overspeed": r["overspeed"],
                "wrong_direction": r["wrong_direction"],
            }
            for tid, r in self.vehicle_records.items()
        ]

    # ------------------------------------------------------------------
    @staticmethod
    def _open_writer(path, fps, size):
        for codec in config.OUTPUT_VIDEO_CODECS:
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*codec), fps, size)
            if writer.isOpened():
                return writer
            writer.release()
        raise RuntimeError(f"Could not open a video writer for {path} with codecs {config.OUTPUT_VIDEO_CODECS}")

    def run_on_video(self, source, output_path=None, frame_callback=None, max_frames=None):
        cap = cv2.VideoCapture(source)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open video source: {source}")

        live = is_live_source(source)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        writer = self._open_writer(output_path, fps, (w, h)) if output_path else None

        t_start, frame_no = time.monotonic(), 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            # Files: frame time. Live feeds: wall clock (processing may be slower than real time).
            timestamp = (time.monotonic() - t_start) if live else frame_no / fps
            frame, stats = self.process_frame(frame, timestamp)
            if writer is not None:
                writer.write(frame)
            if frame_callback is not None:
                frame_callback(frame, stats)
            frame_no += 1
            if max_frames and frame_no >= max_frames:
                break

        cap.release()
        if writer is not None:
            writer.release()
        return self.get_stats()

    # ------------------------------------------------------------------
    def save_report(self, out_dir="."):
        os.makedirs(out_dir, exist_ok=True)
        stats = self.get_stats()
        with open(f"{out_dir}/summary.json", "w") as f:
            json.dump({"stats": stats, "overspeed_events": self.events}, f, indent=2)
        with open(f"{out_dir}/events.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["frame", "track_id", "class", "plate", "speed_kmh",
                                                   "limit_kmh", "speed_calibrated"])
            writer.writeheader()
            writer.writerows(self.events)
        return stats

    def print_summary(self):
        stats = self.get_stats()
        by_class = stats["by_class"]
        print("\n===== Traffic Statistics =====")
        print(f"Total Vehicles: {stats['total']}\n")
        print(f"Cars:        {by_class.get('Car', 0)}")
        print(f"Motorcycles: {by_class.get('Motorcycle', 0)}")
        print(f"Buses:       {by_class.get('Bus', 0)}")
        print(f"Trucks:      {by_class.get('Truck', 0)}\n")
        if not stats["speed_calibrated"] and not config.ALERT_WHEN_UNCALIBRATED:
            print("Overspeeding: not evaluated (speed is uncalibrated - set --distance or calibration points)")
        else:
            print(f"Overspeeding: {stats['overspeeding']}")
        print(f"Wrong-direction: {stats['wrong_direction']}\n")
        if not stats["speed_calibrated"]:
            print("NOTE: speed was UNCALIBRATED - speed/overspeed figures are indicative only.\n")
        if stats["by_roi_direction"]:
            print("===== By Carriageway / Direction =====")
            for key, count in stats["by_roi_direction"].items():
                roi_name, direction = key.split("|")
                print(f"{roi_name} ({direction}): {count}")
        if self.events:
            print("\n===== Overspeed Alerts =====")
            for e in self.events:
                print(f"\n⚠ OVERSPEED DETECTED\nVehicle: {e['plate']}\n"
                      f"Estimated Speed: {e['speed_kmh']} km/h\nLimit: {e['limit_kmh']} km/h")
