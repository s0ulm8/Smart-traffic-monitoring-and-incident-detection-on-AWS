"""Drawing / overlay helpers and small utilities."""

import os
import shutil
import subprocess

import cv2

COLORS = {
    "Car": (60, 180, 75),
    "Motorcycle": (255, 165, 0),
    "Bus": (0, 128, 255),
    "Truck": (200, 50, 200),
    "Vehicle": (200, 200, 200),
}


def _text_bg(frame, text, org, scale=0.5, thickness=1, color=(0, 0, 0), bg=(255, 255, 255)):
    (tw, th), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, thickness)
    x, y = org
    cv2.rectangle(frame, (x, y - th - baseline - 2), (x + tw + 4, y + baseline), bg, -1)
    cv2.putText(frame, text, (x + 2, y - 2), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)


def draw_box(frame, box, cls_name, track_id, plate, speed, overspeed, wrong_direction=False):
    h = frame.shape[0]
    x1, y1, x2, y2 = box
    color = COLORS.get(cls_name, (200, 200, 200))
    if overspeed or wrong_direction:
        color = (0, 0, 255)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

    label = f"#{track_id} {cls_name}"
    if plate:
        label += f" | {plate}"
    if speed is not None:
        label += f" | {speed:.0f} km/h"
    _text_bg(frame, label, (x1, max(y1, 15)), bg=color, color=(255, 255, 255))

    # Tags go under the box, but are pulled up so they always stay inside
    # the frame (they used to be clipped away for vehicles near the bottom).
    tag_y = y2 + 18
    step = 18
    tags = []
    if overspeed:
        tags.append(("OVERSPEED", (0, 0, 255)))
    if wrong_direction:
        tags.append(("WRONG DIRECTION", (0, 0, 200)))
    if tags:
        tag_y = min(tag_y, h - 6 - step * (len(tags) - 1))
        for text, bg in tags:
            _text_bg(frame, text, (x1, tag_y), bg=bg, color=(255, 255, 255))
            tag_y += step


def draw_rois(frame, roi_manager):
    """Draws ROI polygons + counting lines so you can verify them visually."""
    for roi in roi_manager.rois:
        cv2.polylines(frame, [roi.polygon], isClosed=True, color=(255, 0, 255), thickness=2)
        x_min, x_max = int(roi.polygon[:, 0].min()), int(roi.polygon[:, 0].max())
        cv2.line(frame, (x_min, roi.count_line_y), (x_max, roi.count_line_y), (0, 255, 255), 2)
        _text_bg(frame, f"{roi.name} ({roi.direction})", (x_min + 5, roi.count_line_y - 8),
                 bg=(255, 0, 255), color=(255, 255, 255))


def draw_calibration_quad(frame, calibration_points):
    if calibration_points is None:
        return
    pts = [tuple(map(int, p)) for p in calibration_points]
    for i in range(len(pts)):
        cv2.line(frame, pts[i], pts[(i + 1) % len(pts)], (0, 200, 255), 2)


def draw_speed_lines(frame, line_a_y, line_b_y):
    """Two-line speed mode: a speed appears only AFTER a vehicle crosses both of these."""
    w = frame.shape[1]
    for y, name in ((line_a_y, "speed line A"), (line_b_y, "speed line B")):
        cv2.line(frame, (0, y), (w, y), (255, 200, 0), 1)
        cv2.putText(frame, name, (w - 150, y - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 200, 0), 1)


def draw_hud(frame, stats):
    lines = [
        f"Total: {stats['total']}",
        f"Overspeeding: {stats['overspeeding']}",
        f"Wrong-direction: {stats.get('wrong_direction', 0)}",
    ]
    for cls, count in stats["by_class"].items():
        lines.append(f"{cls}: {count}")
    for key, count in stats.get("by_roi_direction", {}).items():
        roi_name, direction = key.split("|")
        lines.append(f"{roi_name} ({direction}): {count}")

    y = 20
    for line in lines:
        _text_bg(frame, line, (10, y), scale=0.55, bg=(30, 30, 30), color=(255, 255, 255))
        y += 22
    if not stats.get("speed_calibrated", True):
        _text_bg(frame, "SPEED UNCALIBRATED - values indicative only", (10, y + 6),
                 scale=0.5, bg=(0, 140, 255), color=(0, 0, 0))


def reencode_h264(path):
    """Re-encode to browser-playable H.264 if ffmpeg is installed. Returns True on success."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg or not os.path.exists(path):
        return False
    tmp = path + ".h264.mp4"
    cmd = [ffmpeg, "-y", "-loglevel", "error", "-i", path, "-c:v", "libx264", "-preset", "veryfast",
           "-crf", "23", "-pix_fmt", "yuv420p", "-movflags", "+faststart", tmp]
    try:
        subprocess.run(cmd, check=True)
        os.replace(tmp, path)
        return True
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        return False
