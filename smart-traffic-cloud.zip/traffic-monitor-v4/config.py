"""Central configuration for the traffic monitoring pipeline.

Anything geometry-dependent (ROAD_ROIS, calibration points, speed limit) can
also be supplied per camera via a JSON scene file: `python main.py --scene scenes/x.json`.
"""

# ---- Detection ----------------------------------------------------------
MODEL_PATH = "yolov8n.pt"
CONF_THRESHOLD = 0.35
USE_GPU = False            # applies to BOTH the YOLO detector and EasyOCR
YOLO_IMGSZ = 640           # raise (960/1280) to catch small distant vehicles; slower

VEHICLE_CLASSES = {
    2: "Car",
    3: "Motorcycle",
    5: "Bus",
    7: "Truck",
}

# Detections smaller than this are dropped before tracking: persistent
# low-confidence blips on static background clutter never disappear by
# themselves, and a vehicle this small is unusable for class/plate anyway.
MIN_VEHICLE_BOX_HEIGHT_PX = 35
MIN_VEHICLE_BOX_AREA_PX = 1200

# ---- Number plates -------------------------------------------------------
PLATE_MODEL_PATH = None            # dedicated plate-detector .pt (strongly recommended)
PLATE_CONF_THRESHOLD = 0.3
PLATE_MIN_OCR_CONFIDENCE = 0.35    # whole-plate confidence needed to accept a read
PLATE_MIN_FRAGMENT_CONFIDENCE = 0.30   # ignore OCR text fragments below this
PLATE_MIN_ASPECT = 1.8             # plate crops must be wider than tall (w/h in this range)
PLATE_MAX_ASPECT = 6.5
PLATE_REGEX = r"^[A-Z0-9]{4,10}$"  # tighten to your country's format

# Plate search/OCR is only attempted once the vehicle is at least this wide:
# below that the plate is a few pixels and cannot be read, and trying only
# wastes the OCR budget before the vehicle gets close.
PLATE_MIN_VEHICLE_WIDTH_PX = 90
OCR_ATTEMPT_INTERVAL_FRAMES = 4        # min frames between attempts per vehicle
MAX_OCR_ATTEMPTS_PER_VEHICLE = 20      # OCR calls (a plate crop was found)
MAX_PLATE_SEARCHES_PER_VEHICLE = 150   # plate-detector calls (hard compute bound)
PLATE_MIN_ACCEPTED_READS = 3           # reads collected before the plate is final

# ---- Speed ---------------------------------------------------------------
# Preferred: homography calibration - 4+ pixel points of a known road
# rectangle and their real-world metres (corrects perspective).
CALIBRATION_SRC_POINTS = None      # e.g. [(400,500),(880,500),(950,700),(300,700)]
CALIBRATION_DST_POINTS = None      # e.g. [(0,0),(3.5,0),(3.5,15),(0,15)]
# Fallback: two virtual lines a MEASURED real distance apart. The default
# below is only a placeholder - speeds are NOT meaningful until you set the
# real distance for your camera (main.py --distance / scene file).
# Place the lines where vehicles are ALREADY detected: small far-away cars are only found
# lower in the frame, and a car that first appears between the lines never crosses line A.
SPEED_LINE_A_RATIO = 0.62
SPEED_LINE_B_RATIO = 0.88
SPEED_CALIB_DISTANCE_M = 15.0

# Overspeed ALERTS need a real calibration. With the placeholder distance, speeds can be off by
# a large factor (on the highway clip nearly every car was flagged), so alerts are suppressed
# until a measured distance / calibration points are supplied. Set True only for demos.
ALERT_WHEN_UNCALIBRATED = False
SPEED_LIMIT_KMH = 50
SPEED_SMOOTHING_WINDOW = 8         # frames of trajectory in the speed fit
SPEED_MIN_POINTS = 5               # points needed before a speed is reported
SPEED_MAX_PLAUSIBLE_KMH = 250      # readings above this are treated as tracking glitches

# An overspeed alert needs this many consecutive FRESH readings above
# limit + tolerance (one-shot two-line mode uses a timing-error lower bound).
OVERSPEED_CONFIRM_FRAMES = 6
OVERSPEED_TOLERANCE_KMH = 0.0

# ---- Counting ------------------------------------------------------------
ROAD_ROIS = None                   # see roi.py / scenes/*.json
COUNT_LINE_RATIO = 0.80            # only used when ROAD_ROIS is None
# A crossing registers only when the ground point moves from more than this
# many px on one side of the line to more than this many px on the other, so
# detector jitter on a stopped vehicle can never count it.
COUNT_LINE_HYSTERESIS_PX = 6

# ---- Tracking stability --------------------------------------------------
TRACK_LOST_MAX_FRAMES = 20
TRACK_MATCH_MAX_DIST_PX = 80
TRACK_MATCH_MIN_HIST_SIM = 0.55
TRACK_MATCH_MIN_AREA_RATIO = 0.4   # new/old box area ratio must lie in [r, 1/r]
TRACK_EXIT_MARGIN_PX = 12          # lost near a frame edge => it LEFT the scene, don't merge
TRACK_MEMORY_FRAMES = 300          # merger forgets raw IDs unseen this long
MIN_CONFIRM_FRAMES = 3             # total sightings before a track is drawn/counted
CLASS_VOTE_MIN_MARGIN = 2

# ---- Housekeeping / output ------------------------------------------------
RECORD_EXPIRY_FRAMES = 300
OUTPUT_VIDEO_CODECS = ["avc1", "mp4v"]   # tried in order (avc1 = browser-playable H.264)
