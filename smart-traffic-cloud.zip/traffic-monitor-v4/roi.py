"""
Road ROIs (Regions of Interest): each carriageway / lane-group is a pixel
polygon with its own counting line and expected direction. A vehicle is only
counted when its ground point is inside an ROI, against THAT ROI's line.

Inputs are validated up front so a config typo fails loudly with a clear
message instead of silently mislabelling every vehicle.
"""

import cv2
import numpy as np

import config

VALID_DIRECTIONS = ("up", "down", "both")


class RoadROI:
    def __init__(self, name, polygon, direction, count_line_y):
        direction = str(direction).strip().lower()
        if direction not in VALID_DIRECTIONS:
            raise ValueError(
                f"ROI '{name}': direction must be one of {VALID_DIRECTIONS}, got {direction!r}"
            )
        if polygon is None or len(polygon) < 3:
            raise ValueError(f"ROI '{name}': polygon needs at least 3 points")
        poly = np.array(polygon, dtype=np.int32)
        if poly.ndim != 2 or poly.shape[1] != 2:
            raise ValueError(f"ROI '{name}': polygon must be a list of (x, y) points")
        y_min, y_max = int(poly[:, 1].min()), int(poly[:, 1].max())
        if not (y_min <= count_line_y <= y_max):
            raise ValueError(
                f"ROI '{name}': count_line_y={count_line_y} is outside the polygon's "
                f"vertical extent [{y_min}, {y_max}] - vehicles could never cross it"
            )
        self.name = name
        self.polygon = poly
        self.direction = direction          # "down", "up" or "both"
        self.count_line_y = int(count_line_y)

    def contains(self, point):
        return cv2.pointPolygonTest(self.polygon, (float(point[0]), float(point[1])), False) >= 0


class RoadROIManager:
    def __init__(self, frame_w, frame_h, roi_defs=None):
        if roi_defs is None:
            roi_defs = config.ROAD_ROIS          # resolved at call time, not import time
        self.rois = []

        if roi_defs:
            names = [d["name"] for d in roi_defs]
            if len(set(names)) != len(names):
                raise ValueError(f"ROI names must be unique, got {names}")
            for d in roi_defs:
                self.rois.append(RoadROI(d["name"], d["polygon"], d["direction"], d["count_line_y"]))
        else:
            # Zero-config fallback: one whole-frame ROI, both directions.
            whole = [(0, 0), (frame_w, 0), (frame_w, frame_h), (0, frame_h)]
            self.rois.append(RoadROI("default", whole, "both", int(frame_h * config.COUNT_LINE_RATIO)))

    def assign(self, point):
        """The ROI containing this point, or None (median, verge, sky...)."""
        for roi in self.rois:
            if roi.contains(point):
                return roi
        return None

    def is_configured(self):
        return len(self.rois) != 1 or self.rois[0].name != "default"
