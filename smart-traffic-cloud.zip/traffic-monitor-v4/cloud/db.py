"""Database models (SQLAlchemy 2.0). SQLite locally, PostgreSQL (RDS) on AWS."""

import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

from sqlalchemy import (JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        create_engine, event)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy.pool import StaticPool


def utcnow():
    return datetime.now(timezone.utc)


def new_id():
    return uuid.uuid4().hex


class Base(DeclarativeBase):
    pass


class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    kind: Mapped[str] = mapped_column(String(16))                 # upload | stream
    name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(16), index=True, default="queued")
    # queued | running | completed | failed | stopped
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    frames_processed: Mapped[int] = mapped_column(Integer, default=0)
    total_frames: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    stats: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    input_key: Mapped[str | None] = mapped_column(String(255), nullable=True)
    video_key: Mapped[str | None] = mapped_column(String(255), nullable=True)
    instance_id: Mapped[str] = mapped_column(String(64), default="local")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    heartbeat_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TrafficStat(Base):
    __tablename__ = "traffic_stats"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    t_sec: Mapped[float] = mapped_column(Float)
    frame: Mapped[int] = mapped_column(Integer)
    total: Mapped[int] = mapped_column(Integer)                   # vehicles counted so far
    vehicles_visible: Mapped[int] = mapped_column(Integer)        # on the road right now
    congestion: Mapped[str] = mapped_column(String(10))           # free | moderate | heavy
    slow_fraction: Mapped[float] = mapped_column(Float, default=0.0)
    by_class: Mapped[dict] = mapped_column(JSON, default=dict)


class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(32), index=True)
    # stopped_vehicle | congestion | congestion_cleared | overspeed | wrong_direction
    severity: Mapped[str] = mapped_column(String(10))             # info | low | high
    t_sec: Mapped[float] = mapped_column(Float)
    frame: Mapped[int] = mapped_column(Integer)
    track_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    snapshot_key: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


Index("ix_jobs_created", Job.created_at)


class Database:
    def __init__(self, url, ssl=False):
        kwargs = {"pool_pre_ping": True}
        if url.startswith("sqlite"):
            kwargs["connect_args"] = {"check_same_thread": False}
            if ":memory:" in url:
                kwargs["poolclass"] = StaticPool
        else:
            kwargs.update(pool_size=5, max_overflow=5, pool_recycle=1800)
            if ssl:
                kwargs["connect_args"] = {"sslmode": "require"}   # RDS: encrypted in transit
        self.engine = create_engine(url, **kwargs)
        if url.startswith("sqlite"):
            @event.listens_for(self.engine, "connect")
            def _fk(conn, _):
                conn.execute("PRAGMA foreign_keys=ON")
        self._Session = sessionmaker(self.engine, expire_on_commit=False)

    def create_all(self, attempts=5):
        """Several instances can start at once and race to create tables: retry."""
        for i in range(attempts):
            try:
                Base.metadata.create_all(self.engine)
                return
            except Exception:
                if i == attempts - 1:
                    raise
                time.sleep(2)

    @contextmanager
    def session(self):
        s = self._Session()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()
