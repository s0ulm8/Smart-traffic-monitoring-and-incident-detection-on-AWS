"""FastAPI application.

    uvicorn cloud.app:create_app --factory --host 0.0.0.0 --port 8000
"""

import json
import logging
import mimetypes
import shutil
from contextlib import asynccontextmanager
from datetime import timezone
from pathlib import Path
from urllib.parse import urlparse

import cv2
from fastapi import APIRouter, Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select, text

from scene import load_scene

from . import security
from .aws_hooks import AwsHooks
from .db import Database, Incident, Job, TrafficStat, new_id
from .jobs import ACTIVE, JobManager
from .monitor import default_monitor_factory, validate_scene
from .settings import Settings
from .storage import LocalStorage, make_storage

log = logging.getLogger("cloud.app")
STATIC_DIR = Path(__file__).parent / "static"
ALLOWED_EXT = (".mp4", ".avi", ".mov", ".mkv")
MAX_SCENE_BYTES = 64 * 1024


def _iso(dt):
    if dt is None:
        return None
    return (dt.replace(tzinfo=None).isoformat() + "Z") if dt.tzinfo is None else dt.astimezone(timezone.utc).isoformat()


def _display_name(name):
    name = Path(name or "video").name
    return ("".join(c for c in name if c.isprintable()) or "video")[:200]


def _safe_stream_label(url):
    """Show host + path only: never echo credentials embedded in a stream URL."""
    p = urlparse(url)
    return f"{p.scheme}://{p.hostname}{':' + str(p.port) if p.port else ''}{p.path}"[:200]


class StreamRequest(BaseModel):
    url: str = Field(max_length=2048)
    speed_limit_kmh: float = Field(50, ge=5, le=300)
    line_distance_m: float | None = Field(None, gt=0, le=1000)
    enable_ocr: bool = True


def create_app(settings=None, monitor_factory=None, storage=None, db=None, hooks=None):
    settings = settings or Settings.from_env()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    Path(settings.work_dir).mkdir(parents=True, exist_ok=True)
    if settings.database_url.startswith("sqlite:///") and ":memory:" not in settings.database_url:
        Path(settings.database_url.replace("sqlite:///", "", 1)).parent.mkdir(parents=True, exist_ok=True)

    db = db or Database(settings.database_url, ssl=settings.db_ssl)
    storage = storage or make_storage(settings)
    hooks = hooks or AwsHooks(settings)
    manager = JobManager(settings, db, storage, monitor_factory or default_monitor_factory(settings), hooks)

    @asynccontextmanager
    async def lifespan(app):
        db.create_all()
        manager.start()
        log.info("started: storage=%s db=%s workers=%d", "s3" if settings.s3_bucket else "local",
                 db.engine.url.get_backend_name(), settings.max_workers)
        yield
        manager.shutdown()

    app = FastAPI(title="Smart Traffic Monitoring", lifespan=lifespan, docs_url=None, redoc_url=None)
    app.state.settings, app.state.db, app.state.storage, app.state.manager = settings, db, storage, manager

    # ---- middleware --------------------------------------------------------
    @app.middleware("http")
    async def guard(request: Request, call_next):
        if request.url.path == "/api/jobs/upload":
            declared = request.headers.get("content-length")
            if declared and declared.isdigit() and int(declared) > settings.max_upload_mb * 1024 * 1024 + 2 * 1024 * 1024:
                return JSONResponse({"detail": f"File too large (limit {settings.max_upload_mb} MB)"}, status_code=413)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: https://*.amazonaws.com; "
            "media-src 'self' https://*.amazonaws.com; script-src 'self'; style-src 'self'; "
            "connect-src 'self'; frame-ancestors 'none'")
        return response

    # ---- serializers ---------------------------------------------------------
    def job_dict(job, detail=False):
        d = {"id": job.id, "kind": job.kind, "name": job.name, "status": job.status,
             "cancel_requested": job.cancel_requested, "progress": job.progress,
             "frames_processed": job.frames_processed, "total_frames": job.total_frames,
             "error": job.error, "stats": job.stats, "instance_id": job.instance_id,
             "created_at": _iso(job.created_at), "started_at": _iso(job.started_at),
             "finished_at": _iso(job.finished_at)}
        if detail:
            d["video_url"] = storage.url(job.video_key) if job.video_key else None
            d["input_url"] = storage.url(job.input_key) if job.input_key else None
        return d

    def get_job(session, job_id):
        job = session.get(Job, job_id)
        if job is None:
            raise HTTPException(404, "Job not found")
        return job

    def check_capacity():
        if manager.pending_count() >= settings.max_pending_jobs:
            raise HTTPException(429, "This server already has the maximum number of queued/running jobs; try again shortly")

    # ---- public routes ----------------------------------------------------------
    @app.get("/health")
    def health():
        return {"status": "ok"}                       # liveness only: must NOT depend on the database

    @app.get("/health/deep")
    def health_deep():
        try:
            with db.session() as s:
                s.execute(text("SELECT 1"))
            return {"status": "ok", "database": "ok"}
        except Exception:
            return JSONResponse({"status": "degraded", "database": "unreachable"}, status_code=503)

    @app.get("/")
    def index():
        return FileResponse(STATIC_DIR / "index.html")

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/files/{key:path}")
    def local_file(key: str, exp: int = 0, sig: str = ""):
        if not isinstance(storage, LocalStorage) or not security.verify(key, exp, sig, settings.signing_secret):
            raise HTTPException(404, "Not found")
        path = storage.resolve(key)
        if path is None or not path.is_file():
            raise HTTPException(404, "Not found")
        return FileResponse(path, media_type=mimetypes.guess_type(str(path))[0] or "application/octet-stream",
                            headers={"Cache-Control": "private, max-age=300"})

    # ---- authenticated API -----------------------------------------------------------
    api = APIRouter(prefix="/api", dependencies=[Depends(security.make_api_key_dependency(settings))])

    @api.get("/config")
    def get_config():
        return {"max_upload_mb": settings.max_upload_mb, "storage": "s3" if settings.s3_bucket else "local",
                "default_enable_ocr": settings.default_enable_ocr}

    @api.post("/jobs/upload", status_code=202)
    def upload_job(file: UploadFile = File(...), scene: UploadFile | None = File(None),
                   speed_limit_kmh: float = Form(50, ge=5, le=300),
                   line_distance_m: float | None = Form(None, gt=0, le=1000),
                   enable_ocr: bool = Form(True)):
        check_capacity()
        name = _display_name(file.filename)
        ext = Path(name).suffix.lower()
        if ext not in ALLOWED_EXT:
            raise HTTPException(400, f"Unsupported file type '{ext}'. Allowed: {', '.join(ALLOWED_EXT)}")

        job = Job(id=new_id(), kind="upload", name=name, status="queued", instance_id=settings.instance_id)
        work = Path(settings.work_dir) / job.id
        work.mkdir(parents=True, exist_ok=True)
        try:
            video_path = work / f"input{ext}"
            limit, size = settings.max_upload_mb * 1024 * 1024, 0
            with open(video_path, "wb") as out:
                while chunk := file.file.read(1024 * 1024):
                    size += len(chunk)
                    if size > limit:
                        raise HTTPException(413, f"File too large (limit {settings.max_upload_mb} MB)")
                    out.write(chunk)
            if size == 0:
                raise HTTPException(400, "The uploaded file is empty")

            cap = cv2.VideoCapture(str(video_path))
            readable, frame = (cap.read() if cap.isOpened() else (False, None))
            w, h = (frame.shape[1], frame.shape[0]) if readable else (0, 0)
            cap.release()
            if not readable:
                raise HTTPException(400, "The file could not be read as a video")

            params = {"speed_limit_kmh": speed_limit_kmh, "line_distance_m": line_distance_m,
                      "enable_ocr": enable_ocr, "local_path": str(video_path)}
            if scene is not None and scene.filename:
                raw = scene.file.read(MAX_SCENE_BYTES + 1)
                if len(raw) > MAX_SCENE_BYTES:
                    raise HTTPException(400, "Scene file is too large")
                scene_path = work / "scene.json"
                scene_path.write_bytes(raw)
                try:
                    json.loads(raw)
                    validate_scene(load_scene(str(scene_path)), w, h)
                except (ValueError, KeyError, TypeError) as exc:      # JSONDecodeError is a ValueError
                    raise HTTPException(400, f"Invalid scene file: {exc}")
                params["scene_path"] = str(scene_path)
            job.params = params
            with db.session() as s:
                s.add(job)
        except BaseException:
            shutil.rmtree(work, ignore_errors=True)
            raise
        manager.submit(job.id)
        return job_dict(job)

    @api.post("/jobs/stream", status_code=202)
    def stream_job(req: StreamRequest):
        check_capacity()
        try:
            url = security.validate_stream_url(req.url, settings.allow_private_streams)
        except ValueError as exc:
            raise HTTPException(400, f"Stream URL rejected: {exc}")
        job = Job(id=new_id(), kind="stream", name=_safe_stream_label(url), status="queued", instance_id=settings.instance_id,
                  params={"url": url, "speed_limit_kmh": req.speed_limit_kmh,
                          "line_distance_m": req.line_distance_m, "enable_ocr": req.enable_ocr})
        with db.session() as s:
            s.add(job)
        manager.submit(job.id)
        return job_dict(job)

    @api.get("/jobs")
    def list_jobs(limit: int = 50):
        with db.session() as s:
            rows = s.scalars(select(Job).order_by(Job.created_at.desc()).limit(max(1, min(limit, 200)))).all()
            return [job_dict(j) for j in rows]

    @api.get("/jobs/{job_id}")
    def job_detail(job_id: str):
        with db.session() as s:
            return job_dict(get_job(s, job_id), detail=True)

    @api.get("/jobs/{job_id}/stats")
    def job_stats(job_id: str, limit: int = 2000):
        with db.session() as s:
            get_job(s, job_id)
            rows = s.scalars(select(TrafficStat).where(TrafficStat.job_id == job_id)
                             .order_by(TrafficStat.t_sec, TrafficStat.id).limit(max(1, min(limit, 5000)))).all()
            return [{"t_sec": r.t_sec, "frame": r.frame, "total": r.total, "vehicles_visible": r.vehicles_visible,
                     "congestion": r.congestion, "slow_fraction": r.slow_fraction, "by_class": r.by_class}
                    for r in rows]

    @api.get("/jobs/{job_id}/incidents")
    def job_incidents(job_id: str, type: str | None = None, limit: int = 500):
        with db.session() as s:
            get_job(s, job_id)
            q = select(Incident).where(Incident.job_id == job_id)
            if type:
                q = q.where(Incident.type == type)
            rows = s.scalars(q.order_by(Incident.t_sec, Incident.id).limit(max(1, min(limit, 1000)))).all()
            return [{"id": r.id, "type": r.type, "severity": r.severity, "t_sec": r.t_sec, "frame": r.frame,
                     "track_id": r.track_id, "details": r.details,
                     "snapshot_url": storage.url(r.snapshot_key) if r.snapshot_key else None} for r in rows]

    @api.post("/jobs/{job_id}/stop")
    def stop_job(job_id: str):
        with db.session() as s:
            job = get_job(s, job_id)
            if job.status not in ACTIVE:
                raise HTTPException(409, f"Job is already {job.status}")
            job.cancel_requested = True             # the owning worker polls this flag
            return job_dict(job)

    @api.delete("/jobs/{job_id}", status_code=204)
    def delete_job(job_id: str):
        with db.session() as s:
            job = get_job(s, job_id)
            if job.status in ACTIVE:
                raise HTTPException(409, "Stop the job before deleting it")
            s.execute(delete(Incident).where(Incident.job_id == job_id))
            s.execute(delete(TrafficStat).where(TrafficStat.job_id == job_id))
            s.delete(job)
        storage.delete_prefix(f"jobs/{job_id}/")

    @api.get("/summary")
    def summary():
        with db.session() as s:
            by_status = dict(s.execute(select(Job.status, func.count()).group_by(Job.status)).all())
            incidents = dict(s.execute(select(Incident.type, func.count()).group_by(Incident.type)).all())
            stats = s.scalars(select(Job.stats).where(Job.status.in_(("completed", "stopped")))
                              .order_by(Job.created_at.desc()).limit(1000)).all()
        return {"jobs_by_status": by_status, "incidents_by_type": incidents,
                "vehicles_counted": sum((st or {}).get("total", 0) for st in stats)}

    app.include_router(api)
    return app
