"""Congestion and stopped-vehicle detection.

Pure logic, no OpenCV: it is fed, once per frame, the confirmed vehicles that
are on the road (inside an ROI) and returns the congestion state plus any NEW
incidents. Everything is time-based (seconds), so it behaves the same at any
frame rate or when frames are skipped.

All thresholds are HEURISTICS - tune them on your own camera footage
(IncidentConfig below). Movement is measured relative to the vehicle's own box
height, so the same thresholds work for near and far vehicles.

STOPPED VEHICLE
    A vehicle whose ground point stays within `stop_move_frac` x box-height
    (min `stop_move_min_px`) of an anchor position for `stopped_seconds`.
    Moving away from the anchor resets the timer. If congestion is
    moderate/heavy at that moment the incident is tagged in_queue=True and has
    severity "low" (queued traffic is expected); otherwise "high".

CONGESTION
    Per frame: n = vehicles on the road, slow_fraction = share of them moving
    slower than `slow_body_lengths_per_s`. free / moderate / heavy by the
    thresholds below. A new level must hold for `level_hold_seconds` before it
    is adopted, so single noisy frames do not flip it.
"""

import math
from collections import deque
from dataclasses import dataclass, field


@dataclass
class IncidentConfig:
    # stopped vehicle
    stopped_seconds: float = 8.0
    stop_move_frac: float = 0.25          # of box height
    stop_move_min_px: float = 6.0
    forget_seconds: float = 3.0           # a track unseen this long loses its history
    # per-vehicle speed (for congestion)
    speed_window_seconds: float = 1.0
    min_speed_span_seconds: float = 0.5
    slow_body_lengths_per_s: float = 0.7  # ~4 km/h for a car
    # congestion levels
    moderate_vehicles: int = 4
    moderate_slow_fraction: float = 0.5
    heavy_vehicles: int = 8
    heavy_slow_fraction: float = 0.7
    level_hold_seconds: float = 3.0


@dataclass
class Incident:
    type: str
    severity: str
    t_sec: float
    track_id: int | None = None
    details: dict = field(default_factory=dict)


@dataclass
class CongestionState:
    level: str = "free"
    vehicles: int = 0
    slow_fraction: float = 0.0


_ORDER = {"free": 0, "moderate": 1, "heavy": 2}


class _Track:
    __slots__ = ("anchor", "anchor_t", "last_t", "flagged", "trail")

    def __init__(self, x, y, t, window):
        self.anchor, self.anchor_t, self.last_t = (x, y), t, t
        self.flagged = False
        self.trail = deque()             # (t, x, y, box_h) over speed_window_seconds


class IncidentDetector:
    def __init__(self, config=None):
        self.cfg = config or IncidentConfig()
        self.tracks = {}
        self.state = CongestionState()
        self._candidate, self._candidate_since = "free", None

    # ------------------------------------------------------------------
    def update(self, t, vehicles):
        """vehicles: list of dicts {tid, x, y, box_h}  (x, y = ground point).
        Returns (CongestionState, [Incident])."""
        cfg, incidents = self.cfg, []
        seen = set()
        speeds = []

        for v in vehicles:
            tid, x, y, box_h = v["tid"], v["x"], v["y"], max(float(v["box_h"]), 1.0)
            seen.add(tid)
            tr = self.tracks.get(tid)
            if tr is not None and t - tr.last_t > cfg.forget_seconds:
                tr = None                                   # gap too long: start over
            if tr is None:
                tr = self.tracks[tid] = _Track(x, y, t, cfg.speed_window_seconds)
            tr.last_t = t

            # motion trail -> normalised speed
            tr.trail.append((t, x, y, box_h))
            while tr.trail and t - tr.trail[0][0] > cfg.speed_window_seconds:
                tr.trail.popleft()
            t0, x0, y0, h0 = tr.trail[0]
            span = t - t0
            if span >= cfg.min_speed_span_seconds:
                speeds.append(math.hypot(x - x0, y - y0) / max(h0, box_h) / span)

            # stopped-vehicle logic
            moved = math.hypot(x - tr.anchor[0], y - tr.anchor[1])
            if moved > max(cfg.stop_move_min_px, cfg.stop_move_frac * box_h):
                tr.anchor, tr.anchor_t, tr.flagged = (x, y), t, False
            elif not tr.flagged and t - tr.anchor_t >= cfg.stopped_seconds:
                tr.flagged = True
                incidents.append(Incident(
                    "stopped_vehicle", "pending", t, tid,
                    {"stopped_for_s": round(t - tr.anchor_t, 1), "x": int(x), "y": int(y)}))

        # forget tracks not seen for a while (bounded memory)
        for tid in [k for k, tr in self.tracks.items() if k not in seen and t - tr.last_t > cfg.forget_seconds]:
            del self.tracks[tid]

        # congestion
        n = len(vehicles)
        slow = sum(1 for s in speeds if s < cfg.slow_body_lengths_per_s)
        frac = slow / len(speeds) if speeds else 0.0
        if n >= cfg.heavy_vehicles and frac >= cfg.heavy_slow_fraction:
            raw = "heavy"
        elif n >= cfg.moderate_vehicles and frac >= cfg.moderate_slow_fraction:
            raw = "moderate"
        else:
            raw = "free"

        if raw == self.state.level:
            self._candidate, self._candidate_since = raw, None
        else:
            if raw != self._candidate or self._candidate_since is None:
                self._candidate, self._candidate_since = raw, t
            if t - self._candidate_since >= cfg.level_hold_seconds:
                previous = self.state.level
                self.state.level = raw
                self._candidate_since = None
                if raw == "free":
                    incidents.append(Incident("congestion_cleared", "info", t, None, {"previous": previous}))
                else:
                    incidents.append(Incident(
                        "congestion", "high" if raw == "heavy" else "low", t, None,
                        {"level": raw, "vehicles": n, "slow_fraction": round(frac, 2)}))
        self.state.vehicles, self.state.slow_fraction = n, round(frac, 2)

        # severity for stopped vehicles depends on the (just updated) congestion level
        for inc in incidents:
            if inc.type == "stopped_vehicle":
                queued = _ORDER[self.state.level] > 0
                inc.details["in_queue"] = queued
                inc.severity = "low" if queued else "high"
        return self.state, incidents

    def stopped_ids(self):
        return {tid for tid, tr in self.tracks.items() if tr.flagged}
