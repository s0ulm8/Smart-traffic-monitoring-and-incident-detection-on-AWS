"""CloudMonitor: your v4 TrafficMonitor + congestion / stopped-vehicle incidents.

It SUBCLASSES TrafficMonitor (v4 files are untouched). A thin proxy around the
track merger captures each frame's detections (with their stable canonical
IDs); the confirmed ones that are on the road feed the IncidentDetector.
Overspeed events and wrong-direction vehicles from v4 are turned into
incidents as well, so the dashboard shows one unified list.
"""

import time
from collections import Counter

import utils
from processor import TrafficMonitor
from roi import RoadROIManager
from speed_estimator import HomographySpeedEstimator

import config
from .incidents import CongestionState, Incident, IncidentConfig, IncidentDetector

_LEVEL_COLOR = {"free": (60, 160, 60), "moderate": (0, 165, 255), "heavy": (0, 0, 220)}


class _MergerProxy:
    def __init__(self, inner):
        self._inner = inner
        self.last = []

    def update(self, frame, detections, frame_idx):
        self.last = self._inner.update(frame, detections, frame_idx)
        return self.last

    def __getattr__(self, name):
        return getattr(self._inner, name)


class CloudMonitor(TrafficMonitor):
    def __init__(self, *args, incident_config=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._merger_proxy = _MergerProxy(self.track_merger)
        self.track_merger = self._merger_proxy
        self.incident_detector = IncidentDetector(incident_config or IncidentConfig())
        self.congestion = CongestionState()
        self.new_incidents = []            # incidents raised by the LAST process_frame call
        self.incident_counts = Counter()
        self._events_seen = 0
        self._wrong_dir_seen = set()

    def process_frame(self, frame, timestamp=None):
        if timestamp is None:
            timestamp = time.time()
        frame, stats = super().process_frame(frame, timestamp)

        road_vehicles = []
        for det in self._merger_proxy.last:
            tid = det["canonical_id"]
            if self.hit_count.get(tid, 0) < config.MIN_CONFIRM_FRAMES:
                continue                                    # unconfirmed = probably noise
            x1, y1, x2, y2 = det["box"]
            gx, gy = (x1 + x2) / 2, y2
            if self.roi_manager.assign((gx, gy)) is None:
                continue                                    # not on a carriageway
            road_vehicles.append({"tid": tid, "x": gx, "y": gy, "box_h": y2 - y1, "box": det["box"]})

        self.congestion, found = self.incident_detector.update(timestamp, road_vehicles)
        self.new_incidents = []
        for inc in found:
            self._add(inc)

        # v4 events -> incidents
        for e in self.events[self._events_seen:]:
            self._add(Incident("overspeed", "high", timestamp, e["track_id"],
                               {"speed_kmh": e["speed_kmh"], "limit_kmh": e["limit_kmh"],
                                "class": e["class"], "speed_calibrated": e["speed_calibrated"]}))
        self._events_seen = len(self.events)
        for tid in self.counter.wrong_direction_ids - self._wrong_dir_seen:
            self._add(Incident("wrong_direction", "high", timestamp, tid, {}))
        self._wrong_dir_seen = set(self.counter.wrong_direction_ids)
        for inc in self.new_incidents:
            if inc.type == "stopped_vehicle":
                inc.details.setdefault("class", self.vehicle_records.get(inc.track_id, {}).get("class"))

        self._draw_overlay(frame, road_vehicles)
        return frame, stats

    def _add(self, inc):
        self.new_incidents.append(inc)
        self.incident_counts[inc.type] += 1

    def _draw_overlay(self, frame, road_vehicles):
        stopped = self.incident_detector.stopped_ids()
        for v in road_vehicles:
            if v["tid"] in stopped:
                x1, y1, x2, y2 = v["box"]
                utils._text_bg(frame, "STOPPED", (x1, max(y1 - 22, 15)), bg=(0, 0, 200), color=(255, 255, 255))
        level = self.congestion.level
        text = f"TRAFFIC: {level.upper()}  ({self.congestion.vehicles} on road)"
        utils._text_bg(frame, text, (max(frame.shape[1] - 330, 10), 24), scale=0.6,
                       bg=_LEVEL_COLOR[level], color=(255, 255, 255))

    def get_stats(self):
        stats = super().get_stats()
        stats["congestion_level"] = self.congestion.level
        stats["vehicles_on_road"] = self.congestion.vehicles
        stats["incident_counts"] = dict(self.incident_counts)
        return stats


def validate_scene(scene_kwargs, width, height):
    """Build the geometry objects now so a bad scene file is rejected at upload
    time (HTTP 400) instead of failing the job later."""
    RoadROIManager(width, height, scene_kwargs.get("road_rois"))
    src, dst = scene_kwargs.get("calibration_src_points"), scene_kwargs.get("calibration_dst_points")
    if src or dst:
        HomographySpeedEstimator(src, dst)


def default_monitor_factory(settings):
    def factory(params, scene_kwargs):
        kwargs = dict(scene_kwargs)
        kwargs.setdefault("speed_limit_kmh", float(params.get("speed_limit_kmh", config.SPEED_LIMIT_KMH)))
        if "real_distance_m" not in kwargs and params.get("line_distance_m"):
            kwargs["real_distance_m"] = float(params["line_distance_m"])
            kwargs["distance_is_measured"] = True
        return CloudMonitor(model_path=settings.model_path,
                            enable_ocr=bool(params.get("enable_ocr", True)), **kwargs)
    return factory
