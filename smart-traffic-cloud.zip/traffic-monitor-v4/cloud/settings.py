"""Runtime settings, read from environment variables.

On AWS the secrets (API key, DB password) are NOT passed as environment
variables. The container receives only the secret's ARN and reads the value
from Secrets Manager at start-up using the EC2 instance role.
"""

import json
import logging
import os
import secrets as _secrets
from dataclasses import dataclass, field

log = logging.getLogger("cloud.settings")


def _bool(value, default=False):
    if value is None or value == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on")


@dataclass
class Settings:
    api_key: str = ""                              # empty = auth disabled (local dev only)
    database_url: str = "sqlite:///./data/traffic.db"
    db_ssl: bool = False                           # require TLS (used for RDS)
    s3_bucket: str = ""                            # empty = local disk storage
    aws_region: str = "ap-south-1"
    local_storage_dir: str = "./data/storage"
    work_dir: str = "./data/work"
    max_upload_mb: int = 500
    max_workers: int = 1                           # concurrent jobs per instance (YOLO is CPU-bound)
    max_pending_jobs: int = 5                      # queued + running per instance
    stats_interval_sec: float = 5.0
    stream_max_seconds: int = 3600
    max_snapshots_per_job: int = 200
    default_enable_ocr: bool = True
    model_path: str = "yolov8n.pt"
    instance_id: str = "local"
    asg_name: str = ""                             # set on AWS: enables scale-in protection while jobs run
    cloudwatch_enabled: bool = False
    cloudwatch_namespace: str = "TrafficMonitor"
    signed_url_ttl: int = 3600
    signing_secret: str = field(default_factory=lambda: _secrets.token_hex(32))
    allow_private_streams: bool = False            # NEVER enable on AWS (SSRF guard)
    stale_job_seconds: int = 180

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env
        s = cls()
        s.aws_region = env.get("AWS_REGION", env.get("AWS_DEFAULT_REGION", s.aws_region))
        s.s3_bucket = env.get("S3_BUCKET", "")
        s.local_storage_dir = env.get("LOCAL_STORAGE_DIR", s.local_storage_dir)
        s.work_dir = env.get("WORK_DIR", s.work_dir)
        s.max_upload_mb = int(env.get("MAX_UPLOAD_MB", s.max_upload_mb))
        s.max_workers = max(1, int(env.get("MAX_WORKERS", s.max_workers)))
        s.max_pending_jobs = int(env.get("MAX_PENDING_JOBS", s.max_pending_jobs))
        s.stats_interval_sec = float(env.get("STATS_INTERVAL_SEC", s.stats_interval_sec))
        s.stream_max_seconds = int(env.get("STREAM_MAX_SECONDS", s.stream_max_seconds))
        s.default_enable_ocr = _bool(env.get("ENABLE_OCR"), True)
        s.model_path = env.get("MODEL_PATH", s.model_path)
        s.instance_id = env.get("INSTANCE_ID", "local")
        s.asg_name = env.get("ASG_NAME", "")
        s.cloudwatch_enabled = _bool(env.get("CLOUDWATCH_ENABLED"), False)
        s.cloudwatch_namespace = env.get("CLOUDWATCH_NAMESPACE", s.cloudwatch_namespace)
        s.allow_private_streams = _bool(env.get("ALLOW_PRIVATE_STREAMS"), False)
        s.db_ssl = _bool(env.get("DB_SSL"), False)

        # --- API key: plain env (local) or Secrets Manager (AWS) ----------
        s.api_key = env.get("APP_API_KEY", "")
        key_arn = env.get("API_KEY_SECRET_ARN")
        if key_arn and not s.api_key:
            s.api_key = _read_secret(key_arn, s.aws_region).strip()
        if s.api_key:
            s.signing_secret = s.api_key + ":sign"     # same on every instance behind the ALB
        else:
            log.warning("APP_API_KEY is not set: API authentication is DISABLED (local development only)")

        # --- Database ------------------------------------------------------
        db_arn = env.get("DB_SECRET_ARN")
        if db_arn:
            from sqlalchemy.engine import URL

            creds = json.loads(_read_secret(db_arn, s.aws_region))
            s.database_url = URL.create(
                "postgresql+psycopg2",
                username=creds["username"], password=creds["password"],
                host=env["DB_HOST"], port=int(env.get("DB_PORT", 5432)),
                database=env.get("DB_NAME", "traffic"),
            ).render_as_string(hide_password=False)
            s.db_ssl = True
        else:
            s.database_url = env.get("DATABASE_URL", s.database_url)
        return s


def _read_secret(arn, region):
    import boto3

    client = boto3.client("secretsmanager", region_name=region)
    return client.get_secret_value(SecretId=arn)["SecretString"]
