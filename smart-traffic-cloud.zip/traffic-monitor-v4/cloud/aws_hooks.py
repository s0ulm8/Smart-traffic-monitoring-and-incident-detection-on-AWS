"""Best-effort AWS integrations. Every method swallows errors: monitoring and
scale-in protection must never be able to break video processing."""

import logging

log = logging.getLogger("cloud.aws")


class AwsHooks:
    def __init__(self, settings):
        self.s = settings
        self._cw = self._asg = None
        self._protected = None

    # ---- CloudWatch custom metrics --------------------------------------
    def put_metric(self, name, value=1.0, unit="Count"):
        if not self.s.cloudwatch_enabled:
            return
        try:
            if self._cw is None:
                import boto3
                self._cw = boto3.client("cloudwatch", region_name=self.s.aws_region)
            self._cw.put_metric_data(
                Namespace=self.s.cloudwatch_namespace,
                MetricData=[{"MetricName": name, "Value": float(value), "Unit": unit}])
        except Exception as exc:
            log.warning("CloudWatch put_metric_data failed: %s", exc)

    # ---- Auto Scaling scale-in protection --------------------------------
    def set_scale_in_protection(self, protected):
        """While a job runs, stop the ASG from terminating THIS instance (a
        scale-in would kill the job). Released when the instance is idle."""
        if not (self.s.asg_name and self.s.instance_id.startswith("i-")):
            return
        if self._protected == protected:
            return
        try:
            if self._asg is None:
                import boto3
                self._asg = boto3.client("autoscaling", region_name=self.s.aws_region)
            self._asg.set_instance_protection(
                InstanceIds=[self.s.instance_id], AutoScalingGroupName=self.s.asg_name,
                ProtectedFromScaleIn=protected)
            self._protected = protected
        except Exception as exc:
            log.warning("set_instance_protection failed: %s", exc)
