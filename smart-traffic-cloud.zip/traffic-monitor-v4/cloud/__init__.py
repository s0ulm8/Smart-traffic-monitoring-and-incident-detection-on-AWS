"""Cloud layer for Traffic Monitor v4: API, storage, database, incident detection."""
