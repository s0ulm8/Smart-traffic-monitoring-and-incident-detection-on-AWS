"""Job execution: runs the video pipeline in a worker thread and records
progress, traffic statistics, incidents (with snapshots) and the annotated
video.

Cross-instance design (several EC2 servers share one database):
  * A job is processed by the instance that received it (recorded in
    jobs.instance_id).
  * "Stop" is a database flag (cancel_requested) polled by the worker, so the
    request can arrive at ANY instance behind the load balancer.
  * A maintenance thread heartbeats this instance's jobs and marks jobs whose
    owner stopped heartbeating (instance died / was replaced) as failed.
"""

import logging
import shutil
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2
from sqlalchemy import select, update

from processor import is_live_source
from scene import load_scene
from utils import reencode_h264

from .db import Incident, Job, TrafficStat, utcnow
from .monitor import CloudMonitor

log = logging.getLogger("cloud.jobs")
ACTIVE = ("queued", "running")
PROGRESS_EVERY_FRAMES = 25


class JobInterrupted(Exception):
    pass


def open_capture(source, live):
    if live:
        try:   # don't hang forever on a stalled network stream (needs OpenCV >= 4.5.2)
            return cv2.VideoCapture(source, cv2.CAP_FFMPEG, [
                cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000, cv2.CAP_PROP_READ_TIMEOUT_MSEC, 10000])
        except TypeError:
            pass
    return cv2.VideoCapture(source)


class JobManager:
    def __init__(self, settings, db, storage, monitor_factory, hooks):
        self.s, self.db, self.storage = settings, db, storage
        self.monitor_factory, self.hooks = monitor_factory, hooks
        self.pool = ThreadPoolExecutor(max_workers=settings.max_workers, thread_name_prefix="job")
        self._shutdown = threading.Event()
        self._running = 0
        self._lock = threading.Lock()
        self._maint = None

    # ---- lifecycle -------------------------------------------------------
    def start(self):
        self.recover_orphans()
        self._maint = threading.Thread(target=self._maintenance_loop, daemon=True, name="maintenance")
        self._maint.start()

    def shutdown(self):
        self._shutdown.set()
        self.pool.shutdown(wait=False, cancel_futures=True)

    def recover_orphans(self):
        """Jobs this instance id owned before a restart can never finish."""
        with self.db.session() as s:
            s.execute(update(Job).where(Job.instance_id == self.s.instance_id, Job.status.in_(ACTIVE))
                      .values(status="failed", error="interrupted: the server restarted",
                              finished_at=utcnow()))

    def _maintenance_loop(self, interval=30):
        while not self._shutdown.wait(interval):
            try:
                self.maintenance_once()
            except Exception:
                log.exception("maintenance failed")

    def maintenance_once(self):
        from datetime import timedelta
        now = utcnow()
        with self.db.session() as s:
            s.execute(update(Job).where(Job.instance_id == self.s.instance_id, Job.status.in_(ACTIVE))
                      .values(heartbeat_at=now))
            stale = now - timedelta(seconds=self.s.stale_job_seconds)
            s.execute(update(Job).where(Job.status.in_(ACTIVE), Job.heartbeat_at < stale)
                      .values(status="failed", error="worker lost (its server stopped responding)",
                              finished_at=now))

    def pending_count(self):
        with self.db.session() as s:
            return len(s.scalars(select(Job.id).where(Job.instance_id == self.s.instance_id,
                                                      Job.status.in_(ACTIVE))).all())

    def submit(self, job_id):
        self.pool.submit(self._run_safe, job_id)

    # ---- execution ---------------------------------------------------------
    def _run_safe(self, job_id):
        with self._lock:
            self._running += 1
            self.hooks.set_scale_in_protection(True)
        try:
            self._run(job_id)
        except JobInterrupted as exc:
            self._finish(job_id, "failed", error=str(exc))
        except Exception as exc:
            log.error("job %s failed:\n%s", job_id, traceback.format_exc())
            self._finish(job_id, "failed", error=f"{type(exc).__name__}: {exc}"[:500])
            self.hooks.put_metric("JobsFailed")
        finally:
            shutil.rmtree(Path(self.s.work_dir) / job_id, ignore_errors=True)
            with self._lock:
                self._running -= 1
                if self._running == 0:
                    self.hooks.set_scale_in_protection(False)
                self.hooks.put_metric("JobsRunning", self._running, "Count")

    def _finish(self, job_id, status, error=None, **fields):
        with self.db.session() as s:
            job = s.get(Job, job_id)
            if job is None:
                return
            job.status, job.finished_at = status, utcnow()
            if error:
                job.error = error
            for k, v in fields.items():
                setattr(job, k, v)

    def _cancelled(self, job_id):
        with self.db.session() as s:
            job = s.get(Job, job_id)
            return job is None or job.cancel_requested

    def _run(self, job_id):
        with self.db.session() as s:
            job = s.get(Job, job_id)
            if job is None or job.status != "queued":
                return
            if job.cancel_requested:
                job.status, job.finished_at = "stopped", utcnow()
                return
            job.status, job.started_at, job.heartbeat_at = "running", utcnow(), utcnow()
            kind, params = job.kind, dict(job.params)

        work = Path(self.s.work_dir) / job_id
        scene_kwargs = load_scene(params["scene_path"]) if params.get("scene_path") else {}
        monitor = self.monitor_factory(params, scene_kwargs)

        if kind == "upload":
            source = params["local_path"]
            ext = Path(source).suffix.lower() or ".mp4"
            input_key = f"jobs/{job_id}/input{ext}"
            self.storage.put_file(input_key, source)                 # keep the original video in S3
            with self.db.session() as s:
                s.get(Job, job_id).input_key = input_key
        else:
            source = params["url"]
        live = kind == "stream" and is_live_source(source)

        cap = open_capture(source, live)
        if not cap.isOpened():
            raise RuntimeError("could not open the video source")
        fps = cap.get(cv2.CAP_PROP_FPS)
        fps = fps if (fps and 1 <= fps <= 240) else 25.0
        w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = 0 if live else max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0), 0)
        out_path = work / "annotated.mp4"
        writer = None if live else CloudMonitor._open_writer(str(out_path), fps, (w, h))
        with self.db.session() as s:
            s.get(Job, job_id).total_frames = total_frames

        status = "completed"
        n, snapshots, next_stat = 0, 0, 0.0
        t0 = time.monotonic()
        try:
            while True:
                if self._shutdown.is_set():
                    raise JobInterrupted("interrupted: the server is shutting down")
                ok, frame = cap.read()
                if not ok:
                    break
                t = (time.monotonic() - t0) if live else n / fps
                if live and t > self.s.stream_max_seconds:
                    break
                frame, stats = monitor.process_frame(frame, t)
                if writer is not None:
                    writer.write(frame)

                if monitor.new_incidents:
                    snapshots = self._store_incidents(job_id, monitor, frame, n, snapshots)
                if t >= next_stat:
                    self._store_stat(job_id, monitor, stats, t, n)
                    next_stat = t + self.s.stats_interval_sec
                n += 1
                if n % PROGRESS_EVERY_FRAMES == 0:
                    with self.db.session() as s:
                        job = s.get(Job, job_id)
                        if job is None or job.cancel_requested:
                            status = "stopped"
                            break
                        job.frames_processed, job.heartbeat_at = n, utcnow()
                        job.progress = round(n / total_frames, 4) if total_frames else 0.0
        finally:
            cap.release()
            if writer is not None:
                writer.release()

        # final statistics row + upload of the annotated video
        self._store_stat(job_id, monitor, monitor.get_stats(), n / fps if not live else time.monotonic() - t0, n)
        video_key = None
        if writer is not None and out_path.exists() and out_path.stat().st_size > 0:
            if not reencode_h264(str(out_path)):
                log.warning("ffmpeg not available: annotated video stays mp4v (may not play in browsers)")
            video_key = f"jobs/{job_id}/annotated.mp4"
            self.storage.put_file(video_key, out_path, "video/mp4")
        final = monitor.get_stats()
        final.update(frames_processed=n, processing_seconds=round(time.monotonic() - t0, 1))
        fields = dict(stats=final, video_key=video_key, frames_processed=n)
        if status == "completed":
            fields["progress"] = 1.0
        self._finish(job_id, status, **fields)
        self.hooks.put_metric("JobsCompleted" if status == "completed" else "JobsStopped")
        self.hooks.put_metric("VehiclesCounted", final["total"])

    # ---- persistence helpers --------------------------------------------
    def _store_stat(self, job_id, monitor, stats, t, frame_no):
        with self.db.session() as s:
            s.add(TrafficStat(job_id=job_id, t_sec=round(t, 2), frame=frame_no, total=stats["total"],
                              vehicles_visible=monitor.congestion.vehicles,
                              congestion=monitor.congestion.level,
                              slow_fraction=monitor.congestion.slow_fraction,
                              by_class=stats["by_class"]))

    def _store_incidents(self, job_id, monitor, frame, frame_no, snapshots):
        rows = []
        for inc in monitor.new_incidents:
            key = None
            if inc.severity != "info" and snapshots < self.s.max_snapshots_per_job:
                ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
                if ok:
                    snapshots += 1
                    key = f"jobs/{job_id}/incidents/{snapshots}.jpg"
                    self.storage.put_bytes(key, buf.tobytes(), "image/jpeg")
            rows.append(Incident(job_id=job_id, type=inc.type, severity=inc.severity,
                                 t_sec=round(inc.t_sec, 2), frame=frame_no, track_id=inc.track_id,
                                 details=inc.details, snapshot_key=key))
            self.hooks.put_metric("IncidentsDetected")
        with self.db.session() as s:
            s.add_all(rows)
        return snapshots
