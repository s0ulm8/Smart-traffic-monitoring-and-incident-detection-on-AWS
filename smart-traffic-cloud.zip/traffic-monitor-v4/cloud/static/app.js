"use strict";
// All text from the server is inserted with textContent (never innerHTML): file names,
// stream URLs and error messages are user-controlled.
const $ = (id) => document.getElementById(id);
const state = { key: sessionStorage.getItem("apiKey") || "", selected: null, chart: null, timer: null, jobs: [] };

function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") node.className = v;
    else if (k === "onclick") node.addEventListener("click", v);
    else node[k] = v;
  }
  for (const c of children) node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return node;
}

async function api(path, opts = {}) {
  const res = await fetch(path, { ...opts, headers: { ...(opts.headers || {}), "X-API-Key": state.key } });
  if (res.status === 401) { showBanner("Missing or invalid API key — enter it at the top right."); throw new Error("401"); }
  if (!res.ok) {
    let detail = res.statusText;
    try { const j = await res.json(); detail = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail); } catch (_) {}
    throw new Error(detail);
  }
  hideBanner();
  return res.status === 204 ? null : res.json();
}
function showBanner(t) { const b = $("banner"); b.textContent = t; b.hidden = false; }
function hideBanner() { $("banner").hidden = true; }
const fmtTime = (iso) => (iso ? new Date(iso).toLocaleString() : "—");
const fmtSec = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
const active = (j) => j.status === "queued" || j.status === "running";

function card(value, label) { return el("div", { class: "card" }, el("b", {}, value), el("span", {}, label)); }

// ---------- overview ----------
async function loadOverview() {
  const s = await api("/api/summary");
  const box = $("overview"); box.replaceChildren();
  const by = s.jobs_by_status, inc = s.incidents_by_type;
  box.append(card(Object.values(by).reduce((a, b) => a + b, 0), "jobs"),
             card(by.running || 0, "running now"),
             card(s.vehicles_counted, "vehicles counted"),
             card(inc.stopped_vehicle || 0, "stopped vehicles"),
             card(inc.congestion || 0, "congestion events"),
             card((inc.overspeed || 0) + (inc.wrong_direction || 0), "speed / direction alerts"));
}

// ---------- jobs table ----------
async function loadJobs() {
  state.jobs = await api("/api/jobs");
  const body = $("jobsTable").tBodies[0]; body.replaceChildren();
  for (const j of state.jobs) {
    const pct = j.total_frames ? Math.round(j.progress * 100) : null;
    const prog = active(j) || j.status === "completed"
      ? el("progress", { max: 100, value: pct === null ? undefined : (j.status === "completed" ? 100 : pct) }) : "";
    const actions = el("td");
    actions.append(el("button", { onclick: () => select(j.id) }, "View"), " ");
    if (active(j)) actions.append(el("button", { onclick: () => stopJob(j.id), disabled: j.cancel_requested },
                                      j.cancel_requested ? "Stopping…" : "Stop"));
    else actions.append(el("button", { onclick: () => deleteJob(j.id) }, "Delete"));
    const tr = el("tr", { class: j.id === state.selected ? "selected" : "" },
      el("td", {}, j.name), el("td", {}, j.kind),
      el("td", {}, el("span", { class: `badge s-${j.status}` }, j.status)),
      el("td", {}, prog, pct !== null && active(j) ? ` ${pct}%` : ""),
      el("td", {}, j.stats ? j.stats.total : "—"), el("td", {}, fmtTime(j.created_at)), actions);
    body.append(tr);
  }
}
async function stopJob(id) { try { await api(`/api/jobs/${id}/stop`, { method: "POST" }); } catch (e) { $("formMsg").textContent = e.message; } refresh(); }
async function deleteJob(id) {
  if (!confirm("Delete this job, its video and all its records?")) return;
  try { await api(`/api/jobs/${id}`, { method: "DELETE" }); } catch (e) { $("formMsg").textContent = e.message; }
  if (state.selected === id) { state.selected = null; $("detail").hidden = true; }
  refresh();
}

// ---------- job detail ----------
function select(id) { state.selected = id; $("detail").hidden = false; loadDetail(); loadJobs(); $("detail").scrollIntoView({ behavior: "smooth" }); }
async function loadDetail() {
  const id = state.selected; if (!id) return;
  let job;
  try { job = await api(`/api/jobs/${id}`); } catch (_) { return; }
  const [stats, incs] = await Promise.all([api(`/api/jobs/${id}/stats`), api(`/api/jobs/${id}/incidents`)]);
  $("detailTitle").textContent = `${job.name}  ·  ${job.status}`;
  const err = $("detailError"); err.hidden = !job.error; err.textContent = job.error || "";

  const st = job.stats || {}; const last = stats[stats.length - 1] || {};
  const cards = $("detailCards"); cards.replaceChildren(
    card(st.total ?? last.total ?? 0, "vehicles counted"),
    card(Object.entries(st.by_class || last.by_class || {}).map(([k, v]) => `${k} ${v}`).join(", ") || "—", "by class"),
    card(st.congestion_level || last.congestion || "free", "congestion now"),
    card(last.vehicles_visible ?? 0, "vehicles on road"),
    card(incs.filter((i) => i.severity !== "info").length, "incidents"),
    card(st.processing_seconds ? `${st.processing_seconds}s` : "—", "processing time"));

  const wrap = $("videoWrap");
  if (job.video_url) {
    let v = wrap.querySelector("video");
    if (!v || v.dataset.job !== id) {
      wrap.replaceChildren(); v = el("video", { controls: true, preload: "metadata" }); v.dataset.job = id;
      v.src = job.video_url; wrap.append(v);
    }
  } else { wrap.replaceChildren(); }

  drawChart(stats);

  const body = $("incTable").tBodies[0]; body.replaceChildren();
  for (const i of incs) {
    const d = Object.entries(i.details || {}).map(([k, v]) => `${k}: ${v}`).join(" · ");
    const snap = i.snapshot_url
      ? el("a", { href: i.snapshot_url, target: "_blank", rel: "noopener" }, el("img", { class: "thumb", src: i.snapshot_url, alt: "incident snapshot", loading: "lazy" }))
      : "—";
    body.append(el("tr", {}, el("td", {}, fmtSec(i.t_sec)),
      el("td", {}, i.type.replaceAll("_", " ") + (i.track_id ? ` (#${i.track_id})` : "")),
      el("td", { class: `sev-${i.severity}` }, i.severity), el("td", {}, d || "—"), el("td", {}, snap)));
  }
  if (!incs.length) body.append(el("tr", {}, el("td", { colSpan: 5 }, "No incidents recorded.")));
}

function drawChart(stats) {
  const labels = stats.map((s) => fmtSec(s.t_sec));
  const data = {
    labels,
    datasets: [
      { label: "Vehicles counted (cumulative)", data: stats.map((s) => s.total), borderColor: "#2563eb", yAxisID: "y", tension: 0.2 },
      { label: "Vehicles on road now", data: stats.map((s) => s.vehicles_visible), borderColor: "#f59e0b", yAxisID: "y", tension: 0.2 },
      { label: "Congestion (0 free, 1 moderate, 2 heavy)", data: stats.map((s) => ({ free: 0, moderate: 1, heavy: 2 }[s.congestion] ?? 0)),
        borderColor: "#dc2626", yAxisID: "y1", stepped: true, pointRadius: 0 },
    ],
  };
  if (state.chart && state.chart.canvas.dataset.job === state.selected) {
    state.chart.data = data; state.chart.update("none"); return;
  }
  if (state.chart) state.chart.destroy();
  const canvas = $("trafficChart"); canvas.dataset.job = state.selected;
  state.chart = new Chart(canvas, { type: "line", data, options: {
    responsive: true, maintainAspectRatio: false, animation: false,
    scales: { y: { beginAtZero: true, title: { display: true, text: "vehicles" } },
              y1: { position: "right", min: 0, max: 2, ticks: { stepSize: 1 }, grid: { drawOnChartArea: false } } } } });
}

// ---------- forms ----------
function setTab(upload) {
  $("uploadForm").hidden = !upload; $("streamForm").hidden = upload;
  $("tabUpload").classList.toggle("active", upload); $("tabStream").classList.toggle("active", !upload);
}
$("tabUpload").addEventListener("click", () => setTab(true));
$("tabStream").addEventListener("click", () => setTab(false));

$("keyForm").addEventListener("submit", (e) => {
  e.preventDefault(); state.key = $("keyInput").value.trim(); sessionStorage.setItem("apiKey", state.key);
  $("keyInput").value = ""; refresh();
});

async function submitForm(e, path, build) {
  e.preventDefault();
  const msg = $("formMsg"), btn = e.target.querySelector("button[type=submit]");
  msg.className = "msg"; msg.textContent = "Submitting…"; btn.disabled = true;
  try {
    const job = await api(path, build(e.target));
    msg.textContent = "Job queued."; e.target.reset(); state.selected = job.id; $("detail").hidden = false;
    refresh();
  } catch (err) { msg.className = "msg err"; msg.textContent = err.message; }
  finally { btn.disabled = false; }
}
$("uploadForm").addEventListener("submit", (e) => submitForm(e, "/api/jobs/upload", (f) => {
  const fd = new FormData(f);
  if (!fd.get("line_distance_m")) fd.delete("line_distance_m");
  if (!(fd.get("scene") && fd.get("scene").name)) fd.delete("scene");
  fd.set("enable_ocr", f.elements.enable_ocr.checked ? "true" : "false");
  return { method: "POST", body: fd };
}));
$("streamForm").addEventListener("submit", (e) => submitForm(e, "/api/jobs/stream", (f) => ({
  method: "POST", headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ url: f.elements.url.value.trim(), speed_limit_kmh: Number(f.elements.speed_limit_kmh.value),
                         enable_ocr: f.elements.enable_ocr.checked }) })));

// ---------- polling ----------
async function refresh() {
  if (!state.key) { showBanner("Enter your API key (top right) to begin."); return; }
  try { await Promise.all([loadOverview(), loadJobs(), state.selected ? loadDetail() : null]); } catch (_) {}
  schedule();
}
function schedule() {
  clearTimeout(state.timer);
  const busy = state.jobs.some(active);
  state.timer = setTimeout(() => { if (!document.hidden) refresh(); else schedule(); }, busy ? 2000 : 10000);
}
refresh();
