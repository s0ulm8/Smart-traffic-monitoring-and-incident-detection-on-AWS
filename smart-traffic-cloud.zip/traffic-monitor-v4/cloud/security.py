"""API-key auth, signed local file URLs, and the stream-URL SSRF guard."""

import hashlib
import hmac
import ipaddress
import socket
import time
from urllib.parse import urlparse

from fastapi import Header, HTTPException

ALLOWED_STREAM_SCHEMES = ("rtsp", "rtmp", "http", "https")


def make_api_key_dependency(settings):
    expected = settings.api_key.encode()

    def require_api_key(x_api_key: str = Header(default="")):
        if not expected:
            return                                   # auth disabled (local dev)
        supplied = (x_api_key or "").encode()
        if not hmac.compare_digest(supplied, expected):   # constant-time compare
            raise HTTPException(status_code=401, detail="Missing or invalid API key")

    return require_api_key


# ---- signed URLs for locally stored files (S3 uses presigned URLs instead) --
def sign(key, expires, secret):
    msg = f"{key}:{int(expires)}".encode()
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def verify(key, expires, signature, secret):
    try:
        if int(expires) < time.time():
            return False
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(sign(key, expires, secret), str(signature))


# ---- SSRF guard ------------------------------------------------------------
def validate_stream_url(url, allow_private=False):
    """Raises ValueError unless `url` is a public rtsp/rtmp/http(s) address.

    Blocks private, loopback, link-local (169.254.169.254 = the AWS metadata
    service) and other non-public targets. Limitation: DNS can change between
    this check and the connection (rebinding); IMDSv2 on the instance is the
    second layer of defence.
    """
    if not isinstance(url, str) or not url or len(url) > 2048:
        raise ValueError("stream URL is empty or too long")
    parsed = urlparse(url.strip())
    if parsed.scheme.lower() not in ALLOWED_STREAM_SCHEMES:
        raise ValueError(f"scheme must be one of {', '.join(ALLOWED_STREAM_SCHEMES)}")
    host = parsed.hostname
    if not host:
        raise ValueError("stream URL has no host")
    if allow_private:
        return url.strip()
    try:
        infos = socket.getaddrinfo(host, parsed.port or 0, proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise ValueError(f"cannot resolve host '{host}'")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        if not ip.is_global or ip.is_multicast:
            raise ValueError("stream URL points to a private or non-public address, which is not allowed")
    return url.strip()
