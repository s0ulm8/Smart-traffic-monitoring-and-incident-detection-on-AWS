"""Test doubles shared by the test-suite (kept inside the package so tests can import them)."""


class FakeHooks:
    def __init__(self):
        self.protection, self.metrics = [], []

    def set_scale_in_protection(self, protected):
        self.protection.append(protected)

    def put_metric(self, name, value=1.0, unit="Count"):
        self.metrics.append(name)
