"""Object storage: S3 on AWS, a local folder for development. Same interface.

Key layout:  jobs/<job_id>/input.<ext>
             jobs/<job_id>/annotated.mp4
             jobs/<job_id>/incidents/<n>.jpg
Nothing is ever public: S3 objects are served through short-lived presigned
URLs, local files through HMAC-signed URLs.
"""

import mimetypes
import os
import shutil
import time
from pathlib import Path
from urllib.parse import quote

from . import security


class Storage:
    def put_file(self, key, path, content_type=None): raise NotImplementedError
    def put_bytes(self, key, data, content_type): raise NotImplementedError
    def url(self, key): raise NotImplementedError
    def delete_prefix(self, prefix): raise NotImplementedError


class LocalStorage(Storage):
    def __init__(self, root, signing_secret, ttl=3600):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.secret, self.ttl = signing_secret, ttl

    def resolve(self, key):
        """Absolute path for a key; None if it would escape the storage root."""
        path = (self.root / key).resolve()
        return path if (path == self.root or self.root in path.parents) else None

    def put_file(self, key, path, content_type=None):
        dest = self.resolve(key)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)

    def put_bytes(self, key, data, content_type):
        dest = self.resolve(key)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)

    def url(self, key):
        exp = int(time.time()) + self.ttl
        return f"/files/{quote(key)}?exp={exp}&sig={security.sign(key, exp, self.secret)}"

    def delete_prefix(self, prefix):
        target = self.resolve(prefix)
        if target and target.exists() and target != self.root:
            shutil.rmtree(target, ignore_errors=True)


class S3Storage(Storage):
    def __init__(self, bucket, region, ttl=3600, client=None):
        import boto3
        from botocore.config import Config

        self.bucket, self.ttl = bucket, ttl
        self.client = client or boto3.client(
            "s3", region_name=region, config=Config(signature_version="s3v4", retries={"max_attempts": 5}))

    def put_file(self, key, path, content_type=None):
        ctype = content_type or mimetypes.guess_type(path)[0] or "application/octet-stream"
        self.client.upload_file(str(path), self.bucket, key, ExtraArgs={"ContentType": ctype})

    def put_bytes(self, key, data, content_type):
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)

    def url(self, key):
        return self.client.generate_presigned_url(
            "get_object", Params={"Bucket": self.bucket, "Key": key}, ExpiresIn=self.ttl)

    def delete_prefix(self, prefix):
        paginator = self.client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            objs = [{"Key": o["Key"]} for o in page.get("Contents", [])]
            if objs:
                self.client.delete_objects(Bucket=self.bucket, Delete={"Objects": objs, "Quiet": True})


def make_storage(settings):
    if settings.s3_bucket:
        return S3Storage(settings.s3_bucket, settings.aws_region, settings.signed_url_ttl)
    return LocalStorage(settings.local_storage_dir, settings.signing_secret, settings.signed_url_ttl)
