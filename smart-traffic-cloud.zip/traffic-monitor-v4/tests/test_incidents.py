from cloud.incidents import IncidentConfig, IncidentDetector


def car(tid, x, y, h=90):
    return {"tid": tid, "x": x, "y": y, "box_h": h}


def run(det, seconds, vehicles_at, fps=10):
    """vehicles_at(t) -> list of vehicles. Returns (all_incidents, last_state)."""
    out, state = [], None
    for i in range(int(seconds * fps) + 1):
        t = i / fps
        state, incs = det.update(t, vehicles_at(t))
        out += incs
    return out, state


def test_stopped_vehicle_flagged_after_threshold_only():
    det = IncidentDetector()
    incs, _ = run(det, 7.5, lambda t: [car(1, 300, 300)])
    assert incs == []                                   # not yet 8 s
    incs, _ = run(IncidentDetector(), 9, lambda t: [car(1, 300, 300)])
    stopped = [i for i in incs if i.type == "stopped_vehicle"]
    assert len(stopped) == 1                            # flagged once, not every frame
    assert stopped[0].track_id == 1
    assert stopped[0].severity == "high" and stopped[0].details["in_queue"] is False


def test_jitter_does_not_reset_but_real_movement_does():
    jitter = lambda t: [car(1, 300 + (2 if int(t * 10) % 2 else -2), 300)]
    incs, _ = run(IncidentDetector(), 9, jitter)
    assert any(i.type == "stopped_vehicle" for i in incs)

    def creeping(t):                                    # 20 px/s = clearly moving
        return [car(1, 300 + 20 * t, 300)]
    incs, _ = run(IncidentDetector(), 20, creeping)
    assert not any(i.type == "stopped_vehicle" for i in incs)


def test_moving_then_stopping_is_timed_from_the_stop():
    def path(t):
        return [car(1, 100 + 80 * t if t < 3 else 340, 300)]
    incs, _ = run(IncidentDetector(), 9, path)          # stopped from t=3 -> flagged near t=11
    assert not any(i.type == "stopped_vehicle" for i in incs)
    incs, _ = run(IncidentDetector(), 12, path)
    assert any(i.type == "stopped_vehicle" for i in incs)


def test_flag_clears_when_vehicle_moves_off_and_can_reflag():
    det = IncidentDetector()
    run(det, 9, lambda t: [car(1, 300, 300)])
    assert det.stopped_ids() == {1}
    det.update(9.2, [car(1, 500, 300)])
    assert det.stopped_ids() == set()


def test_track_gap_resets_history():
    det = IncidentDetector()
    run(det, 5, lambda t: [car(1, 300, 300)])
    det.update(12.0, [car(1, 300, 300)])                # reappears after a long gap
    assert det.stopped_ids() == set()


def test_congestion_levels_and_debounce():
    def jam(n):
        return lambda t: [car(i, 100 + i * 60, 300) for i in range(n)]
    # 10 stationary vehicles -> heavy, but only after the hold time
    det = IncidentDetector()
    state, incs = det.update(0.0, jam(10)(0))
    assert state.level == "free" and incs == []         # debounced
    incs, state = run(IncidentDetector(), 6, jam(10))[0], None
    assert [i.details["level"] for i in incs if i.type == "congestion"] == ["heavy"]

    incs, st = run(IncidentDetector(), 6, jam(5))       # 5 slow vehicles -> moderate
    assert st.level == "moderate"
    incs, st = run(IncidentDetector(), 6, jam(2))       # 2 vehicles -> free
    assert st.level == "free"


def test_fast_traffic_is_free_flow():
    def flow(t):
        return [car(i, 100 + i * 60, 100 + 300 * t) for i in range(10)]   # 300 px/s ~ 3.3 body lengths/s
    _, st = run(IncidentDetector(), 1.5, flow)
    assert st.level == "free" and st.slow_fraction == 0.0


def test_queue_tagging_and_cleared_event():
    cfg = IncidentConfig(stopped_seconds=4)
    det = IncidentDetector(cfg)
    jam = lambda t: [car(i, 100 + i * 60, 300) for i in range(10)]
    incs, _ = run(det, 8, jam)
    stopped = [i for i in incs if i.type == "stopped_vehicle"]
    assert stopped and all(i.details["in_queue"] and i.severity == "low" for i in stopped)
    incs, st = run(det, 5, lambda t: [])                # road empties (t restarts, so offset)
    det2 = IncidentDetector(cfg)
    run(det2, 6, jam)
    s, incs = det2.update(30.0, [])
    s, incs = det2.update(34.0, [])
    assert s.level == "free" and any(i.type == "congestion_cleared" for i in incs)
