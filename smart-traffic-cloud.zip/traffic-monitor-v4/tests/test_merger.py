from conftest import blank_frame, det
from track_merger import TrackMerger


def frame():
    return blank_frame(640, 480)


def step(tm, f, dets):
    return tm.update(frame(), dets, f)


def test_same_vehicle_keeps_id_after_short_occlusion_and_id_switch():
    tm = TrackMerger()
    ids = [step(tm, f, [det(5, (100, 100, 180, 160))])[0]["canonical_id"] for f in range(10)]
    for f in range(10, 15):
        step(tm, f, [])
    out = step(tm, 15, [det(99, (102, 100, 182, 160))])      # tracker re-issues a new raw id
    assert out[0]["canonical_id"] == ids[0]


def test_class_flicker_does_not_fragment_ids():
    """The '#5,#6,#7,#8' bug: a distant car flickering Car/Truck got a new ID each time."""
    tm = TrackMerger()
    cid = step(tm, 0, [det(1, (100, 100, 180, 160), "Truck")])[0]["canonical_id"]
    step(tm, 1, [])
    out = step(tm, 2, [det(2, (102, 100, 182, 160), "Car")])
    assert out[0]["canonical_id"] == cid


def test_two_simultaneous_nearby_vehicles_never_merge():
    tm = TrackMerger()
    for f in range(5):
        out = step(tm, f, [det(1, (100, 100, 180, 160)), det(2, (110, 100, 190, 160))])
        assert out[0]["canonical_id"] != out[1]["canonical_id"]


def test_stale_wrong_merge_is_split_when_both_are_visible():
    """The duplicate '#7 #7' bug: a wrongly merged raw id later coexists with the original."""
    tm = TrackMerger()
    step(tm, 0, [det(14, (100, 200, 220, 300))])
    step(tm, 1, [])                                         # raw 14 vanishes for one frame
    out = step(tm, 2, [det(21, (102, 200, 222, 300))])      # raw 21 gets merged into 14's id
    merged_id = out[0]["canonical_id"]
    out = step(tm, 3, [det(14, (100, 200, 220, 300)), det(21, (102, 200, 222, 300))])
    ids = {d["id"]: d["canonical_id"] for d in out}
    assert ids[14] != ids[21], f"two visible vehicles share id {merged_id}"


def test_vehicle_that_left_the_frame_is_not_merged_with_a_newcomer():
    tm = TrackMerger()
    for f in range(5):
        step(tm, f, [det(1, (560, 100, 638, 160))])         # touching the right edge (frame is 640 wide)
    for f in range(5, 8):
        step(tm, f, [])
    out = step(tm, 8, [det(2, (562, 100, 636, 160))])       # a DIFFERENT car appears nearby
    assert out[0]["canonical_id"] == 2, "a vehicle that exited at the edge must not absorb a new one"


def test_different_sized_vehicle_is_not_merged():
    tm = TrackMerger()
    for f in range(5):
        step(tm, f, [det(1, (100, 100, 140, 130))])         # small
    step(tm, 5, [])
    out = step(tm, 6, [det(2, (100, 60, 300, 260))])        # much larger, same spot
    assert out[0]["canonical_id"] == 2


def test_far_away_reappearance_is_a_new_vehicle():
    tm = TrackMerger(max_dist_px=50)
    for f in range(5):
        step(tm, f, [det(1, (100, 100, 180, 160))])
    step(tm, 5, [])
    out = step(tm, 6, [det(2, (400, 300, 480, 360))])
    assert out[0]["canonical_id"] == 2


def test_lost_pool_expires():
    tm = TrackMerger(max_lost_frames=5)
    for f in range(3):
        step(tm, f, [det(1, (100, 100, 180, 160))])
    for f in range(3, 20):
        step(tm, f, [])
    out = step(tm, 20, [det(2, (102, 100, 182, 160))])
    assert out[0]["canonical_id"] == 2


def test_memory_is_bounded_over_many_short_lived_tracks():
    tm = TrackMerger(memory_frames=50)
    for f in range(2000):
        step(tm, f, [det(f + 1, (10, 10, 60, 60))])
    assert len(tm.raw_to_canonical) < 400, "raw_to_canonical used to grow forever"
    assert len(tm.last_snapshot) < 400
