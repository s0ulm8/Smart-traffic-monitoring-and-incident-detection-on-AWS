import json

import numpy as np

import config
import utils
from conftest import CALIB_DST, CALIB_SRC, FakePlates, blank_frame, box_at, det, make_monitor, run
from processor import is_live_source
from speed_estimator import HomographySpeedEstimator

import pytest


def drive_down(x=600, start=480, end=680, step=8, w=120, h=90, raw_id=1, cls="Car"):
    return [[det(raw_id, box_at(x, y, w=w, h=h), cls)] for y in range(start, end, step)]


# ---- counting through the whole pipeline ------------------------------------
def test_vehicle_counted_once_by_class():
    m = make_monitor(drive_down())
    stats = run(m, 25)
    assert stats["total"] == 1 and stats["by_class"] == {"Car": 1}


def test_raw_id_switch_mid_track_is_not_double_counted():
    script = [[det(1 if i < 12 else 2, box_at(600, 480 + i * 8))] for i in range(25)]
    # raw id changes after a one-frame dropout, as after an occlusion
    script.insert(12, [])
    stats = run(make_monitor(script), len(script))
    assert stats["total"] == 1


def test_defaults_are_resolved_at_construction_not_import_time(monkeypatch):
    """v3 bound config.ROAD_ROIS at import time, so later changes were ignored."""
    monkeypatch.setattr(config, "ROAD_ROIS", [
        {"name": "only", "polygon": [(0, 0), (1280, 0), (1280, 720), (0, 720)], "direction": "down", "count_line_y": 500},
    ])
    m = make_monitor(drive_down(start=420, end=620))
    run(m, 25)
    assert [r.name for r in m.roi_manager.rois] == ["only"]
    assert m.get_stats()["by_roi_direction"] == {"only|down": 1}


def test_unconfirmed_one_frame_noise_is_ignored():
    script = [[det(7, box_at(300, 300))]] + [[] for _ in range(10)]
    m = make_monitor(script)
    run(m, 11)
    assert m.vehicle_records == {}


# ---- overspeed: persistence + both directions ---------------------------------
def calibrated_monitor(script, **kw):
    return make_monitor(script, calibration_src_points=CALIB_SRC, calibration_dst_points=CALIB_DST,
                        speed_limit_kmh=50, **kw)


def pixel_track(kmh, n=40, fps=25.0, jitter=0.0, seed=0, raw_id=1):
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST)
    Hinv = np.linalg.inv(est.H)
    rng = np.random.default_rng(seed)
    script = []
    for i in range(n):
        Y = 0.5 + kmh / 3.6 * (i / fps)
        if Y > 19.5:
            break
        v = Hinv @ np.array([1.75, Y, 1.0])
        v /= v[2]
        px, py = v[0] + rng.uniform(-jitter, jitter), v[1] + rng.uniform(-jitter, jitter)
        script.append([det(raw_id, box_at(px, py, w=120, h=90))])
    return script


def test_genuine_speeder_triggers_exactly_one_event():
    m = calibrated_monitor(pixel_track(70))
    stats = run(m, 40)
    assert stats["overspeeding"] == 1 and len(m.events) == 1
    assert m.events[0]["speed_kmh"] == pytest.approx(70, abs=3)


def test_vehicle_below_limit_never_alerts():
    m = calibrated_monitor(pixel_track(40))
    assert run(m, 40)["overspeeding"] == 0


def test_noise_does_not_cause_false_overspeed_alerts():
    """v3 flagged ~36% of 40 km/h cars (limit 50) from +/-2 px jitter alone."""
    false_alerts, trials = 0, 80
    for seed in range(trials):
        m = calibrated_monitor(pixel_track(40, jitter=2.0, seed=seed))
        false_alerts += run(m, 40)["overspeeding"]
    assert false_alerts / trials <= 0.03, f"{false_alerts}/{trials} false overspeed alerts"


def test_uncalibrated_speed_is_labelled():
    m = make_monitor(drive_down())
    assert run(m, 25)["speed_calibrated"] is False


def test_measured_distance_counts_as_calibrated():
    m = make_monitor(drive_down(), real_distance_m=12.0, distance_is_measured=True)
    assert run(m, 25)["speed_calibrated"] is True


def test_calibration_points_count_as_calibrated():
    m = calibrated_monitor(pixel_track(40))
    assert run(m, 10)["speed_calibrated"] is True


def test_upward_traffic_gets_speed_and_alerts_in_fallback_mode():
    """Fallback two-line mode, vehicle travelling UP the frame."""
    script = [[det(1, box_at(600, y))] for y in range(700, 250, -9)]
    m = make_monitor(script, speed_limit_kmh=30, real_distance_m=15.0, distance_is_measured=True)
    run(m, len(script))
    assert m.vehicle_records[1]["speed"] is not None
    assert m.get_stats()["overspeeding"] == 1


# ---- event <-> plate linking ----------------------------------------------------
def test_unknown_plate_on_event_is_updated_when_ocr_resolves_later():
    # A 70 km/h car crosses the 20 m calibrated zone in ~25 frames, so the plate has to become
    # readable within that window - but AFTER the overspeed event has already been raised.
    plates = FakePlates(reads=[("AB1234", 0.9)], visible=lambda call: call > 3)
    script = pixel_track(70, n=60)
    m = calibrated_monitor(script, plates=plates)

    plate_when_event_created = None
    for i in range(len(script)):
        m.process_frame(blank_frame(), i / 25.0)
        if m.events and plate_when_event_created is None:
            plate_when_event_created = m.events[0]["plate"]

    assert plate_when_event_created == "UNKNOWN", "the plate must not be known yet when the event is raised"
    assert m.events[0]["plate"] == "AB1234", "event used to stay UNKNOWN forever"


def test_event_plate_is_unknown_when_never_read():
    m = calibrated_monitor(pixel_track(70))
    run(m, 40)
    assert m.events[0]["plate"] == "UNKNOWN"


# ---- memory / reports --------------------------------------------------------------
def test_purge_keeps_totals_and_empties_detail(cfg):
    cfg.RECORD_EXPIRY_FRAMES = 5
    script = drive_down() + [[] for _ in range(30)]
    m = make_monitor(script)
    run(m, len(script))
    assert m.vehicle_records == {} and m.hit_count == {}
    assert m.get_stats()["total"] == 1


def test_report_files_are_valid_json_and_csv(tmp_path):
    m = calibrated_monitor(pixel_track(70))
    run(m, 40)
    m.save_report(str(tmp_path))
    data = json.loads((tmp_path / "summary.json").read_text())
    assert data["stats"]["overspeeding"] == 1
    header = (tmp_path / "events.csv").read_text().splitlines()[0]
    assert "speed_calibrated" in header


def test_is_live_source():
    assert is_live_source(0) and is_live_source("rtsp://cam/stream") and is_live_source("http://x/y.m3u8")
    assert not is_live_source("traffic.mp4")


# ---- drawing: OVERSPEED tag used to be clipped at the bottom edge -------------------
def test_overspeed_tag_stays_inside_frame_for_vehicle_at_bottom():
    frame = blank_frame()
    before = frame.copy()
    utils.draw_box(frame, (400, 600, 600, 715), "Car", 1, None, 80, True)
    band = frame[700:720, 400:560]
    assert (band != before[700:720, 400:560]).any(), "tag should be visible inside the frame"
    # the tag text region (red background) must exist within the visible rows
    assert (frame[690:720, 400:470, 2] == 255).any()


def test_wrong_direction_tag_also_inside_frame():
    frame = blank_frame()
    utils.draw_box(frame, (400, 600, 600, 715), "Car", 1, None, 80, True, wrong_direction=True)
    assert frame.shape == (720, 1280, 3)


def test_fallback_mode_draws_the_two_speed_lines():
    m = make_monitor(drive_down())
    frame = blank_frame()
    m.process_frame(frame, 0.0)
    ya, yb = m.speed_estimator.line_a_y, m.speed_estimator.line_b_y
    assert (frame[ya, :, :] != 0).any() and (frame[yb, :, :] != 0).any()


def test_no_overspeed_alert_when_speed_is_uncalibrated(cfg):
    """Placeholder distance used to flag nearly every car; alerts now need a real calibration."""
    script = [[det(1, box_at(600, y))] for y in range(300, 700, 9)]
    m = make_monitor(script, speed_limit_kmh=1)          # absurdly low limit: everything would alert
    stats = run(m, len(script))
    assert m.vehicle_records[1]["speed"] is not None, "indicative speed is still shown"
    assert stats["overspeeding"] == 0 and m.events == []


def test_uncalibrated_alerts_can_be_forced_for_demos(cfg):
    cfg.ALERT_WHEN_UNCALIBRATED = True
    script = [[det(1, box_at(600, y))] for y in range(300, 700, 9)]
    m = make_monitor(script, speed_limit_kmh=1)
    assert run(m, len(script))["overspeeding"] == 1
