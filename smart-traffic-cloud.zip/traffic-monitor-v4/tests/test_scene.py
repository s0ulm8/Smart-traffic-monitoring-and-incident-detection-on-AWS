import json

import pytest

from scene import load_scene


def write(tmp_path, data):
    p = tmp_path / "scene.json"
    p.write_text(json.dumps(data))
    return str(p)


def test_valid_scene_loads(tmp_path):
    kw = load_scene(write(tmp_path, {
        "speed_limit_kmh": 60,
        "line_distance_m": 12.5,
        "road_rois": [{"name": "a", "polygon": [[0, 0], [10, 0], [10, 10]], "direction": "down", "count_line_y": 5}],
    }))
    assert kw["speed_limit_kmh"] == 60.0
    assert kw["real_distance_m"] == 12.5 and kw["distance_is_measured"] is True
    assert kw["road_rois"][0]["polygon"] == [(0, 0), (10, 0), (10, 10)]


def test_unknown_key_is_an_error_not_silently_ignored(tmp_path):
    with pytest.raises(ValueError, match="unknown keys"):
        load_scene(write(tmp_path, {"speed_limt_kmh": 60}))


def test_example_scene_is_valid():
    import os

    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scenes", "highway_example.json")
    kw = load_scene(path)
    from roi import RoadROIManager

    RoadROIManager(1280, 720, kw["road_rois"])      # must validate cleanly


def test_evaluate_reports_errors():
    from evaluate import compare

    stats = {"total": 7, "overspeeding": 1, "by_class": {"Car": 6, "Bus": 1}}
    rows = {r[0]: r[3] for r in compare(stats, {"total": 6, "Car": 6, "Truck": 0})}
    assert rows == {"total": 1, "Car": 0, "Truck": 0}


def test_speed_line_positions_can_be_set_from_scene(tmp_path):
    kw = load_scene(write(tmp_path, {"speed_line_a_ratio": 0.6, "speed_line_b_ratio": 0.9}))
    from conftest import make_monitor, blank_frame

    m = make_monitor([[]], **kw)
    m.process_frame(blank_frame(), 0.0)
    assert (m.speed_estimator.line_a_y, m.speed_estimator.line_b_y) == (int(720 * 0.6), int(720 * 0.9))
