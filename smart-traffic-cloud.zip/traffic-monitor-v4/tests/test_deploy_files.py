"""Static checks of the deployment files (no AWS account needed)."""
import glob
import os
import shutil
import subprocess

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@pytest.mark.skipif(shutil.which("cfn-lint") is None, reason="cfn-lint not installed")
def test_cloudformation_template_lints_clean():
    r = subprocess.run(["cfn-lint", os.path.join(ROOT, "deploy", "template.yaml")], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


@pytest.mark.skipif(shutil.which("bash") is None, reason="bash not available")
@pytest.mark.parametrize("script", sorted(glob.glob(os.path.join(ROOT, "deploy", "*.sh"))))
def test_shell_scripts_have_valid_syntax(script):
    assert subprocess.run(["bash", "-n", script]).returncode == 0


def test_template_has_the_architecture_from_the_brief():
    text = open(os.path.join(ROOT, "deploy", "template.yaml")).read()
    for resource in ("AWS::AutoScaling::AutoScalingGroup", "AWS::ElasticLoadBalancingV2::LoadBalancer",
                     "AWS::RDS::DBInstance", "AWS::S3::Bucket", "AWS::IAM::Role", "AWS::CloudWatch::Alarm",
                     "AWS::CloudWatch::Dashboard", "AWS::Logs::LogGroup", "AWS::AutoScaling::ScalingPolicy"):
        assert resource in text, resource
    assert "PubliclyAccessible: false" in text and "StorageEncrypted: true" in text
    assert "HttpTokens: required" in text and "BlockPublicAcls: true" in text


def test_dockerfile_keeps_opencv_4_and_bakes_models():
    text = open(os.path.join(ROOT, "Dockerfile")).read()
    assert "constraints.txt" in text and "startswith('4.')" in text and "easyocr.Reader" in text
    assert "--workers\", \"1\"" in text
    assert "opencv-python<5" in open(os.path.join(ROOT, "constraints.txt")).read()
