"""End-to-end API tests: real HTTP layer, real database, real video files,
real worker thread. Only the YOLO detector is replaced by a scripted fake."""

import io
import json
import os
import time

import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient

from cloud.app import create_app
from cloud.cloud_testing import FakeHooks
from cloud.monitor import CloudMonitor
from cloud.settings import Settings
from conftest import FakeDetector, FakePlates, box_at, det

W, H, FPS = 640, 360, 10
KEY = "test-key"
HDR = {"X-API-Key": KEY}


def make_video(path, n_frames=130):
    codec = "mp4v" if str(path).endswith(".mp4") else "MJPG"
    wr = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*codec), FPS, (W, H))
    assert wr.isOpened()
    for i in range(n_frames):
        frame = np.full((H, W, 3), 100, np.uint8)
        cv2.putText(frame, str(i), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        wr.write(frame)
    wr.release()
    return path


def scripted_scene(n_frames):
    """Car 1 drives down across the count line; car 2 parks and never moves."""
    script = []
    for i in range(n_frames):
        ds = [det(2, box_at(450, 300))]
        if i < 60:
            ds.append(det(1, box_at(150, 120 + i * 4)))        # crosses y=288 (80% of 360)
        script.append(ds)
    return script


def factory_for(script_fn, delay=0.0):
    def factory(params, scene_kwargs):
        detector = FakeDetector(script_fn())
        if delay:
            inner = detector.track
            detector.track = lambda f: (time.sleep(delay), inner(f))[1]
        return CloudMonitor(detector=detector, plate_recognizer=FakePlates(with_reader=False), **scene_kwargs)
    return factory


@pytest.fixture
def make_client(tmp_path):
    clients = []

    def build(factory=None, **overrides):
        opts = dict(api_key=KEY, database_url=f"sqlite:///{tmp_path}/t.db", local_storage_dir=str(tmp_path / "store"),
                    work_dir=str(tmp_path / "work"), signing_secret="s3cret", stats_interval_sec=5.0,
                    allow_private_streams=False)
        opts.update(overrides)
        s = Settings(**opts)
        app = create_app(s, monitor_factory=factory or factory_for(lambda: scripted_scene(130)), hooks=FakeHooks())
        c = TestClient(app)
        c.__enter__()
        clients.append(c)
        return c
    yield build
    for c in clients:
        c.__exit__(None, None, None)


def wait_for(client, job_id, statuses=("completed", "failed", "stopped"), timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        j = client.get(f"/api/jobs/{job_id}", headers=HDR).json()
        if j["status"] in statuses:
            return j
        time.sleep(0.1)
    raise AssertionError(f"job did not finish: {j}")


def upload(client, path, **data):
    with open(path, "rb") as f:
        return client.post("/api/jobs/upload", headers=HDR, files={"file": (os.path.basename(path), f)}, data=data)


@pytest.fixture
def video(tmp_path):
    return make_video(tmp_path / "road.mp4")


# --------------------------------------------------------------------------
def test_health_is_public_and_api_needs_key(make_client):
    c = make_client()
    assert c.get("/health").json() == {"status": "ok"}
    assert c.get("/health/deep").json()["database"] == "ok"
    assert c.get("/api/jobs").status_code == 401
    assert c.get("/api/jobs", headers={"X-API-Key": "wrong"}).status_code == 401
    assert c.get("/api/jobs", headers=HDR).status_code == 200
    r = c.get("/")
    assert r.status_code == 200 and "text/html" in r.headers["content-type"]
    assert "frame-ancestors" in r.headers["content-security-policy"]


def test_full_pipeline_upload_to_results(make_client, video):
    c = make_client()
    r = upload(c, video, speed_limit_kmh="50")
    assert r.status_code == 202
    job_id = r.json()["id"]
    job = wait_for(c, job_id)
    assert job["status"] == "completed", job
    assert job["progress"] == 1.0 and job["frames_processed"] == 130
    assert job["stats"]["total"] == 1 and job["stats"]["by_class"] == {"Car": 1}

    # annotated video + original were stored and are downloadable via signed URLs
    assert job["video_url"] and job["input_url"]
    vid = c.get(job["video_url"])
    assert vid.status_code == 200 and len(vid.content) > 1000
    cap_path = os.path.join(os.path.dirname(video), "dl.mp4")
    open(cap_path, "wb").write(vid.content)
    cap = cv2.VideoCapture(cap_path)
    assert cap.isOpened() and cap.get(cv2.CAP_PROP_FRAME_COUNT) >= 100

    # traffic statistics were recorded every 5 s (+ a final row)
    stats = c.get(f"/api/jobs/{job_id}/stats", headers=HDR).json()
    assert len(stats) >= 3 and stats[-1]["total"] == 1
    assert [s["t_sec"] for s in stats] == sorted(s["t_sec"] for s in stats)

    # the parked car was flagged as a stopped vehicle, with a snapshot image
    incs = c.get(f"/api/jobs/{job_id}/incidents", headers=HDR).json()
    stopped = [i for i in incs if i["type"] == "stopped_vehicle"]
    assert len(stopped) == 1 and stopped[0]["track_id"] and stopped[0]["details"]["stopped_for_s"] >= 8
    assert stopped[0]["severity"] == "high" and stopped[0]["details"]["in_queue"] is False
    snap = c.get(stopped[0]["snapshot_url"])
    assert snap.status_code == 200 and snap.content[:2] == b"\xff\xd8"          # JPEG magic

    assert c.get("/api/summary", headers=HDR).json()["incidents_by_type"]["stopped_vehicle"] == 1
    assert c.get("/api/jobs", headers=HDR).json()[0]["id"] == job_id


def test_signed_file_urls_cannot_be_forged_or_traversed(make_client, video):
    c = make_client()
    job = wait_for(c, upload(c, video).json()["id"])
    url = job["video_url"]
    assert c.get(url).status_code == 200
    assert c.get(url.split("&sig=")[0] + "&sig=deadbeef").status_code == 404           # bad signature
    assert c.get("/files/jobs/x/annotated.mp4?exp=9999999999&sig=abc").status_code == 404
    assert c.get("/files/..%2f..%2fetc%2fpasswd?exp=9999999999&sig=abc").status_code == 404
    assert c.get(url.replace("exp=", "exp=1&x=")).status_code in (404, 422)           # tampered/expired


def test_delete_removes_rows_and_files(make_client, video, tmp_path):
    c = make_client()
    job_id = upload(c, video).json()["id"]
    wait_for(c, job_id)
    assert (tmp_path / "store" / "jobs" / job_id).exists()
    assert c.delete(f"/api/jobs/{job_id}", headers=HDR).status_code == 204
    assert c.get(f"/api/jobs/{job_id}", headers=HDR).status_code == 404
    assert not (tmp_path / "store" / "jobs" / job_id).exists()
    assert c.delete(f"/api/jobs/{job_id}", headers=HDR).status_code == 404


def test_stop_running_job(make_client, video):
    c = make_client(factory_for(lambda: scripted_scene(130), delay=0.05))
    job_id = upload(c, video).json()["id"]
    wait_for(c, job_id, statuses=("running",))
    assert c.delete(f"/api/jobs/{job_id}", headers=HDR).status_code == 409      # must stop first
    assert c.post(f"/api/jobs/{job_id}/stop", headers=HDR).status_code == 200
    job = wait_for(c, job_id)
    assert job["status"] == "stopped" and job["frames_processed"] < 130
    assert c.post(f"/api/jobs/{job_id}/stop", headers=HDR).status_code == 409   # already finished


def test_failing_job_reports_error(make_client, video):
    def bad_factory(params, scene):
        raise RuntimeError("model exploded")
    c = make_client(bad_factory)
    job = wait_for(c, upload(c, video).json()["id"])
    assert job["status"] == "failed" and "model exploded" in job["error"]


def test_upload_validation(make_client, tmp_path, video):
    c = make_client(max_upload_mb=1)
    bad = tmp_path / "notes.txt"
    bad.write_text("hello")
    assert upload(c, bad).status_code == 400                                       # extension
    fake = tmp_path / "fake.mp4"
    fake.write_bytes(b"this is not a video" * 100)
    r = upload(c, fake)
    assert r.status_code == 400 and "could not be read" in r.json()["detail"]
    empty = tmp_path / "empty.mp4"
    empty.write_bytes(b"")
    assert upload(c, empty).status_code == 400
    big = tmp_path / "big.mp4"
    big.write_bytes(b"\0" * (1 * 1024 * 1024 + 10))
    assert upload(c, big).status_code == 413
    assert upload(c, video, speed_limit_kmh="1").status_code == 422                # out of range
    assert not any(os.scandir(tmp_path / "work"))                                  # failed uploads left no files
    assert c.get("/api/jobs", headers=HDR).json() == []


def test_scene_file_validation_and_use(make_client, video, tmp_path):
    c = make_client()
    def with_scene(obj):
        f = open(video, "rb")
        return c.post("/api/jobs/upload", headers=HDR,
                      files={"file": ("road.mp4", f), "scene": ("scene.json", json.dumps(obj).encode())})
    assert with_scene({"bogus": 1}).status_code == 400
    r = with_scene({"road_rois": [{"name": "a", "polygon": [[0, 0], [10, 0], [10, 10]], "direction": "sideways",
                                   "count_line_y": 5}]})
    assert r.status_code == 400 and "direction" in r.json()["detail"]
    ok = with_scene({"road_rois": [{"name": "all", "polygon": [[0, 0], [640, 0], [640, 360], [0, 360]],
                                    "direction": "both", "count_line_y": 288}]})
    assert ok.status_code == 202
    job = wait_for(c, ok.json()["id"])
    assert job["status"] == "completed" and "all|down" in job["stats"]["by_roi_direction"]


def test_stream_url_ssrf_guard(make_client):
    c = make_client()
    for url in ["http://169.254.169.254/latest/meta-data/", "http://127.0.0.1:8000/", "http://localhost/x",
                "http://10.0.0.5/stream", "rtsp://192.168.1.10/cam", "file:///etc/passwd", "ftp://example.com/x",
                "http://[::1]/"]:
        r = c.post("/api/jobs/stream", headers=HDR, json={"url": url})
        assert r.status_code == 400, url
    assert c.get("/api/jobs", headers=HDR).json() == []


def test_stream_job_runs_and_hides_credentials(tmp_path, video, make_client, monkeypatch):
    c = make_client(allow_private_streams=True)           # dev switch so a file can stand in for a stream
    monkeypatch.setattr("cloud.jobs.is_live_source", lambda s: False)
    r = c.post("/api/jobs/stream", headers=HDR, json={"url": "http://user:pass@example.com:8080/live/cam.mp4"})
    assert r.status_code == 202
    assert "pass" not in json.dumps(r.json()) and r.json()["name"] == "http://example.com:8080/live/cam.mp4"
    job = wait_for(c, r.json()["id"])                    # nothing listens there: must fail cleanly, not hang
    assert job["status"] == "failed" and "could not open" in job["error"]


def test_pending_job_cap(make_client, video):
    c = make_client(factory_for(lambda: scripted_scene(130), delay=0.1), max_pending_jobs=2)
    ids = [upload(c, video).json()["id"] for _ in range(2)]
    assert upload(c, video).status_code == 429
    for i in ids:
        c.post(f"/api/jobs/{i}/stop", headers=HDR)
        wait_for(c, i)


def test_orphaned_jobs_are_recovered_and_stale_jobs_reaped(tmp_path):
    from datetime import timedelta
    from cloud.db import Database, Job, utcnow
    s = Settings(api_key=KEY, database_url=f"sqlite:///{tmp_path}/o.db", local_storage_dir=str(tmp_path / "st"),
                 work_dir=str(tmp_path / "w"), instance_id="i-mine", stale_job_seconds=60)
    db = Database(s.database_url)
    db.create_all()
    old = utcnow() - timedelta(seconds=600)
    with db.session() as se:
        se.add_all([Job(id="a" * 32, kind="upload", name="mine", status="running", instance_id="i-mine"),
                    Job(id="b" * 32, kind="upload", name="dead peer", status="running", instance_id="i-dead",
                        heartbeat_at=old),
                    Job(id="c" * 32, kind="upload", name="live peer", status="running", instance_id="i-live")])
    app = create_app(s, db=db, hooks=FakeHooks())
    with TestClient(app) as c:                                  # startup runs recover_orphans
        c.app.state.manager.maintenance_once()
        jobs = {j["name"]: j for j in c.get("/api/jobs", headers=HDR).json()}
    assert jobs["mine"]["status"] == "failed" and "restarted" in jobs["mine"]["error"]
    assert jobs["dead peer"]["status"] == "failed" and "worker lost" in jobs["dead peer"]["error"]
    assert jobs["live peer"]["status"] == "running"             # a healthy peer is left alone


def test_scale_in_protection_toggles_around_jobs(make_client, video):
    c = make_client()
    hooks = c.app.state.manager.hooks
    wait_for(c, upload(c, video).json()["id"])
    time.sleep(0.3)
    assert hooks.protection == [True, False]
    assert "JobsCompleted" in hooks.metrics and "VehiclesCounted" in hooks.metrics
