import numpy as np

import config
from conftest import FakePlates, box_at, det, make_monitor, run
from plate_recognition import PlateRecognizer, combine_plate_reads


# ---- character-level voting --------------------------------------------------
def test_combine_reads_votes_per_character():
    reads = [("A82545", 0.55), ("A8254S", 0.80), ("A8254S", 0.75)]
    assert combine_plate_reads(reads) == "A8254S"


def test_combine_reads_single_and_empty():
    assert combine_plate_reads([]) is None
    assert combine_plate_reads([("AB1234", 0.9)]) == "AB1234"


def test_combine_reads_prefers_best_supported_length():
    reads = [("AB123", 0.4), ("AB1234", 0.9), ("AB1234", 0.8)]
    assert combine_plate_reads(reads) == "AB1234"


# ---- multi-fragment OCR ------------------------------------------------------
class FakeReader:
    def __init__(self, results):
        self.results = results

    def readtext(self, img):
        return self.results


def bbox(x0, x1, y0=10, y1=40):
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]


def recognizer_with(results):
    pr = PlateRecognizer(use_easyocr=False)
    pr.reader = FakeReader(results)
    return pr


CROP = np.zeros((20, 80, 3), dtype=np.uint8)


def test_split_plate_fragments_are_joined_left_to_right():
    # right fragment listed first: order must come from x position, not list order
    pr = recognizer_with([(bbox(120, 300), "8254S", 0.9), (bbox(0, 100), "ZHA", 0.7)])
    text, conf = pr.read_plate(CROP)
    assert text == "ZHA8254S"
    assert 0.7 < conf < 0.9


def test_fragments_on_a_different_line_are_not_merged():
    pr = recognizer_with([(bbox(0, 300, 10, 40), "AB1234", 0.9), (bbox(0, 300, 200, 230), "STICKER", 0.9)])
    assert pr.read_plate(CROP)[0] == "AB1234"


def test_low_confidence_fragments_ignored_and_low_confidence_plate_rejected():
    pr = recognizer_with([(bbox(0, 100), "AB1234", 0.2)])
    assert pr.read_plate(CROP) == (None, 0.0)


def test_text_failing_regex_is_rejected():
    pr = recognizer_with([(bbox(0, 100), "AB", 0.95)])        # too short for PLATE_REGEX
    assert pr.read_plate(CROP) == (None, 0.0)


def test_read_plate_without_reader_returns_nothing_instead_of_crashing():
    pr = PlateRecognizer(use_easyocr=False)
    assert pr.reader is None
    assert pr.read_plate(CROP) == (None, 0.0)


# ---- bug: plate budget was burned while the vehicle was still far away -------
def test_plate_found_late_is_still_read(cfg):
    """Plate only becomes findable after ~100 frames (vehicle approaching)."""
    # visible() counts only searches that actually happen, i.e. those after the vehicle
    # is wide enough (frame 100+, every 4th frame). The plate shows up on the 6th search.
    plates = FakePlates(reads=[("AB1234", 0.9)], visible=lambda call: call > 5)
    # vehicle is narrow (far) for 100 frames, then wide (close) for 100 frames
    script = []
    for i in range(200):
        w = 60 if i < 100 else 160
        script.append([det(1, box_at(600, 400, w=w, h=int(w * 0.75)))])
    m = make_monitor(script, plates=plates)
    run(m, 200)
    assert m.vehicle_records[1]["plate"] == "AB1234", "budget used to be exhausted before the plate was readable"


def test_far_vehicle_costs_no_plate_work(cfg):
    plates = FakePlates()
    script = [[det(1, box_at(600, 400, w=60, h=45))] for _ in range(100)]    # always below min width
    m = make_monitor(script, plates=plates)
    run(m, 100)
    assert plates.detect_calls == 0 and plates.read_calls == 0


def test_plate_search_work_is_hard_capped(cfg):
    plates = FakePlates(visible=lambda call: False)                           # plate never found
    script = [[det(1, box_at(600, 400, w=160, h=120))] for _ in range(1500)]
    m = make_monitor(script, plates=plates)
    run(m, 1500)
    assert plates.detect_calls <= config.MAX_PLATE_SEARCHES_PER_VEHICLE


def test_ocr_calls_capped(cfg):
    plates = FakePlates(reads=[(None, 0.0)])                                  # found but unreadable
    script = [[det(1, box_at(600, 400, w=160, h=120))] for _ in range(600)]
    m = make_monitor(script, plates=plates)
    run(m, 600)
    assert plates.read_calls <= config.MAX_OCR_ATTEMPTS_PER_VEHICLE


def test_plate_voting_corrects_a_bad_first_read(cfg):
    plates = FakePlates(reads=[("A82545", 0.5), ("A8254S", 0.9), ("A8254S", 0.9)])
    script = [[det(1, box_at(600, 400, w=160, h=120))] for _ in range(80)]
    m = make_monitor(script, plates=plates)
    run(m, 80)
    assert m.vehicle_records[1]["plate"] == "A8254S"


def test_disabled_ocr_does_no_plate_work():
    plates = FakePlates(with_reader=False)
    script = [[det(1, box_at(600, 400, w=160, h=120))] for _ in range(50)]
    m = make_monitor(script, plates=plates)
    run(m, 50)
    assert plates.detect_calls == 0


def test_haar_localiser_is_actually_loaded():
    """Under OpenCV 5 / missing XML this used to be silently None -> plates never found."""
    pr = PlateRecognizer(use_easyocr=False)
    assert pr.cascade is not None and pr.localiser_error is None
