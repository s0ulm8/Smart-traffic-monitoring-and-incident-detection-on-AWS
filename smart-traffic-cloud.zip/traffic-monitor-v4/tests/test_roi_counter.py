import pytest

from line_counter import RoiLineCounter
from roi import RoadROI, RoadROIManager

SQUARE = [(0, 0), (1000, 0), (1000, 1000), (0, 1000)]


# ---- ROI validation (a typo used to flag every car as wrong-way) -------------
def test_direction_is_case_insensitive_and_normalised():
    assert RoadROI("a", SQUARE, "Down", 400).direction == "down"
    assert RoadROI("a", SQUARE, " UP ", 400).direction == "up"


def test_invalid_direction_fails_loudly():
    with pytest.raises(ValueError, match="direction"):
        RoadROI("a", SQUARE, "sideways", 400)


def test_count_line_outside_polygon_rejected():
    with pytest.raises(ValueError, match="count_line_y"):
        RoadROI("a", SQUARE, "down", 5000)


def test_polygon_needs_three_points():
    with pytest.raises(ValueError):
        RoadROI("a", [(0, 0), (1, 1)], "down", 0)


def test_duplicate_roi_names_rejected():
    defs = [{"name": "x", "polygon": SQUARE, "direction": "down", "count_line_y": 400}] * 2
    with pytest.raises(ValueError, match="unique"):
        RoadROIManager(1000, 1000, defs)


def test_median_point_belongs_to_no_roi():
    defs = [
        {"name": "L", "polygon": [(0, 0), (600, 0), (600, 700), (0, 700)], "direction": "down", "count_line_y": 400},
        {"name": "R", "polygon": [(680, 0), (1280, 0), (1280, 700), (680, 700)], "direction": "up", "count_line_y": 400},
    ]
    mgr = RoadROIManager(1280, 720, defs)
    assert mgr.assign((300, 400)).name == "L"
    assert mgr.assign((900, 400)).name == "R"
    assert mgr.assign((640, 400)) is None


# ---- counting ----------------------------------------------------------------
def roi(direction="both", line=400):
    return RoadROI("r", SQUARE, direction, line)


def feed(counter, r, ys, tid="a"):
    return [counter.update(tid, r, y) for y in ys]


def test_vehicle_counted_once_going_down():
    c, r = RoiLineCounter(), roi()
    results = [x for x in feed(c, r, range(300, 500, 10)) if x]
    assert len(results) == 1 and results[0]["direction"] == "down"
    assert c.counts_by_roi_direction[("r", "down")] == 1


def test_vehicle_counted_once_going_up():
    c, r = RoiLineCounter(), roi()
    results = [x for x in feed(c, r, range(500, 300, -10)) if x]
    assert len(results) == 1 and results[0]["direction"] == "up"


def test_jitter_on_the_line_never_counts_a_stopped_vehicle():
    c, r = RoiLineCounter(), roi()
    # stopped on the line, box jittering +/-3 px (inside the hysteresis band)
    jitter = [397, 403, 398, 402, 396, 404] * 10
    assert not any(feed(c, r, jitter))
    assert c.counted_ids == set()


def test_jitter_then_real_crossing_is_counted_exactly_once():
    c, r = RoiLineCounter(), roi()
    ys = [380] * 3 + [397, 403, 398, 402] + [420, 440]
    assert len([x for x in feed(c, r, ys) if x]) == 1


def test_slow_crawler_is_still_counted():
    c, r = RoiLineCounter(), roi()
    ys = [380 + 0.5 * i for i in range(120)]          # 0.5 px/frame crawl across the line
    assert len([x for x in feed(c, r, ys) if x]) == 1


def test_wrong_direction_flagged_not_hidden():
    c, r = RoiLineCounter(), roi(direction="up")
    res = [x for x in feed(c, r, range(300, 500, 10)) if x][0]
    assert res["wrong_direction"] is True
    assert "a" in c.wrong_direction_ids


def test_correct_direction_not_flagged():
    c, r = RoiLineCounter(), roi(direction="down")
    res = [x for x in feed(c, r, range(300, 500, 10)) if x][0]
    assert res["wrong_direction"] is False


def test_vehicle_outside_any_roi_is_never_counted():
    c = RoiLineCounter()
    assert not any(c.update("a", None, y) for y in range(300, 500, 10))


def test_forget_bounds_memory():
    c, r = RoiLineCounter(), roi()
    feed(c, r, range(300, 500, 10))
    c.forget("a")
    assert "a" not in c.last_side and "a" not in c.counted_ids


def test_counts_are_independent_per_roi():
    c = RoiLineCounter()
    left = RoadROI("left", SQUARE, "down", 400)
    right = RoadROI("right", SQUARE, "up", 400)
    feed(c, left, range(300, 500, 10), tid="car1")
    feed(c, right, range(500, 300, -10), tid="car2")
    assert c.counts_by_roi_direction[("left", "down")] == 1
    assert c.counts_by_roi_direction[("right", "up")] == 1
