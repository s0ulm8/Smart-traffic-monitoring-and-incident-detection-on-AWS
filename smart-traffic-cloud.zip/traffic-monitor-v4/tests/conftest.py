"""Shared test helpers: fake detector / plate recognizer so the whole pipeline
can be exercised deterministically, with no model downloads."""

import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config  # noqa: E402

FRAME_W, FRAME_H = 1280, 720


def blank_frame(w=FRAME_W, h=FRAME_H):
    return np.full((h, w, 3), 120, dtype=np.uint8)


def det(raw_id, box, cls="Car", conf=0.9):
    return {"id": raw_id, "box": tuple(int(v) for v in box), "cls_id": 2, "cls_name": cls, "conf": conf}


def box_at(gx, gy, w=120, h=90):
    """A box whose bottom-centre ground point is exactly (gx, gy)."""
    return (int(gx - w / 2), int(gy - h), int(gx + w / 2), int(gy))


class FakeDetector:
    """track() returns the next scripted list of detections (empty when exhausted)."""

    def __init__(self, script=None):
        self.script = list(script or [])
        self.calls = 0

    def track(self, frame):
        self.calls += 1
        return self.script.pop(0) if self.script else []


class FakePlates:
    """Stand-in for PlateRecognizer. plate_visible(frame_idx) decides if a plate
    can be found; reads is a list of (text, conf) returned in order."""

    def __init__(self, reads=None, visible=lambda n: True, with_reader=True):
        self.reader = object() if with_reader else None
        self.reads = list(reads or [])
        self.visible = visible
        self.detect_calls = 0
        self.read_calls = 0

    def detect_plate(self, crop):
        self.detect_calls += 1
        if self.visible(self.detect_calls):
            return np.zeros((20, 60, 3), dtype=np.uint8), None
        return None, None

    def read_plate(self, crop):
        self.read_calls += 1
        if self.reads:
            return self.reads.pop(0) if len(self.reads) > 1 else self.reads[0]
        return None, 0.0


def make_monitor(script, plates=None, **kwargs):
    from processor import TrafficMonitor

    return TrafficMonitor(detector=FakeDetector(script), plate_recognizer=plates or FakePlates(with_reader=False),
                          **kwargs)


def run(monitor, n, fps=25.0):
    frame_stats = None
    for i in range(n):
        _, frame_stats = monitor.process_frame(blank_frame(), i / fps)
    return frame_stats


@pytest.fixture
def cfg():
    """Snapshot/restore config so tests can change thresholds safely."""
    saved = {k: getattr(config, k) for k in dir(config) if k.isupper()}
    yield config
    for k, v in saved.items():
        setattr(config, k, v)


# A perspective-skewed road rectangle: 3.5 m wide x 20 m long.
CALIB_SRC = [(250, 400), (390, 400), (500, 600), (140, 600)]
CALIB_DST = [(0, 0), (3.5, 0), (3.5, 20), (0, 20)]
