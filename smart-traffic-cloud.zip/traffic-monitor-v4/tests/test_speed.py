import numpy as np
import pytest

from conftest import CALIB_DST, CALIB_SRC
from speed_estimator import HomographySpeedEstimator, SimpleLineSpeedEstimator


def drive(est, ys, fps=25.0, x=100):
    """Feed y positions one per frame; return the list of readings (None = no fresh reading)."""
    return [est.update("v", x, y, i / fps) for i, y in enumerate(ys)]


# ---- bug: upward-moving vehicles never got a speed --------------------------
def test_line_speed_works_for_downward_traffic():
    est = SimpleLineSpeedEstimator(300, 500, 15.0)
    readings = [r for r in drive(est, range(200, 600, 8)) if r]
    assert len(readings) == 1
    # 200 px between lines at 8 px/frame, 25 fps -> 25 frames = 1.0 s -> 15 m/s = 54 km/h
    assert readings[0].speed_kmh == pytest.approx(54.0, abs=3)


def test_line_speed_works_for_upward_traffic():
    est = SimpleLineSpeedEstimator(300, 500, 15.0)
    readings = [r for r in drive(est, range(600, 200, -8)) if r]
    assert len(readings) == 1, "upward-moving vehicles used to never receive a speed"
    assert readings[0].speed_kmh == pytest.approx(54.0, abs=3)


def test_line_speed_reports_once_and_has_conservative_bound():
    est = SimpleLineSpeedEstimator(300, 500, 15.0)
    readings = [r for r in drive(est, list(range(200, 600, 8)) + list(range(600, 200, -8))) if r]
    assert len(readings) == 1
    assert readings[0].decision_kmh < readings[0].speed_kmh      # accounts for one-frame timing error


# ---- bug: calibration validation gave cryptic crashes ------------------------
def test_homography_requires_four_points():
    with pytest.raises(ValueError, match="4\\+"):
        HomographySpeedEstimator([(0, 0), (10, 0), (10, 10)], [(0, 0), (3, 0), (3, 5)])


def test_homography_rejects_mismatched_point_counts():
    with pytest.raises(ValueError):
        HomographySpeedEstimator(CALIB_SRC, CALIB_DST[:3])


def test_homography_rejects_collinear_points():
    with pytest.raises(ValueError, match="collinear"):
        HomographySpeedEstimator([(0, 0), (1, 1), (2, 2), (3, 3)], [(0, 0), (1, 0), (2, 0), (3, 0)])


def test_homography_none_points():
    with pytest.raises(ValueError):
        HomographySpeedEstimator(None, None)


# ---- homography correctness -------------------------------------------------
def _pixel_track(est, kmh, n=30, fps=25.0, jitter=0.0, seed=0):
    rng = np.random.default_rng(seed)
    Hinv = np.linalg.inv(est.H)
    out = []
    for i in range(n):
        t = i / fps
        Y = 0.5 + kmh / 3.6 * t
        if Y > 19.5:
            break
        v = Hinv @ np.array([1.75, Y, 1.0])
        v /= v[2]
        out.append(est.update("v", v[0] + rng.uniform(-jitter, jitter), v[1] + rng.uniform(-jitter, jitter), t))
    return [r for r in out if r]


def test_homography_recovers_true_speed_through_perspective():
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST)
    readings = _pixel_track(est, 54.0)
    assert readings and readings[-1].speed_kmh == pytest.approx(54.0, abs=0.5)


def test_homography_waits_for_enough_points():
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST, min_points=5)
    Hinv = np.linalg.inv(est.H)
    v = Hinv @ np.array([1.75, 2.0, 1.0])
    v /= v[2]
    first_four = [est.update("v", v[0], v[1] + i, i / 25) for i in range(4)]
    assert all(r is None for r in first_four)


# ---- fix: don't extrapolate the homography outside the calibrated area -------
def test_homography_ignores_points_outside_calibrated_zone():
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST)
    for i in range(10):
        assert est.update("v", 1200, 50 + i, i / 25) is None     # far outside the quad
    assert "v" not in est.history or len(est.history["v"]) == 0


def test_implausible_speed_is_rejected_as_glitch():
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST, max_kmh=100)
    assert _pixel_track(est, 400.0) == []          # >100 km/h is treated as a tracking glitch


def test_forget_clears_history():
    est = HomographySpeedEstimator(CALIB_SRC, CALIB_DST)
    _pixel_track(est, 40.0)
    est.forget("v")
    assert "v" not in est.history


def test_simple_estimator_rejects_implausible_jump():
    """A box that snaps across both lines in one step must not yield a speed."""
    from speed_estimator import SimpleLineSpeedEstimator
    est = SimpleLineSpeedEstimator(400, 580, 12.0)
    est.update(1, 600, 300, 0.0)
    assert est.update(1, 600, 650, 0.04) is None
