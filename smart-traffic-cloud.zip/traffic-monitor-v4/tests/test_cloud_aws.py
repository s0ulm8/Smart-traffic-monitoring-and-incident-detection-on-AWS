"""AWS-facing code tested against moto (an in-memory AWS): S3 storage, Secrets
Manager-based settings, CloudWatch metrics and Auto Scaling protection calls."""

import json
import socket
import time

import boto3
import pytest
from moto import mock_aws

from cloud import security
from cloud.aws_hooks import AwsHooks
from cloud.settings import Settings
from cloud.storage import LocalStorage, S3Storage, make_storage

REGION = "ap-south-1"


@pytest.fixture(autouse=True)
def fake_aws_env(monkeypatch):
    for k in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"):
        monkeypatch.setenv(k, "testing")
    monkeypatch.setenv("AWS_DEFAULT_REGION", REGION)


@mock_aws
def test_s3_storage_roundtrip_and_prefix_delete(tmp_path):
    boto3.client("s3", region_name=REGION).create_bucket(
        Bucket="test-bucket", CreateBucketConfiguration={"LocationConstraint": REGION})
    st = S3Storage("test-bucket", REGION, ttl=600)
    f = tmp_path / "v.mp4"
    f.write_bytes(b"video-bytes")
    st.put_file("jobs/j1/annotated.mp4", f, "video/mp4")
    st.put_bytes("jobs/j1/incidents/1.jpg", b"\xff\xd8jpg", "image/jpeg")
    st.put_bytes("jobs/j2/incidents/1.jpg", b"keep", "image/jpeg")
    head = boto3.client("s3", region_name=REGION).head_object(Bucket="test-bucket", Key="jobs/j1/annotated.mp4")
    assert head["ContentType"] == "video/mp4"
    url = st.url("jobs/j1/annotated.mp4")
    assert url.startswith("https://") and "X-Amz-Signature" in url and "X-Amz-Expires=600" in url
    st.delete_prefix("jobs/j1/")
    keys = [o["Key"] for o in boto3.client("s3", region_name=REGION).list_objects_v2(Bucket="test-bucket")["Contents"]]
    assert keys == ["jobs/j2/incidents/1.jpg"]                      # only job 1 was removed


def test_local_storage_blocks_path_escape(tmp_path):
    st = LocalStorage(tmp_path / "root", "secret")
    assert st.resolve("jobs/a/b.jpg") is not None
    assert st.resolve("../outside") is None and st.resolve("jobs/../../x") is None
    st.put_bytes("jobs/a/x.jpg", b"1", "image/jpeg")
    st.delete_prefix("../")                                          # must not delete anything outside / the root
    assert (tmp_path / "root" / "jobs" / "a" / "x.jpg").exists()


def test_make_storage_chooses_backend(tmp_path):
    assert isinstance(make_storage(Settings(local_storage_dir=str(tmp_path))), LocalStorage)


@mock_aws
def test_settings_read_secrets_from_secrets_manager():
    sm = boto3.client("secretsmanager", region_name=REGION)
    key_arn = sm.create_secret(Name="api", SecretString="k3y-from-secret")["ARN"]
    db_arn = sm.create_secret(Name="db", SecretString=json.dumps({"username": "ta", "password": "p@ss/w:rd"}))["ARN"]
    s = Settings.from_env({"API_KEY_SECRET_ARN": key_arn, "DB_SECRET_ARN": db_arn, "DB_HOST": "db.example.internal",
                           "DB_NAME": "traffic", "S3_BUCKET": "bkt", "INSTANCE_ID": "i-123", "AWS_REGION": REGION})
    assert s.api_key == "k3y-from-secret"
    assert s.database_url.startswith("postgresql+psycopg2://ta:") and "@db.example.internal:5432/traffic" in s.database_url
    assert "p@ss/w:rd" not in s.database_url                        # special characters are URL-escaped
    assert s.db_ssl is True and s.s3_bucket == "bkt" and s.instance_id == "i-123"
    assert s.signing_secret.startswith("k3y-from-secret")           # identical on all instances


def test_settings_defaults_for_local_dev():
    s = Settings.from_env({})
    assert s.api_key == "" and s.s3_bucket == "" and s.database_url.startswith("sqlite") and s.max_workers == 1


@mock_aws
def test_scale_in_protection_calls_asg():
    ec2 = boto3.client("ec2", region_name=REGION)
    asg = boto3.client("autoscaling", region_name=REGION)
    ami = ec2.describe_images()["Images"][0]["ImageId"]
    asg.create_launch_configuration(LaunchConfigurationName="lc", ImageId=ami, InstanceType="t3.micro")
    asg.create_auto_scaling_group(AutoScalingGroupName="tm-asg", LaunchConfigurationName="lc", MinSize=1, MaxSize=2,
                                  AvailabilityZones=[f"{REGION}a"])
    iid = asg.describe_auto_scaling_groups()["AutoScalingGroups"][0]["Instances"][0]["InstanceId"]
    hooks = AwsHooks(Settings(asg_name="tm-asg", instance_id=iid, aws_region=REGION))
    hooks.set_scale_in_protection(True)
    state = lambda: asg.describe_auto_scaling_groups()["AutoScalingGroups"][0]["Instances"][0]["ProtectedFromScaleIn"]
    assert state() is True
    hooks.set_scale_in_protection(False)
    assert state() is False


@mock_aws
def test_cloudwatch_metrics_and_failure_safety():
    hooks = AwsHooks(Settings(cloudwatch_enabled=True, aws_region=REGION))
    hooks.put_metric("IncidentsDetected", 2)
    metrics = boto3.client("cloudwatch", region_name=REGION).list_metrics(Namespace="TrafficMonitor")["Metrics"]
    assert [m["MetricName"] for m in metrics] == ["IncidentsDetected"]
    # disabled / misconfigured hooks must never raise
    AwsHooks(Settings()).put_metric("x")
    AwsHooks(Settings(asg_name="a", instance_id="local")).set_scale_in_protection(True)
    broken = AwsHooks(Settings(asg_name="nope", instance_id="i-doesnotexist", aws_region=REGION))
    broken.set_scale_in_protection(True)


# ---- security helpers ---------------------------------------------------
def test_signature_roundtrip_expiry_and_tamper():
    exp = int(time.time()) + 60
    sig = security.sign("jobs/a/b.mp4", exp, "s")
    assert security.verify("jobs/a/b.mp4", exp, sig, "s")
    assert not security.verify("jobs/a/other.mp4", exp, sig, "s")
    assert not security.verify("jobs/a/b.mp4", exp, sig, "different-secret")
    old = int(time.time()) - 1
    assert not security.verify("k", old, security.sign("k", old, "s"), "s")
    assert not security.verify("k", "abc", "x", "s")


def test_ssrf_guard_resolves_dns_and_blocks_private(monkeypatch):
    def fake_getaddrinfo(host, port, proto=0):
        table = {"public.example": "93.184.216.34", "internal.example": "10.1.2.3",
                 "meta.example": "169.254.169.254", "mapped.example": "::ffff:127.0.0.1"}
        if host not in table:
            raise socket.gaierror("nope")
        return [(socket.AF_INET, 0, 0, "", (table[host], 0))]
    monkeypatch.setattr(socket, "getaddrinfo", fake_getaddrinfo)
    assert security.validate_stream_url("rtsp://public.example/live") == "rtsp://public.example/live"
    for bad in ("http://internal.example/", "http://meta.example/latest", "http://mapped.example/",
                "http://missing.example/", "http:///nohost", "javascript:alert(1)", "", "http://" + "a" * 3000):
        with pytest.raises(ValueError):
            security.validate_stream_url(bad)
    assert security.validate_stream_url("http://internal.example/", allow_private=True)
