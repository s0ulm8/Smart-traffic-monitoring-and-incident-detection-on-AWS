"""
Keeps one stable "canonical" ID per physical vehicle even when the underlying
tracker drops and re-issues IDs (occlusion, flicker).

When a raw track disappears it goes into a short-lived "lost" pool. A new raw
track may inherit its canonical ID if it appears nearby, soon after, with
similar appearance AND similar size. Class is only a score bonus: distant
vehicles flicker between Car/Truck, so requiring an exact match fragments IDs.

Guards against wrong merges (which would silently under-count):
  * tracks last seen at a frame edge are assumed to have LEFT the scene and
    are never put in the lost pool;
  * the new box must be a similar size to the lost one;
  * two raw IDs visible in the same frame can never share a canonical ID
    (a stale wrong merge is split on sight).
Memory is bounded: raw IDs unseen for TRACK_MEMORY_FRAMES are forgotten.

Residual limitation: a different, same-looking, same-sized vehicle that appears
right where another vanished mid-scene (not at an edge) can still be merged.
"""

from dataclasses import dataclass

import cv2
import numpy as np

import config


@dataclass
class _Snapshot:
    canonical_id: int
    ground_point: tuple
    box: tuple
    cls_name: str
    hist: np.ndarray
    last_seen_frame: int


def _area(box):
    return max(1, (box[2] - box[0]) * (box[3] - box[1]))


class TrackMerger:
    def __init__(self, max_lost_frames=None, max_dist_px=None, min_hist_sim=None,
                 min_area_ratio=None, exit_margin_px=None, memory_frames=None):
        self.max_lost_frames = config.TRACK_LOST_MAX_FRAMES if max_lost_frames is None else max_lost_frames
        self.max_dist_px = config.TRACK_MATCH_MAX_DIST_PX if max_dist_px is None else max_dist_px
        self.min_hist_sim = config.TRACK_MATCH_MIN_HIST_SIM if min_hist_sim is None else min_hist_sim
        self.min_area_ratio = config.TRACK_MATCH_MIN_AREA_RATIO if min_area_ratio is None else min_area_ratio
        self.exit_margin_px = config.TRACK_EXIT_MARGIN_PX if exit_margin_px is None else exit_margin_px
        self.memory_frames = config.TRACK_MEMORY_FRAMES if memory_frames is None else memory_frames

        self.raw_to_canonical = {}
        self.last_snapshot = {}
        self.lost_pool = {}
        self._active_last_frame = set()
        self._next_canonical_id = 1

    # -- helpers ---------------------------------------------------------
    @staticmethod
    def _color_hist(frame, box):
        x1, y1, x2, y2 = box
        crop = frame[max(y1, 0):y2, max(x1, 0):x2]
        if crop.size == 0:
            return None
        hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [16, 16], [0, 180, 0, 256])
        cv2.normalize(hist, hist)
        return hist

    @staticmethod
    def _ground_point(box):
        return ((box[0] + box[2]) / 2, box[3])

    def _touches_edge(self, box, frame_w, frame_h):
        m = self.exit_margin_px
        return box[0] <= m or box[1] <= m or box[2] >= frame_w - m or box[3] >= frame_h - m

    def _best_match(self, point, box, cls_name, hist, frame_idx):
        best_id, best_score = None, -1.0
        area_new = _area(box)
        for raw_id, snap in self.lost_pool.items():
            frames_lost = frame_idx - snap.last_seen_frame
            if frames_lost > self.max_lost_frames:
                continue
            ratio = area_new / _area(snap.box)
            if not (self.min_area_ratio <= ratio <= 1.0 / self.min_area_ratio):
                continue                     # a visibly different-sized vehicle
            max_dist = self.max_dist_px * (1 + 0.15 * frames_lost)
            dist = float(np.hypot(point[0] - snap.ground_point[0], point[1] - snap.ground_point[1]))
            if dist > max_dist:
                continue
            sim = 0.0 if (hist is None or snap.hist is None) else cv2.compareHist(hist, snap.hist, cv2.HISTCMP_CORREL)
            if sim < self.min_hist_sim:
                continue
            score = sim + (0.1 if snap.cls_name == cls_name else 0.0) - (dist / max_dist) * 0.3
            if score > best_score:
                best_score, best_id = score, raw_id
        return best_id

    # -- main ------------------------------------------------------------
    def update(self, frame, detections, frame_idx):
        frame_h, frame_w = frame.shape[:2]
        current_raw_ids = {d["id"] for d in detections}

        # tracks that vanished this frame -> lost pool, unless they left the scene
        for raw_id in self._active_last_frame - current_raw_ids:
            snap = self.last_snapshot.get(raw_id)
            if snap is None or raw_id in self.lost_pool:
                continue
            if self._touches_edge(snap.box, frame_w, frame_h):
                continue
            self.lost_pool[raw_id] = snap

        used_this_frame = {}
        for det in detections:
            raw_id = det["id"]
            point = self._ground_point(det["box"])
            hist = self._color_hist(frame, det["box"])

            if raw_id in self.raw_to_canonical:
                canonical_id = self.raw_to_canonical[raw_id]
            else:
                match = self._best_match(point, det["box"], det["cls_name"], hist, frame_idx)
                if match is not None:
                    canonical_id = self.lost_pool[match].canonical_id
                    del self.lost_pool[match]
                else:
                    canonical_id = self._next_canonical_id
                    self._next_canonical_id += 1
                self.raw_to_canonical[raw_id] = canonical_id

            # A canonical ID must belong to ONE visible detection per frame.
            if canonical_id in used_this_frame:
                canonical_id = self._next_canonical_id
                self._next_canonical_id += 1
                self.raw_to_canonical[raw_id] = canonical_id
            used_this_frame[canonical_id] = raw_id

            det["canonical_id"] = canonical_id
            self.last_snapshot[raw_id] = _Snapshot(canonical_id, point, tuple(det["box"]),
                                                   det["cls_name"], hist, frame_idx)

        for rid in [r for r, s in self.lost_pool.items() if frame_idx - s.last_seen_frame > self.max_lost_frames]:
            del self.lost_pool[rid]

        if frame_idx % 100 == 0:
            self._forget_old(current_raw_ids, frame_idx)

        self._active_last_frame = current_raw_ids
        return detections

    def _forget_old(self, current_raw_ids, frame_idx):
        """Bound memory on long/continuous streams."""
        for rid in [r for r, s in self.last_snapshot.items()
                    if r not in current_raw_ids and frame_idx - s.last_seen_frame > self.memory_frames]:
            self.last_snapshot.pop(rid, None)
            self.raw_to_canonical.pop(rid, None)
            self.lost_pool.pop(rid, None)
