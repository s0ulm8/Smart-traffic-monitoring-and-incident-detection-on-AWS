"""
CLI runner.

  python main.py --source traffic.mp4 --scene scenes/highway_example.json --output out.mp4
  python main.py --source 0 --distance 12.5          # live camera, measured line distance

Geometry (carriageway ROIs, speed calibration) comes from --scene JSON, or
config.py. Speed is only meaningful when calibrated: give calibration points
in the scene file, or a MEASURED --distance between the two speed lines.
"""

import argparse

import config
from processor import TrafficMonitor
from scene import load_scene
from utils import reencode_h264


def main():
    p = argparse.ArgumentParser(description="Traffic monitoring pipeline")
    p.add_argument("--source", required=True, help="Video file, stream URL, or camera index (0,1,...)")
    p.add_argument("--output", default="annotated_output.mp4", help="Annotated video to write")
    p.add_argument("--scene", help="JSON scene file (ROIs, speed calibration, limit)")
    p.add_argument("--speed-limit", type=float, help="Speed limit km/h (overrides scene/config)")
    p.add_argument("--distance", type=float,
                   help="MEASURED metres between the two speed lines (fallback speed mode)")
    p.add_argument("--model", default=config.MODEL_PATH, help="YOLO detection model")
    p.add_argument("--plate-model", default=config.PLATE_MODEL_PATH, help="Dedicated plate-detector model")
    p.add_argument("--no-ocr", action="store_true", help="Disable plate OCR (faster)")
    p.add_argument("--alert-uncalibrated", action="store_true",
                   help="Raise overspeed alerts even without a measured distance (demo only; speeds are unreliable)")
    p.add_argument("--gpu", action="store_true", help="Use CUDA for YOLO and OCR if available")
    p.add_argument("--out-dir", default=".", help="Where to write summary.json / events.csv")
    args = p.parse_args()

    if args.alert_uncalibrated:
        config.ALERT_WHEN_UNCALIBRATED = True
    if args.gpu:
        config.USE_GPU = True

    source = int(args.source) if args.source.isdigit() else args.source

    kwargs = load_scene(args.scene) if args.scene else {}
    if args.speed_limit is not None:
        kwargs["speed_limit_kmh"] = args.speed_limit
    if args.distance is not None:
        kwargs["real_distance_m"] = args.distance
        kwargs["distance_is_measured"] = True

    monitor = TrafficMonitor(model_path=args.model, plate_model_path=args.plate_model,
                             enable_ocr=not args.no_ocr, **kwargs)

    monitor.run_on_video(source, output_path=args.output)
    if reencode_h264(args.output):
        print("Re-encoded output to H.264 (browser-playable).")
    monitor.save_report(args.out_dir)
    monitor.print_summary()
    print(f"\nAnnotated video: {args.output}")
    print(f"Reports: {args.out_dir}/summary.json, {args.out_dir}/events.csv")


if __name__ == "__main__":
    main()
