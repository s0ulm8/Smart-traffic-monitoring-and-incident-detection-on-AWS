"""
Speed estimators. Both return a SpeedReading ONLY when a fresh measurement
was made this frame (else None), so the caller can require several fresh
readings before raising an overspeed alert.

SpeedReading.speed_kmh     - best estimate (shown on screen)
SpeedReading.decision_kmh  - value used for the overspeed decision (for the
                             one-shot estimator this is a conservative lower
                             bound that accounts for frame-timing error)

HomographySpeedEstimator (recommended)
    4+ calibration points map pixels to ground-plane metres (perspective
    corrected). Only points INSIDE the calibrated quad are used - a
    homography extrapolated beyond it is unreliable. Speed is a least-squares
    fit over a sliding window, reported once SPEED_MIN_POINTS are available.

SimpleLineSpeedEstimator (fallback, no perspective correction)
    Time between crossing two lines a measured distance apart. Works in
    BOTH directions. Only meaningful if the distance is real for your scene.
"""

from collections import deque, namedtuple

import cv2
import numpy as np

import config

SpeedReading = namedtuple("SpeedReading", ["speed_kmh", "decision_kmh"])


class HomographySpeedEstimator:
    def __init__(self, src_points, dst_points, window=None, min_points=None, max_kmh=None):
        if src_points is None or dst_points is None:
            raise ValueError("calibration needs both source (pixel) and destination (metre) points")
        if len(src_points) < 4 or len(src_points) != len(dst_points):
            raise ValueError(
                f"calibration needs 4+ matching point pairs, got {len(src_points)} pixel / {len(dst_points)} metre points"
            )
        src = np.array(src_points, dtype=np.float32).reshape(-1, 2)
        dst = np.array(dst_points, dtype=np.float32).reshape(-1, 2)

        hull = cv2.convexHull(src)
        if cv2.contourArea(hull) < 1.0:
            raise ValueError("calibration pixel points are collinear/degenerate - they must span an area on the road")

        H, _ = cv2.findHomography(src, dst, 0)
        if H is None or not np.all(np.isfinite(H)) or abs(np.linalg.det(H)) < 1e-12:
            raise ValueError("could not compute a valid homography from the calibration points - check their order and values")

        self.H = H
        self.zone = hull                                   # calibrated area (pixels)
        self.window = config.SPEED_SMOOTHING_WINDOW if window is None else window
        self.min_points = config.SPEED_MIN_POINTS if min_points is None else min_points
        self.max_kmh = config.SPEED_MAX_PLAUSIBLE_KMH if max_kmh is None else max_kmh
        self.history = {}                                  # track_id -> deque[(t, X, Y)]

    @property
    def confirm(self):
        return config.OVERSPEED_CONFIRM_FRAMES

    def _to_ground_plane(self, px, py):
        mapped = self.H @ np.array([px, py, 1.0])
        mapped /= mapped[2]
        return float(mapped[0]), float(mapped[1])

    def update(self, track_id, cx, cy, timestamp):
        if cv2.pointPolygonTest(self.zone, (float(cx), float(cy)), False) < 0:
            return None                      # outside the calibrated area: don't extrapolate

        X, Y = self._to_ground_plane(cx, cy)
        hist = self.history.setdefault(track_id, deque(maxlen=self.window))
        hist.append((timestamp, X, Y))
        if len(hist) < self.min_points:
            return None

        ts = np.array([h[0] for h in hist])
        if ts[-1] - ts[0] <= 0:
            return None
        vx = np.polyfit(ts, [h[1] for h in hist], 1)[0]
        vy = np.polyfit(ts, [h[2] for h in hist], 1)[0]
        kmh = float(np.hypot(vx, vy)) * 3.6
        if kmh > self.max_kmh:
            return None                      # physically implausible: tracking glitch
        kmh = round(kmh, 1)
        return SpeedReading(kmh, kmh)

    def forget(self, track_id):
        self.history.pop(track_id, None)


class SimpleLineSpeedEstimator:
    confirm = 1                              # one-shot measurement; bound handles timing error

    def __init__(self, line_a_y, line_b_y, real_distance_m):
        self.line_a_y = min(line_a_y, line_b_y)
        self.line_b_y = max(line_a_y, line_b_y)
        self.real_distance_m = real_distance_m
        self.crossings = {}                  # track_id -> {"a": t, "b": t, "done": bool}
        self.last_y = {}
        self.last_t = {}

    def update(self, track_id, cx, cy, timestamp):
        prev_y, prev_t = self.last_y.get(track_id), self.last_t.get(track_id)
        self.last_y[track_id], self.last_t[track_id] = cy, timestamp
        rec = self.crossings.setdefault(track_id, {})
        if prev_y is None or rec.get("done"):
            return None

        for key, line in (("a", self.line_a_y), ("b", self.line_b_y)):
            if key in rec:
                continue
            # a crossing in EITHER direction (down-frame or up-frame traffic)
            if (prev_y < line <= cy) or (prev_y > line >= cy):
                # interpolate the crossing instant between the two frames
                span = cy - prev_y
                frac = (line - prev_y) / span if span else 1.0
                rec[key] = prev_t + frac * (timestamp - prev_t) if prev_t is not None else timestamp

        if "a" in rec and "b" in rec:
            rec["done"] = True
            dt = abs(rec["b"] - rec["a"])
            if dt <= 0:
                return None
            frame_period = (timestamp - prev_t) if (prev_t is not None and timestamp > prev_t) else 0.0
            speed = self.real_distance_m / dt * 3.6
            if speed > config.SPEED_MAX_PLAUSIBLE_KMH:
                return None                  # tracking jump (box snapped across both lines)
            # Each crossing time is only known to within one frame, so the
            # slowest plausible speed uses dt + one frame period.
            lower = self.real_distance_m / (dt + frame_period) * 3.6
            return SpeedReading(round(speed, 1), round(lower, 1))
        return None

    def forget(self, track_id):
        self.crossings.pop(track_id, None)
        self.last_y.pop(track_id, None)
        self.last_t.pop(track_id, None)
