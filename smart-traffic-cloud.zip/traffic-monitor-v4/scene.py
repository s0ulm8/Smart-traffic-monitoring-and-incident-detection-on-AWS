"""
Per-camera scene profiles, so geometry lives in a JSON file instead of
editing source code. Example (scenes/highway_example.json):

{
  "speed_limit_kmh": 50,
  "speed_line_a_ratio": 0.62,               # where the two speed lines sit (fraction of frame height)
  "speed_line_b_ratio": 0.88,
  "line_distance_m": 15.0,                  # MEASURED metres between the two speed lines
  "calibration_src_points": [[x,y], ...],   # optional, 4+ pixel points (preferred)
  "calibration_dst_points": [[X,Y], ...],   # matching metres
  "road_rois": [
    {"name": "left", "polygon": [[0,720],[0,260],[630,260],[490,720]],
     "direction": "down", "count_line_y": 550}
  ]
}
"""

import json


def load_scene(path):
    """Returns TrafficMonitor keyword arguments built from the scene file."""
    with open(path) as f:
        data = json.load(f)

    allowed = {"speed_limit_kmh", "line_distance_m", "calibration_src_points",
               "calibration_dst_points", "road_rois", "speed_line_a_ratio", "speed_line_b_ratio"}
    unknown = set(data) - allowed
    if unknown:
        raise ValueError(f"scene file {path}: unknown keys {sorted(unknown)} (allowed: {sorted(allowed)})")

    kwargs = {}
    if "speed_limit_kmh" in data:
        kwargs["speed_limit_kmh"] = float(data["speed_limit_kmh"])
    if "line_distance_m" in data:
        kwargs["real_distance_m"] = float(data["line_distance_m"])
        kwargs["distance_is_measured"] = True
    if "speed_line_a_ratio" in data:
        kwargs["speed_line_a_ratio"] = float(data["speed_line_a_ratio"])
    if "speed_line_b_ratio" in data:
        kwargs["speed_line_b_ratio"] = float(data["speed_line_b_ratio"])
    if "calibration_src_points" in data:
        kwargs["calibration_src_points"] = [tuple(p) for p in data["calibration_src_points"]]
    if "calibration_dst_points" in data:
        kwargs["calibration_dst_points"] = [tuple(p) for p in data["calibration_dst_points"]]
    if "road_rois" in data:
        kwargs["road_rois"] = [
            {**r, "polygon": [tuple(p) for p in r["polygon"]]} for r in data["road_rois"]
        ]
    return kwargs
