"""
Keeps a vote count per class for each tracked vehicle instead of
overwriting its class with whatever YOLO says on the current frame.

A track only SWITCHES its reported class when a challenger has at least
CLASS_VOTE_MIN_MARGIN more votes than the current leader - a couple of
misclassified frames out of hundreds won't flip the final vehicle type.
"""

from collections import Counter

import config


class ClassVoter:
    def __init__(self):
        self.votes = {}      # canonical_id -> Counter(class_name -> count)
        self.current = {}    # canonical_id -> current leading class name

    def update(self, tid, cls_name):
        counter = self.votes.setdefault(tid, Counter())
        counter[cls_name] += 1

        leader = self.current.get(tid)
        if leader is None:
            self.current[tid] = cls_name
            return cls_name

        if cls_name != leader and counter[cls_name] >= counter[leader] + config.CLASS_VOTE_MIN_MARGIN:
            self.current[tid] = cls_name

        return self.current[tid]

    def forget(self, tid):
        self.votes.pop(tid, None)
        self.current.pop(tid, None)
