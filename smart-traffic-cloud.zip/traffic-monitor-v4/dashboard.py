"""
Streamlit dashboard.   Run with:  streamlit run dashboard.py
"""

import os
import tempfile
import time

import cv2
import pandas as pd
import plotly.express as px
import streamlit as st

import config
from processor import TrafficMonitor
from scene import load_scene

st.set_page_config(page_title="Traffic Monitoring Dashboard", layout="wide")
st.title("🚦 Traffic Monitoring Dashboard")

with st.sidebar:
    st.header("Start")
    uploaded = st.file_uploader("Upload a traffic video", type=["mp4", "avi", "mov", "mkv"])
    speed_limit = st.slider("Speed limit (km/h)", 20, 120, int(config.SPEED_LIMIT_KMH), 5)
    start_btn = st.button("▶ Start processing", type="primary", disabled=uploaded is None)

    # Everything below is optional - the defaults work with just a video.
    with st.expander("Advanced (optional)", expanded=False):
        scene_file = st.file_uploader("Scene file (JSON: lanes, speed calibration)", type=["json"])
        distance_m = st.number_input("Real distance between the two speed lines (m)", min_value=1.0,
                                     value=float(config.SPEED_CALIB_DISTANCE_M), step=0.5)
        distance_measured = st.checkbox("I measured this distance", value=False,
                                        help="Needed for overspeed alerts. Untick = speeds are indicative only.")
        enable_ocr = st.checkbox("Read number plates (slower)", value=True)
        frame_skip = st.slider("Process every Nth frame", 1, 5, 1,
                               help="Above 1 is faster but hurts tracking and speed accuracy.")
        chart_update_every = st.slider("Update charts every N frames", 1, 30, 10)

video_col, stats_col = st.columns([2, 1])
video_placeholder = video_col.empty()
calib_placeholder = video_col.empty()

row1, row2 = stats_col.columns(3), stats_col.columns(3)
total_metric, overspeed_metric, wrongdir_metric = (c.empty() for c in row1)
car_metric, moto_metric, bus_truck_metric = (c.empty() for c in row2)

st.subheader("By Carriageway / Direction")
roi_table_placeholder = st.empty()
chart_col1, chart_col2 = st.columns(2)
chart1_placeholder, chart2_placeholder = chart_col1.empty(), chart_col2.empty()
st.subheader("Vehicles / Plates")
table_placeholder = st.empty()
st.subheader("Overspeed events (plates update when OCR resolves)")
events_placeholder = st.empty()
alert_placeholder = st.container()

if start_btn and uploaded is not None:
    tmp_paths = []
    try:
        tfile = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
        tfile.write(uploaded.read())
        tfile.close()
        tmp_paths.append(tfile.name)

        kwargs = {}
        if scene_file is not None:
            sfile = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
            sfile.write(scene_file.read())
            sfile.close()
            tmp_paths.append(sfile.name)
            kwargs = load_scene(sfile.name)
        kwargs.setdefault("speed_limit_kmh", float(speed_limit))
        if "real_distance_m" not in kwargs:
            kwargs["real_distance_m"] = distance_m
            kwargs["distance_is_measured"] = distance_measured

        monitor = TrafficMonitor(enable_ocr=enable_ocr, **kwargs)

        cap = cv2.VideoCapture(tfile.name)
        fps_video = cap.get(cv2.CAP_PROP_FPS) or 25
        frame_no, t_start, events_shown = 0, time.time(), 0
        wrongdir_seen = set()

        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if frame_no % frame_skip == 0:
                frame, stats = monitor.process_frame(frame, frame_no / fps_video)
                video_placeholder.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), channels="RGB",
                                        use_container_width=True)
                if not stats["speed_calibrated"]:
                    calib_placeholder.warning("Speed is UNCALIBRATED - speeds are indicative only and NO overspeed alerts are raised until you tick 'I measured this distance' or load calibration points.")

                total_metric.metric("Vehicles counted", stats["total"])
                overspeed_metric.metric("Overspeeding", stats["overspeeding"])
                wrongdir_metric.metric("Wrong-direction", stats["wrong_direction"])
                by_class = stats["by_class"]
                car_metric.metric("Cars", by_class.get("Car", 0))
                moto_metric.metric("Motorcycles", by_class.get("Motorcycle", 0))
                bus_truck_metric.metric("Buses + Trucks", by_class.get("Bus", 0) + by_class.get("Truck", 0))

                if stats["by_roi_direction"]:
                    rows = [{"Carriageway": k.split("|")[0], "Direction": k.split("|")[1], "Count": v}
                            for k, v in stats["by_roi_direction"].items()]
                    roi_table_placeholder.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

                if frame_no % chart_update_every == 0:
                    if by_class:
                        df = pd.DataFrame({"Type": list(by_class), "Count": list(by_class.values())})
                        chart1_placeholder.plotly_chart(
                            px.bar(df, x="Type", y="Count", title="Vehicle Types", color="Type"),
                            use_container_width=True, key=f"c1_{frame_no}")
                    speeds = [r["speed"] for r in monitor.vehicle_records.values() if r["speed"] is not None]
                    if speeds:
                        fig = px.histogram(pd.DataFrame({"Speed (km/h)": speeds}), x="Speed (km/h)",
                                           title="Speed Distribution", nbins=15)
                        fig.add_vline(x=speed_limit, line_dash="dash", line_color="red")
                        chart2_placeholder.plotly_chart(fig, use_container_width=True, key=f"c2_{frame_no}")
                    rows = monitor.get_plate_table()
                    if rows:
                        table_placeholder.dataframe(pd.DataFrame(rows), use_container_width=True, height=250)
                    if monitor.events:
                        events_placeholder.dataframe(pd.DataFrame(monitor.events), use_container_width=True)

                if len(monitor.events) > events_shown:
                    for e in monitor.events[events_shown:]:
                        alert_placeholder.warning(f"⚠ OVERSPEED — track #{e['track_id']} | "
                                                  f"{e['speed_kmh']} km/h (limit {e['limit_kmh']})")
                    events_shown = len(monitor.events)
                new_wrong = monitor.counter.wrong_direction_ids - wrongdir_seen
                for tid in new_wrong:
                    alert_placeholder.error(f"🚫 WRONG-DIRECTION vehicle (track #{tid})")
                wrongdir_seen |= new_wrong
            frame_no += 1

        cap.release()
        if monitor.events:
            events_placeholder.dataframe(pd.DataFrame(monitor.events), use_container_width=True)
        st.success("Processing complete.")
        st.subheader("Final Summary")
        st.json(monitor.get_stats())
    finally:
        for path in tmp_paths:           # temp copies of the upload are no longer left behind
            try:
                os.remove(path)
            except OSError:
                pass
elif uploaded is None:
    st.info("Upload a video and press **Start processing** to begin.")
